#!/usr/bin/env bash
set -euo pipefail

node --check src/loan-calculator.js
node --check src/store.js
node --check src/common.js
node --check src/home-page.js
node --check src/loans-page.js
node --check src/insights-page.js
node --check src/settings-page.js
node --check src/form-page.js
node --check src/loan-page.js
node --check src/calculator-page.js
node --check src/boot.js
node --check src/pwa.js
node --check service-worker.js
node --test tests/loan-calculator.test.js tests/store.test.js tests/page-exports.test.js tests/pwa-config.test.js
