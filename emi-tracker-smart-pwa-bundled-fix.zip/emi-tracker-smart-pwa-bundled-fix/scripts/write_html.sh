write_page() {
  local file="$1"
  local title="$2"
  local desc="$3"
  local page="$4"
  cat > "$file" <<HTML
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#0b1020" />
    <meta name="description" content="$desc" />
    <title>$title</title>
    <script>
      (function () {
        try {
          var raw = localStorage.getItem('emi-tracker-modern-pwa.settings.v1');
          var settings = raw ? JSON.parse(raw) : {};
          var theme = settings && settings.theme === 'light' ? 'light' : 'dark';
          document.documentElement.setAttribute('data-theme', theme);
          var meta = document.querySelector('meta[name="theme-color"]');
          if (meta) {
            meta.setAttribute('content', theme === 'light' ? '#f8fafc' : '#0b1020');
          }
        } catch (error) {
          document.documentElement.setAttribute('data-theme', 'dark');
        }
      })();
    </script>
    <link rel="manifest" href="./manifest.webmanifest" />
    <link rel="apple-touch-icon" href="./assets/icons/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="EMI Tracker" />
    <link rel="stylesheet" href="./styles.css" />
  </head>
  <body data-page="$page">
    <noscript>
      <div class="fallback-box">
        <h1>EMI Tracker</h1>
        <p>This app needs JavaScript enabled.</p>
      </div>
    </noscript>
    <div id="app"></div>
    <script defer src="./vendor/react-lite.js"></script>
    <script defer src="./vendor/react-dom-lite.js"></script>
    <script defer src="./src/loan-calculator.js"></script>
    <script defer src="./src/store.js"></script>
    <script defer src="./src/common.js"></script>
    <script defer src="./src/home-page.js"></script>
    <script defer src="./src/loans-page.js"></script>
    <script defer src="./src/insights-page.js"></script>
    <script defer src="./src/settings-page.js"></script>
    <script defer src="./src/form-page.js"></script>
    <script defer src="./src/loan-page.js"></script>
    <script defer src="./src/calculator-page.js"></script>
    <script defer src="./src/boot.js"></script>
    <script defer src="./src/pwa.js"></script>
  </body>
</html>
HTML
}

write_page /tmp/emi-next/index.html 'EMI Tracker' 'Track multiple loans, reminders, and payoff insights.' 'home'
write_page /tmp/emi-next/loans.html 'Loans · EMI Tracker' 'Browse all saved loans with balances, EMIs, and payoff dates.' 'loans'
write_page /tmp/emi-next/insights.html 'Insights · EMI Tracker' 'Smart insights, payoff strategy, and AI-like loan planning guidance.' 'insights'
write_page /tmp/emi-next/settings.html 'Settings · EMI Tracker' 'Change currency, theme, reminders, and export CSV data.' 'settings'
write_page /tmp/emi-next/form.html 'Add Loan · EMI Tracker' 'Create or edit a loan with priority and prepayment preferences.' 'form'
write_page /tmp/emi-next/loan.html 'Loan Details · EMI Tracker' 'Track one loan with payment logging, planner, and amortization schedule.' 'loan'
write_page /tmp/emi-next/calculator.html 'Advanced EMI · EMI Tracker' 'Advanced EMI calculator with goal helper, graph comparison, and save flow.' 'calculator'
