# EMI Tracker PWA - bundled runtime fix

This build fixes the installed-app error:

> The app dependencies could not be loaded.

## What changed

The earlier build still depended on external React and ReactDOM CDN files.
If those CDN files were blocked, slow, or unavailable in the installed PWA cache, the app could fail to start.

This build removes that dependency by bundling a local browser runtime inside the app:

- `vendor/react-lite.js`
- `vendor/react-dom-lite.js`

The app now starts from local files only and the service worker caches those files for offline use.

## Files added or changed

- added `vendor/react-lite.js`
- added `vendor/react-dom-lite.js`
- updated all HTML entry pages to use local bundled runtime files
- updated `service-worker.js` to cache local runtime files and use a new cache version
- updated `src/pwa.js` to warm local runtime files instead of external CDN files
- updated tests to verify bundled dependency loading
- added runtime tests for controlled inputs and effect cleanup

## Verification

Run locally:

```bash
npm run verify
python3 -m http.server 8080
```

Then open:

```text
http://localhost:8080/index.html
```

## Netlify redeploy steps

1. Upload this updated build to Netlify.
2. Open the Netlify URL once in the mobile browser.
3. Remove the old installed app icon from Android.
4. Clear site data for the Netlify domain in Chrome.
5. Open the site again in Chrome and confirm it loads in the browser.
6. Install the app again.

## Important note

If the previous broken build is still cached on the phone, the old installed copy may keep showing the same dependency error until site data is cleared and the app is reinstalled.
