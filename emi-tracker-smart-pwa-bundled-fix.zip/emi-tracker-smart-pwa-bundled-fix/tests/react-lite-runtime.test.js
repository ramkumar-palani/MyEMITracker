const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const reactLiteCode = fs.readFileSync(path.join(__dirname, '../vendor/react-lite.js'), 'utf8');
const reactDomLiteCode = fs.readFileSync(path.join(__dirname, '../vendor/react-dom-lite.js'), 'utf8');

class ElementNode {
  constructor(tagName, ownerDocument) {
    this.nodeType = 1;
    this.ownerDocument = ownerDocument;
    this.tagName = String(tagName || '').toUpperCase();
    this.nodeName = this.tagName;
    this.parentNode = null;
    this.childNodes = [];
    this.attributes = {};
    this.style = {};
    this.__listeners = {};
    this.value = '';
    this.type = '';
    this.disabled = false;
    this.checked = false;
    this.selected = false;
  }

  appendChild(node) {
    return this.insertBefore(node, null);
  }

  insertBefore(node, referenceNode) {
    if (node.parentNode) {
      node.parentNode.removeChild(node);
    }
    const list = this.childNodes;
    const index = referenceNode ? list.indexOf(referenceNode) : -1;
    if (index >= 0) {
      list.splice(index, 0, node);
    } else {
      list.push(node);
    }
    node.parentNode = this;
    return node;
  }

  replaceChild(newChild, oldChild) {
    const index = this.childNodes.indexOf(oldChild);
    if (index === -1) {
      throw new Error('Old child not found.');
    }
    if (newChild.parentNode) {
      newChild.parentNode.removeChild(newChild);
    }
    this.childNodes[index] = newChild;
    newChild.parentNode = this;
    oldChild.parentNode = null;
    return oldChild;
  }

  removeChild(node) {
    const index = this.childNodes.indexOf(node);
    if (index === -1) {
      throw new Error('Child not found.');
    }
    this.childNodes.splice(index, 1);
    node.parentNode = null;
    return node;
  }

  setAttribute(name, value) {
    this.attributes[name] = String(value);
  }

  removeAttribute(name) {
    delete this.attributes[name];
  }

  addEventListener(name, handler) {
    this.__listeners[name] = this.__listeners[name] || [];
    this.__listeners[name].push(handler);
  }

  removeEventListener(name, handler) {
    const list = this.__listeners[name] || [];
    const index = list.indexOf(handler);
    if (index >= 0) {
      list.splice(index, 1);
    }
  }

  emit(name, event) {
    const list = (this.__listeners[name] || []).slice();
    for (const handler of list) {
      handler.call(this, event || { target: this, currentTarget: this });
    }
  }
}

class TextNode {
  constructor(text, ownerDocument) {
    this.nodeType = 3;
    this.ownerDocument = ownerDocument;
    this.parentNode = null;
    this.nodeName = '#text';
    this.nodeValue = String(text);
  }
}

class DocumentStub {
  createElement(tagName) {
    return new ElementNode(tagName, this);
  }

  createElementNS(_namespace, tagName) {
    return new ElementNode(tagName, this);
  }

  createTextNode(text) {
    return new TextNode(text, this);
  }
}

function createRuntime() {
  const document = new DocumentStub();
  const context = {
    console,
    document,
    setTimeout,
    clearTimeout
  };
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(reactLiteCode, context);
  vm.runInContext(reactDomLiteCode, context);
  return context;
}

function collectText(node) {
  if (!node) {
    return '';
  }
  if (node.nodeType === 3) {
    return node.nodeValue;
  }
  return node.childNodes.map(collectText).join('');
}

test('bundled React-lite runtime renders controlled inputs and updates state', async function () {
  const context = createRuntime();
  const React = context.React;
  const ReactDOM = context.ReactDOM;
  const container = context.document.createElement('div');

  function App() {
    const state = React.useState('1000');
    const amount = state[0];
    const setAmount = state[1];
    return React.createElement('div', { className: 'app-root' },
      React.createElement('input', {
        value: amount,
        onChange: function (event) {
          setAmount(event.target.value);
        }
      }),
      React.createElement('span', null, amount)
    );
  }

  ReactDOM.createRoot(container).render(React.createElement(App));
  const shell = container.childNodes[0];
  const input = shell.childNodes[0];
  const output = shell.childNodes[1];

  assert.equal(input.value, '1000');
  assert.equal(collectText(output), '1000');

  input.value = '2500';
  input.emit('input', { target: input, currentTarget: input });
  await new Promise((resolve) => setTimeout(resolve, 5));

  const rerenderedShell = container.childNodes[0];
  const rerenderedInput = rerenderedShell.childNodes[0];
  const rerenderedOutput = rerenderedShell.childNodes[1];

  assert.equal(rerenderedInput, input);
  assert.equal(rerenderedInput.value, '2500');
  assert.equal(collectText(rerenderedOutput), '2500');
});

test('bundled React-lite runtime runs effects and cleans them up on rerender and unmount', async function () {
  const context = createRuntime();
  const React = context.React;
  const ReactDOM = context.ReactDOM;
  const container = context.document.createElement('div');
  const log = [];
  const root = ReactDOM.createRoot(container);

  function App(props) {
    React.useEffect(function () {
      log.push('effect:' + props.label);
      return function () {
        log.push('cleanup:' + props.label);
      };
    }, [props.label]);
    return React.createElement('div', null, props.label);
  }

  root.render(React.createElement(App, { label: 'A' }));
  await new Promise((resolve) => setTimeout(resolve, 5));
  root.render(React.createElement(App, { label: 'B' }));
  await new Promise((resolve) => setTimeout(resolve, 5));
  root.render(null);
  await new Promise((resolve) => setTimeout(resolve, 5));

  assert.deepEqual(log, ['effect:A', 'cleanup:A', 'effect:B', 'cleanup:B']);
});
