const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');

function read(file) {
  return fs.readFileSync(path.join(root, file), 'utf8');
}

test('all multipage HTML files link the manifest, load bundled dependencies, load the PWA script, and declare the correct page name', function () {
  const pages = {
    'index.html': 'home',
    'loans.html': 'loans',
    'insights.html': 'insights',
    'settings.html': 'settings',
    'form.html': 'form',
    'loan.html': 'loan',
    'calculator.html': 'calculator'
  };

  Object.entries(pages).forEach(([file, pageName]) => {
    const html = read(file);
    assert.match(html, /manifest\.webmanifest/);
    assert.match(html, /vendor\/react-lite\.js/);
    assert.match(html, /vendor\/react-dom-lite\.js/);
    assert.match(html, /src\/pwa\.js/);
    assert.match(html, new RegExp('data-page="' + pageName + '"'));
  });
});

test('service worker caches all local app shell pages, scripts, and icons', function () {
  const sw = read('service-worker.js');
  [
    './index.html',
    './loans.html',
    './insights.html',
    './settings.html',
    './form.html',
    './loan.html',
    './calculator.html',
    './src/loans-page.js',
    './src/insights-page.js',
    './src/settings-page.js',
    './assets/icons/icon-192.png'
  ].forEach((snippet) => {
    assert.match(sw, new RegExp(snippet.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  });
  assert.doesNotMatch(sw.split('const APP_SHELL =')[1], /cdnjs\.cloudflare\.com/);
});

test('pwa runtime exposes install and notification helpers and warms key pages', function () {
  const pwa = read('src/pwa.js');
  assert.match(pwa, /warmRuntimeCache/);
  assert.match(pwa, /requestNotificationPermission/);
  assert.match(pwa, /sendDueNotifications/);
  assert.match(pwa, /triggerTestNotification/);
  assert.match(pwa, /\.\/insights\.html/);
  assert.match(pwa, /\.\/settings\.html/);
  assert.match(pwa, /\.\/vendor\/react-lite\.js/);
  assert.match(pwa, /\.\/vendor\/react-dom-lite\.js/);
});

test('page bootstrapping script knows every multipage entry point', function () {
  const boot = read('src/boot.js');
  ['home:', 'loans:', 'insights:', 'settings:', 'form:', 'loan:', 'calculator:'].forEach((snippet) => {
    assert.match(boot, new RegExp(snippet.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  });
});

test('headers disable caching for service worker and manifest refresh', function () {
  const headers = read('_headers');
  assert.match(headers, /\/service-worker\.js/);
  assert.match(headers, /Cache-Control: no-cache/);
  assert.match(headers, /\/manifest\.webmanifest/);
});

test('styles include bottom navigation, light theme support, and smooth transitions', function () {
  const css = read('styles.css');
  assert.match(css, /html\[data-theme='light'\]/);
  assert.match(css, /\.bottom-nav/);
  assert.match(css, /@view-transition/);
});
