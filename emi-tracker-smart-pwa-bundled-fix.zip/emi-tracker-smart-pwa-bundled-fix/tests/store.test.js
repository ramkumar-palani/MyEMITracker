const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const storePath = path.join(__dirname, '../src/store.js');

function createLocalStorage() {
  const data = new Map();
  return {
    getItem(key) {
      return data.has(key) ? data.get(key) : null;
    },
    setItem(key, value) {
      data.set(key, String(value));
    },
    removeItem(key) {
      data.delete(key);
    }
  };
}

function loadStoreWithStorage(storage) {
  global.localStorage = storage;
  delete require.cache[require.resolve(storePath)];
  return require(storePath);
}

test('upsertLoan persists and returns a normalized loan with strategy and tracking fields', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  const saved = Store.upsertLoan({
    name: 'Test Loan',
    lender: 'Test Bank',
    principal: 100000,
    annualRate: 10,
    originalTenureMonths: 24,
    startDate: '2025-01-01',
    monthlyExtraOverrides: [{ date: '2025-03-01', amount: 0 }],
    actualPayments: [{ date: '2025-01-01', amount: 5200, paidOn: '2025-01-02', note: 'Paid' }],
    priorityRank: 2,
    prepaymentMode: 'reduceEmi'
  });

  assert.ok(saved.id);
  assert.equal(saved.name, 'Test Loan');
  assert.equal(saved.priorityRank, 2);
  assert.equal(saved.prepaymentMode, 'reduceEmi');
  assert.equal(saved.actualPayments.length, 1);
  assert.equal(saved.monthlyExtraOverrides.length, 1);
  assert.equal(Store.getLoans().length, 1);
  assert.equal(Store.getLoanById(saved.id).principal, 100000);
});

test('deleteLoan removes the loan from storage', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  const saved = Store.upsertLoan({
    name: 'Delete Me',
    principal: 80000,
    annualRate: 9,
    originalTenureMonths: 12,
    startDate: '2025-01-01'
  });

  Store.deleteLoan(saved.id);
  assert.equal(Store.getLoans().length, 0);
  assert.equal(Store.getLoanById(saved.id), null);
});

test('seedSampleLoans creates rich example loans with priorities, overrides, and actual payments', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  const seeded = Store.seedSampleLoans();

  assert.equal(seeded.length, 3);
  assert.ok(Array.isArray(seeded[0].monthlyExtraOverrides));
  assert.ok(seeded[0].monthlyExtraOverrides.length >= 1);
  assert.ok(seeded.some((loan) => Array.isArray(loan.actualPayments) && loan.actualPayments.length >= 1));
  assert.ok(seeded.some((loan) => loan.prepaymentMode === 'reduceEmi'));
  assert.ok(seeded.every((loan) => typeof loan.priorityRank === 'number'));
});

test('currency settings are stored and retrieved', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);

  Store.setCurrency('USD');
  assert.equal(Store.getCurrency(), 'USD');
  assert.equal(Store.getSettings().currency, 'USD');
});

test('theme and reminder settings are stored and reminder days are clamped', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);

  Store.setTheme('light');
  Store.setReminderSettings({ remindersEnabled: true, reminderDaysBefore: 30 });

  assert.equal(Store.getTheme(), 'light');
  assert.deepEqual(Store.getReminderSettings(), {
    remindersEnabled: true,
    reminderDaysBefore: 14
  });
});

test('setSettings ignores unsupported currency and theme values', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);

  Store.setSettings({ currency: 'INR', theme: 'dark', remindersEnabled: false, reminderDaysBefore: 3 });
  Store.setSettings({ currency: 'XYZ', theme: 'neon', remindersEnabled: true, reminderDaysBefore: 0 });

  assert.deepEqual(Store.getSettings(), {
    currency: 'INR',
    theme: 'dark',
    remindersEnabled: true,
    reminderDaysBefore: 1
  });
});
