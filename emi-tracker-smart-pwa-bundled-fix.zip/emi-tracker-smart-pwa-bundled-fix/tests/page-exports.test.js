const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const Calculator = require('../src/loan-calculator.js');
const storePath = path.join(__dirname, '../src/store.js');
const commonCode = fs.readFileSync(path.join(__dirname, '../src/common.js'), 'utf8');
const homeCode = fs.readFileSync(path.join(__dirname, '../src/home-page.js'), 'utf8');
const loansCode = fs.readFileSync(path.join(__dirname, '../src/loans-page.js'), 'utf8');
const insightsCode = fs.readFileSync(path.join(__dirname, '../src/insights-page.js'), 'utf8');
const settingsCode = fs.readFileSync(path.join(__dirname, '../src/settings-page.js'), 'utf8');
const formCode = fs.readFileSync(path.join(__dirname, '../src/form-page.js'), 'utf8');
const loanCode = fs.readFileSync(path.join(__dirname, '../src/loan-page.js'), 'utf8');
const calculatorCode = fs.readFileSync(path.join(__dirname, '../src/calculator-page.js'), 'utf8');

function createReactStub() {
  return {
    Fragment: Symbol('Fragment'),
    createElement(type, props, ...children) {
      return { type, props: props || {}, children };
    },
    useEffect(effect) {
      if (typeof effect === 'function') {
        effect();
      }
    },
    useMemo(factory) {
      return factory();
    },
    useState(initialValue) {
      const value = typeof initialValue === 'function' ? initialValue() : initialValue;
      return [value, function noop() {}];
    },
    useRef(initialValue) {
      return { current: initialValue };
    }
  };
}

function createLocalStorage() {
  const data = new Map();
  return {
    getItem(key) {
      return data.has(key) ? data.get(key) : null;
    },
    setItem(key, value) {
      data.set(key, String(value));
    }
  };
}

function loadStoreWithStorage(storage) {
  global.localStorage = storage;
  delete require.cache[require.resolve(storePath)];
  return require(storePath);
}

function createDocumentStub(pageName) {
  return {
    documentElement: {
      setAttribute() {}
    },
    querySelector() {
      return null;
    },
    createElement() {
      return {
        click() {},
        remove() {},
        setAttribute() {},
        style: {}
      };
    },
    getElementById() {
      return null;
    },
    body: {
      appendChild() {},
      getAttribute(name) {
        return name === 'data-page' ? pageName : '';
      }
    }
  };
}

function createContext({ search, Store, pageName }) {
  const document = createDocumentStub(pageName || 'home');
  const context = {
    console,
    React: createReactStub(),
    EmiTrackerCalculator: Calculator,
    EmiTrackerStore: Store,
    localStorage: global.localStorage,
    crypto: {
      randomUUID() {
        return 'test-id';
      }
    },
    confirm() {
      return true;
    },
    Notification: undefined,
    navigator: {
      serviceWorker: {}
    },
    location: {
      href: 'https://example.com/index.html' + (search || ''),
      search: search || ''
    },
    URL,
    URLSearchParams,
    Blob,
    document,
    setTimeout,
    clearTimeout,
    addEventListener() {},
    removeEventListener() {}
  };
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(commonCode, context);
  vm.runInContext(homeCode, context);
  vm.runInContext(loansCode, context);
  vm.runInContext(insightsCode, context);
  vm.runInContext(settingsCode, context);
  vm.runInContext(formCode, context);
  vm.runInContext(loanCode, context);
  vm.runInContext(calculatorCode, context);
  return context;
}

function seedLoan(Store) {
  return Store.upsertLoan({
    id: 'loan-1',
    name: 'Seed Loan',
    lender: 'Seed Bank',
    principal: 500000,
    annualRate: 9,
    originalTenureMonths: 60,
    startDate: '2025-01-01',
    monthlyPayment: 0,
    monthlyExtraPayment: 1500,
    extraPayments: [{ date: '2025-03-01', amount: 25000 }],
    monthlyExtraOverrides: [{ date: '2025-06-01', amount: 0 }],
    actualPayments: [{ date: '2025-01-01', amount: 12000, paidOn: '2025-01-02', note: 'Paid' }],
    priorityRank: 1,
    prepaymentMode: 'reduceEmi'
  });
}

test('Common helpers support CSV generation and relative page URLs', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  const context = createContext({ search: '', Store, pageName: 'home' });

  const csv = context.EmiTrackerCommon.buildCsvContent([
    { loan: 'Home Loan', note: 'Paid, on time' }
  ], [
    { key: 'loan', label: 'Loan' },
    { key: 'note', label: 'Note' }
  ]);

  assert.match(csv, /^Loan,Note/);
  assert.match(csv, /"Paid, on time"/);
  assert.equal(context.EmiTrackerCommon.buildUrl('loan.html', { id: 'loan-1' }), './loan.html?id=loan-1');
});

test('HomePage renders with stored loans', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '', Store, pageName: 'home' });

  assert.ok(context.EmiTrackerHomePage);
  assert.equal(typeof context.EmiTrackerHomePage.HomePage, 'function');
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerHomePage.HomePage();
    assert.ok(tree);
  });
});

test('LoansPage renders a loan list view', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '', Store, pageName: 'loans' });

  assert.ok(context.EmiTrackerLoansPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerLoansPage.LoansPage();
    assert.ok(tree);
  });
});

test('InsightsPage renders strategy and assistant sections', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  Store.upsertLoan({
    id: 'loan-2',
    name: 'Personal Loan',
    principal: 150000,
    annualRate: 15,
    originalTenureMonths: 24,
    startDate: '2025-01-01'
  });
  const context = createContext({ search: '', Store, pageName: 'insights' });

  assert.ok(context.EmiTrackerInsightsPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerInsightsPage.InsightsPage();
    assert.ok(tree);
  });
});

test('SettingsPage renders currency, theme, reminders, and export sections', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '', Store, pageName: 'settings' });

  assert.ok(context.EmiTrackerSettingsPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerSettingsPage.SettingsPage();
    assert.ok(tree);
  });
});

test('FormPage renders in edit mode', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '?id=loan-1', Store, pageName: 'form' });

  assert.ok(context.EmiTrackerFormPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerFormPage.FormPage();
    assert.ok(tree);
  });
});

test('LoanPage renders a saved loan detail view with tracker and planner', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '?id=loan-1', Store, pageName: 'loan' });

  assert.ok(context.EmiTrackerLoanPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerLoanPage.LoanPage();
    assert.ok(tree);
  });
});

test('CalculatorPage renders advanced EMI tabs when loaded from an existing loan', function () {
  const storage = createLocalStorage();
  const Store = loadStoreWithStorage(storage);
  seedLoan(Store);
  const context = createContext({ search: '?loanId=loan-1', Store, pageName: 'calculator' });

  assert.ok(context.EmiTrackerCalculatorPage);
  assert.doesNotThrow(function () {
    const tree = context.EmiTrackerCalculatorPage.CalculatorPage();
    assert.ok(tree);
  });
});
