const test = require('node:test');
const assert = require('node:assert/strict');
const Calculator = require('../src/loan-calculator.js');

function approxEqual(actual, expected, tolerance, message) {
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    message + ' (expected ' + expected + ', received ' + actual + ')'
  );
}

function buildLoan(overrides) {
  return Object.assign({
    principal: 1000000,
    annualRate: 10,
    originalTenureMonths: 120,
    startDate: '2025-01-01',
    monthlyPayment: 0,
    monthlyExtraPayment: 0,
    monthlyExtraOverrides: [],
    extraPayments: [],
    rateChanges: [],
    offsetBalance: 0,
    offsetBalanceChanges: [],
    actualPayments: [],
    prepaymentMode: 'reduceTenure',
    priorityRank: 0
  }, overrides || {});
}

test('calculateEmi returns the expected EMI for a standard reducing-balance loan', function () {
  const emi = Calculator.calculateEmi(1000000, 10, 120);
  approxEqual(emi, 13215.07, 0.01, 'EMI should match the known repayment amount');
});

test('auto EMI schedule pays off within the original tenure', function () {
  const result = Calculator.createAmortizationSchedule(buildLoan());

  assert.equal(result.rows.length, 120);
  assert.equal(result.payoffDate, '2034-12-01');
  assert.equal(result.rows[result.rows.length - 1].closingBalance, 0);
});

test('recurring extra payments reduce both tenure and total interest', function () {
  const baseline = Calculator.buildLoanSnapshot(buildLoan(), '2024-12-01');
  const accelerated = Calculator.buildLoanSnapshot(buildLoan({ monthlyExtraPayment: 5000 }), '2024-12-01');

  assert.ok(accelerated.schedule.length < baseline.schedule.length);
  assert.ok(accelerated.projectedTotalInterest < baseline.projectedTotalInterest);
  assert.equal(accelerated.monthsSaved, 46);
  approxEqual(accelerated.interestSaved, 243475.52, 0.1, 'Interest saved should reflect the extra payments');
});

test('one-time extra payments are included in the matching repayment month', function () {
  const snapshot = Calculator.buildLoanSnapshot(buildLoan({
    principal: 500000,
    annualRate: 9,
    originalTenureMonths: 60,
    startDate: '2025-01-15',
    monthlyExtraPayment: 1000,
    extraPayments: [
      { date: '2025-03-01', amount: 25000 }
    ]
  }), '2024-12-15');

  const marchRow = snapshot.schedule.find((row) => row.paymentDate === '2025-03-15');
  assert.ok(marchRow, 'March installment should exist');
  approxEqual(marchRow.extraPayment, 26000, 0.01, 'March should include the recurring and one-time extra payment');
});

test('month-wise extra overrides replace the default extra amount for that month', function () {
  const snapshot = Calculator.buildLoanSnapshot(buildLoan({
    principal: 500000,
    annualRate: 10,
    originalTenureMonths: 60,
    monthlyExtraPayment: 5000,
    monthlyExtraOverrides: [
      { date: '2025-03-01', amount: 0 }
    ]
  }), '2024-12-01');

  const marchRow = snapshot.schedule.find((row) => row.paymentDate === '2025-03-01');
  assert.equal(marchRow.recurringExtra, 0);
  assert.equal(marchRow.extraPayment, 0);
  assert.equal(snapshot.schedule[0].recurringExtra, 5000);
});

test('actual payment logs override the planned payment for the matching month', function () {
  const loan = buildLoan({
    principal: 300000,
    annualRate: 12,
    originalTenureMonths: 36,
    actualPayments: [
      { date: '2025-01-01', amount: 5000, paidOn: '2025-01-03', note: 'Partial' }
    ]
  });
  const snapshot = Calculator.buildLoanSnapshot(loan, '2025-02-01');
  const firstRow = snapshot.schedule[0];
  const baseline = Calculator.buildLoanSnapshot(buildLoan({
    principal: 300000,
    annualRate: 12,
    originalTenureMonths: 36
  }), '2025-02-01');

  assert.equal(firstRow.isActualPayment, true);
  assert.equal(firstRow.totalPayment, 5000);
  assert.equal(firstRow.loggedPayment, 5000);
  assert.equal(firstRow.paidOn, '2025-01-03');
  assert.equal(firstRow.note, 'Partial');
  assert.equal(snapshot.hasActualTracking, true);
  assert.equal(snapshot.actualPaymentCount, 1);
  assert.ok(snapshot.remainingBalance > baseline.remainingBalance);
});

test('reduce-EMI mode lowers future scheduled payment after prepayments', function () {
  const reduced = Calculator.buildLoanSnapshot(buildLoan({
    principal: 800000,
    annualRate: 9,
    originalTenureMonths: 96,
    monthlyExtraPayment: 7000,
    prepaymentMode: 'reduceEmi'
  }), '2024-12-01');

  assert.equal(reduced.schedule[0].prepaymentMode, 'reduceEmi');
  assert.ok(reduced.schedule[1].scheduledPaymentTarget < reduced.schedule[0].scheduledPaymentTarget);
  assert.ok(reduced.minimumScheduledPayment < reduced.scheduledPayment);
});

test('rate changes apply from the matching month onward', function () {
  const baseline = Calculator.buildLoanSnapshot(buildLoan({ annualRate: 8 }), '2024-12-01');
  const changed = Calculator.buildLoanSnapshot(buildLoan({
    annualRate: 8,
    rateChanges: [
      { date: '2025-07-01', annualRate: 10 }
    ]
  }), '2024-12-01');

  assert.deepEqual(changed.schedule.slice(0, 8).map((row) => row.annualRate), [8, 8, 8, 8, 8, 8, 10, 10]);
  assert.ok(changed.projectedTotalInterest > baseline.projectedTotalInterest);
  assert.ok(changed.schedule.length > baseline.schedule.length);
});

test('offset balance reduces interest and shortens tenure', function () {
  const withoutOffset = Calculator.buildLoanSnapshot(buildLoan({
    principal: 600000,
    annualRate: 9,
    offsetBalance: 0
  }), '2024-12-01');

  const withOffset = Calculator.buildLoanSnapshot(buildLoan({
    principal: 600000,
    annualRate: 9,
    offsetBalance: 100000
  }), '2024-12-01');

  assert.ok(withOffset.projectedTotalInterest < withoutOffset.projectedTotalInterest);
  assert.ok(withOffset.schedule.length < withoutOffset.schedule.length);
  assert.equal(withOffset.schedule[0].interestBase, 500000);
  assert.ok(withOffset.schedule[0].accruedInterest < withoutOffset.schedule[0].accruedInterest);
});

test('negative amortization is flagged when payment does not cover interest', function () {
  const snapshot = Calculator.buildLoanSnapshot(buildLoan({
    principal: 100000,
    annualRate: 24,
    originalTenureMonths: 24,
    monthlyPayment: 100
  }), '2025-01-01');

  assert.equal(snapshot.hasNegativeAmortization, true);
});

test('strategy plan chooses the highest rate loan first', function () {
  const plan = Calculator.buildStrategyPlan([
    buildLoan({ id: 'loan-a', name: 'Home', annualRate: 8.5, principal: 3000000 }),
    buildLoan({ id: 'loan-b', name: 'Personal', annualRate: 15.5, principal: 250000, originalTenureMonths: 36 })
  ], {
    strategy: 'highestRate',
    extraBudget: 5000,
    asOfDate: '2024-12-01'
  });

  assert.equal(plan.target.name, 'Personal');
  assert.equal(plan.order[0].name, 'Personal');
  assert.equal(plan.reason, 'Highest active interest rate');
});

test('strategy plan honors custom priority rank', function () {
  const plan = Calculator.buildStrategyPlan([
    buildLoan({ id: 'loan-a', name: 'Home', annualRate: 8.5, principal: 3000000, priorityRank: 3 }),
    buildLoan({ id: 'loan-b', name: 'Car', annualRate: 11, principal: 700000, originalTenureMonths: 60, priorityRank: 1 }),
    buildLoan({ id: 'loan-c', name: 'Personal', annualRate: 15.5, principal: 250000, originalTenureMonths: 36, priorityRank: 2 })
  ], {
    strategy: 'customPriority',
    extraBudget: 5000,
    asOfDate: '2024-12-01'
  });

  assert.equal(plan.target.name, 'Car');
  assert.deepEqual(plan.order.map((item) => item.name), ['Car', 'Personal', 'Home']);
});

test('findRequiredMonthlyPayment reaches the requested target tenure', function () {
  const targetMonths = 48;
  const loan = buildLoan({
    principal: 750000,
    annualRate: 10,
    originalTenureMonths: 120,
    monthlyExtraPayment: 2000
  });
  const requiredPayment = Calculator.findRequiredMonthlyPayment(loan, targetMonths);
  const schedule = Calculator.createAmortizationSchedule(Object.assign({}, loan, {
    monthlyPayment: requiredPayment
  }));

  assert.ok(requiredPayment > Calculator.calculateEmi(loan.principal, loan.annualRate, loan.originalTenureMonths));
  assert.ok(schedule.rows.length <= targetMonths);
});

test('calculateTenureMonths falls as monthly payment increases', function () {
  const slower = Calculator.calculateTenureMonths(500000, 9, 8000);
  const faster = Calculator.calculateTenureMonths(500000, 9, 12000);

  assert.ok(faster < slower);
  assert.ok(faster > 0);
});
