const APP_CACHE = 'emi-tracker-modern-app-v3';
const RUNTIME_CACHE = 'emi-tracker-runtime-v3';
const APP_SHELL = [
  './',
  './index.html',
  './loans.html',
  './insights.html',
  './settings.html',
  './form.html',
  './loan.html',
  './calculator.html',
  './styles.css',
  './vendor/react-lite.js',
  './vendor/react-dom-lite.js',
  './src/loan-calculator.js',
  './src/store.js',
  './src/common.js',
  './src/home-page.js',
  './src/loans-page.js',
  './src/insights-page.js',
  './src/settings-page.js',
  './src/form-page.js',
  './src/loan-page.js',
  './src/calculator-page.js',
  './src/boot.js',
  './src/pwa.js',
  './manifest.webmanifest',
  './offline.html',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(APP_CACHE)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((key) => key !== APP_CACHE && key !== RUNTIME_CACHE).map((key) => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;

  if (request.method !== 'GET') {
    return;
  }

  if (request.cache === 'only-if-cached' && request.mode !== 'same-origin') {
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
          return response;
        })
        .catch(async () => {
          const cached = await caches.match(request);
          if (cached) {
            return cached;
          }
          const requestUrl = new URL(request.url);
          const pathname = requestUrl.pathname;
          if (pathname.endsWith('/loan.html')) {
            return caches.match('./loan.html') || caches.match('./offline.html');
          }
          if (pathname.endsWith('/form.html')) {
            return caches.match('./form.html') || caches.match('./offline.html');
          }
          if (pathname.endsWith('/calculator.html')) {
            return caches.match('./calculator.html') || caches.match('./offline.html');
          }
          if (pathname.endsWith('/loans.html')) {
            return caches.match('./loans.html') || caches.match('./offline.html');
          }
          if (pathname.endsWith('/insights.html')) {
            return caches.match('./insights.html') || caches.match('./offline.html');
          }
          if (pathname.endsWith('/settings.html')) {
            return caches.match('./settings.html') || caches.match('./offline.html');
          }
          return caches.match('./index.html') || caches.match('./offline.html');
        })
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) {
        return cached;
      }
      return fetch(request)
        .then((response) => {
          if (!response) {
            return response;
          }
          const copy = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy)).catch(() => {});
          return response;
        })
        .catch(() => caches.match(request));
    })
  );
});
