(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./loan-calculator.js'));
  } else {
    root.EmiTrackerStore = factory(root.EmiTrackerCalculator);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (Calculator) {
  'use strict';

  var runtimeRoot = typeof globalThis !== 'undefined' ? globalThis : {};
  var LOANS_KEY = 'emi-tracker-modern-pwa.loans.v1';
  var SETTINGS_KEY = 'emi-tracker-modern-pwa.settings.v1';
  var DEFAULT_CURRENCY = 'INR';
  var DEFAULT_THEME = 'dark';
  var DEFAULT_REMINDER_DAYS = 3;
  var CURRENCY_OPTIONS = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'AUD'];
  var THEME_OPTIONS = ['dark', 'light'];

  function safeReadJson(storage, key, fallback) {
    try {
      var raw = storage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function safeWriteJson(storage, key, value) {
    try {
      storage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  function getStorage() {
    if (runtimeRoot && runtimeRoot.localStorage) {
      return runtimeRoot.localStorage;
    }
    return {
      getItem: function () { return null; },
      setItem: function () {}
    };
  }

  function createId() {
    if (runtimeRoot && runtimeRoot.crypto && typeof runtimeRoot.crypto.randomUUID === 'function') {
      return runtimeRoot.crypto.randomUUID();
    }
    return 'loan-' + Date.now() + '-' + Math.random().toString(36).slice(2, 9);
  }

  function nowIso() {
    return Calculator && Calculator.toIsoDate ? Calculator.toIsoDate(new Date()) : new Date().toISOString().slice(0, 10);
  }

  function clampReminderDays(value) {
    var parsed = Number(value);
    if (!Number.isFinite(parsed)) {
      return DEFAULT_REMINDER_DAYS;
    }
    return Math.max(1, Math.min(14, Math.round(parsed)));
  }

  function normalizePersistedLoan(rawLoan) {
    var normalized = Calculator.normalizeLoan(rawLoan || {});
    normalized.id = normalized.id || createId();
    normalized.createdAt = rawLoan && rawLoan.createdAt ? String(rawLoan.createdAt) : normalized.createdAt || nowIso();
    normalized.updatedAt = rawLoan && rawLoan.updatedAt ? String(rawLoan.updatedAt) : normalized.updatedAt || nowIso();
    return normalized;
  }

  function getLoans() {
    var storage = getStorage();
    var raw = safeReadJson(storage, LOANS_KEY, []);
    return (Array.isArray(raw) ? raw : []).map(normalizePersistedLoan).sort(function (left, right) {
      return String(left.createdAt || '').localeCompare(String(right.createdAt || ''));
    });
  }

  function saveLoans(loans) {
    var storage = getStorage();
    var normalized = (Array.isArray(loans) ? loans : []).map(normalizePersistedLoan);
    safeWriteJson(storage, LOANS_KEY, normalized);
    return normalized;
  }

  function getLoanById(id) {
    var targetId = String(id || '');
    var loans = getLoans();
    for (var index = 0; index < loans.length; index += 1) {
      if (loans[index].id === targetId) {
        return loans[index];
      }
    }
    return null;
  }

  function upsertLoan(loanInput) {
    var storage = getStorage();
    var loans = getLoans();
    var normalized = normalizePersistedLoan(loanInput || {});
    normalized.id = normalized.id || createId();
    normalized.updatedAt = nowIso();

    var replaced = false;
    var nextLoans = loans.map(function (loan) {
      if (loan.id !== normalized.id) {
        return loan;
      }
      replaced = true;
      normalized.createdAt = loan.createdAt || normalized.createdAt || nowIso();
      return normalized;
    });

    if (!replaced) {
      normalized.createdAt = normalized.createdAt || nowIso();
      nextLoans.push(normalized);
    }

    safeWriteJson(storage, LOANS_KEY, nextLoans);
    return normalized;
  }

  function deleteLoan(id) {
    var storage = getStorage();
    var targetId = String(id || '');
    var nextLoans = getLoans().filter(function (loan) {
      return loan.id !== targetId;
    });
    safeWriteJson(storage, LOANS_KEY, nextLoans);
    return nextLoans;
  }

  function clearLoans() {
    var storage = getStorage();
    safeWriteJson(storage, LOANS_KEY, []);
    return [];
  }

  function getSettings() {
    var storage = getStorage();
    var stored = safeReadJson(storage, SETTINGS_KEY, {});
    return {
      currency: CURRENCY_OPTIONS.indexOf(stored.currency) >= 0 ? stored.currency : DEFAULT_CURRENCY,
      theme: THEME_OPTIONS.indexOf(stored.theme) >= 0 ? stored.theme : DEFAULT_THEME,
      remindersEnabled: !!stored.remindersEnabled,
      reminderDaysBefore: clampReminderDays(stored.reminderDaysBefore)
    };
  }

  function setSettings(partialSettings) {
    var storage = getStorage();
    var current = getSettings();
    var nextSettings = {
      currency: CURRENCY_OPTIONS.indexOf(partialSettings && partialSettings.currency) >= 0
        ? partialSettings.currency
        : current.currency,
      theme: THEME_OPTIONS.indexOf(partialSettings && partialSettings.theme) >= 0
        ? partialSettings.theme
        : current.theme,
      remindersEnabled: partialSettings && partialSettings.remindersEnabled !== undefined
        ? !!partialSettings.remindersEnabled
        : current.remindersEnabled,
      reminderDaysBefore: partialSettings && partialSettings.reminderDaysBefore !== undefined
        ? clampReminderDays(partialSettings.reminderDaysBefore)
        : current.reminderDaysBefore
    };
    safeWriteJson(storage, SETTINGS_KEY, nextSettings);
    return nextSettings;
  }

  function getCurrency() {
    return getSettings().currency;
  }

  function setCurrency(currency) {
    return setSettings({ currency: currency }).currency;
  }

  function getTheme() {
    return getSettings().theme;
  }

  function setTheme(theme) {
    return setSettings({ theme: theme }).theme;
  }

  function getReminderSettings() {
    var settings = getSettings();
    return {
      remindersEnabled: settings.remindersEnabled,
      reminderDaysBefore: settings.reminderDaysBefore
    };
  }

  function setReminderSettings(partialReminderSettings) {
    var current = getReminderSettings();
    return setSettings({
      remindersEnabled: partialReminderSettings && partialReminderSettings.remindersEnabled !== undefined
        ? partialReminderSettings.remindersEnabled
        : current.remindersEnabled,
      reminderDaysBefore: partialReminderSettings && partialReminderSettings.reminderDaysBefore !== undefined
        ? partialReminderSettings.reminderDaysBefore
        : current.reminderDaysBefore
    });
  }

  function seedSampleLoans() {
    var today = nowIso();
    var lastMonth = Calculator.toIsoDate(Calculator.addMonths(today, -1));
    var loans = [
      normalizePersistedLoan({
        id: createId(),
        name: 'Home Loan',
        lender: 'Sample Bank',
        principal: 3500000,
        annualRate: 8.9,
        originalTenureMonths: 240,
        startDate: Calculator.toIsoDate(Calculator.addMonths(today, -6)),
        monthlyPayment: 0,
        monthlyExtraPayment: 5000,
        monthlyExtraOverrides: [
          { date: Calculator.toIsoDate(Calculator.addMonths(today, 1)), amount: 10000 },
          { date: Calculator.toIsoDate(Calculator.addMonths(today, 2)), amount: 0 }
        ],
        extraPayments: [
          { date: Calculator.toIsoDate(Calculator.addMonths(today, 5)), amount: 25000 }
        ],
        actualPayments: [
          { date: lastMonth, amount: 36500, paidOn: lastMonth, note: 'Paid via bank transfer' }
        ],
        priorityRank: 2,
        prepaymentMode: 'reduceTenure'
      }),
      normalizePersistedLoan({
        id: createId(),
        name: 'Car Loan',
        lender: 'City Finance',
        principal: 800000,
        annualRate: 10.5,
        originalTenureMonths: 72,
        startDate: Calculator.toIsoDate(Calculator.addMonths(today, -3)),
        monthlyPayment: 0,
        monthlyExtraPayment: 1500,
        rateChanges: [
          { date: Calculator.toIsoDate(Calculator.addMonths(today, 12)), annualRate: 9.75 }
        ],
        offsetBalance: 25000,
        priorityRank: 1,
        prepaymentMode: 'reduceTenure'
      }),
      normalizePersistedLoan({
        id: createId(),
        name: 'Personal Loan',
        lender: 'Metro Credit',
        principal: 250000,
        annualRate: 14.2,
        originalTenureMonths: 36,
        startDate: Calculator.toIsoDate(Calculator.addMonths(today, -2)),
        monthlyPayment: 0,
        monthlyExtraPayment: 0,
        actualPayments: [
          { date: Calculator.toIsoDate(Calculator.addMonths(today, -1)), amount: 9000, paidOn: Calculator.toIsoDate(Calculator.addMonths(today, -1)), note: 'Partial payment' }
        ],
        priorityRank: 3,
        prepaymentMode: 'reduceEmi'
      })
    ];
    return saveLoans(loans);
  }

  return {
    LOANS_KEY: LOANS_KEY,
    SETTINGS_KEY: SETTINGS_KEY,
    DEFAULT_CURRENCY: DEFAULT_CURRENCY,
    DEFAULT_THEME: DEFAULT_THEME,
    DEFAULT_REMINDER_DAYS: DEFAULT_REMINDER_DAYS,
    CURRENCY_OPTIONS: CURRENCY_OPTIONS,
    THEME_OPTIONS: THEME_OPTIONS,
    getLoans: getLoans,
    saveLoans: saveLoans,
    getLoanById: getLoanById,
    upsertLoan: upsertLoan,
    deleteLoan: deleteLoan,
    clearLoans: clearLoans,
    getSettings: getSettings,
    setSettings: setSettings,
    getCurrency: getCurrency,
    setCurrency: setCurrency,
    getTheme: getTheme,
    setTheme: setTheme,
    getReminderSettings: getReminderSettings,
    setReminderSettings: setReminderSettings,
    seedSampleLoans: seedSampleLoans,
    createId: createId
  };
});
