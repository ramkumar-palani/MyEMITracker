(function (root, factory) {
  root.EmiTrackerCommon = factory(root.React, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Calculator, Store) {
  'use strict';

  if (!React) {
    return {};
  }

  var runtimeRoot = typeof globalThis !== 'undefined' ? globalThis : {};
  var h = React.createElement;
  var Fragment = React.Fragment;
  var useEffect = React.useEffect;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var useRef = React.useRef;

  function el(type, props) {
    var children = [];
    for (var index = 2; index < arguments.length; index += 1) {
      var child = arguments[index];
      if (Array.isArray(child)) {
        children = children.concat(child.filter(function (item) { return item !== undefined && item !== null && item !== false; }));
      } else if (child !== undefined && child !== null && child !== false) {
        children.push(child);
      }
    }
    return h.apply(null, [type, props].concat(children));
  }

  function classNames() {
    var parts = [];
    for (var index = 0; index < arguments.length; index += 1) {
      var value = arguments[index];
      if (Array.isArray(value)) {
        parts = parts.concat(value.filter(Boolean));
      } else if (value) {
        parts.push(value);
      }
    }
    return parts.join(' ');
  }

  function toNumber(value, fallback) {
    var parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : (fallback !== undefined ? fallback : 0);
  }

  function todayIso() {
    return Calculator.toIsoDate(new Date());
  }

  function formatMoney(amount, currencyCode) {
    var value = Number.isFinite(amount) ? amount : 0;
    var currency = currencyCode || (Store ? Store.getCurrency() : 'INR');
    try {
      return new Intl.NumberFormat(undefined, {
        style: 'currency',
        currency: currency,
        maximumFractionDigits: 2
      }).format(value);
    } catch (error) {
      return value.toFixed(2);
    }
  }

  function formatNumber(value, fractionDigits) {
    return new Intl.NumberFormat(undefined, {
      maximumFractionDigits: fractionDigits === undefined ? 2 : fractionDigits
    }).format(Number.isFinite(value) ? value : 0);
  }

  function formatDate(dateInput) {
    var date = Calculator.parseIsoDate(dateInput);
    if (!date) {
      return '—';
    }
    return new Intl.DateTimeFormat(undefined, {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC'
    }).format(date);
  }

  function formatMonth(dateInput) {
    var date = Calculator.parseIsoDate(dateInput);
    if (!date) {
      return '—';
    }
    return new Intl.DateTimeFormat(undefined, {
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC'
    }).format(date);
  }

  function describeTenure(months) {
    var totalMonths = Math.max(0, Math.round(toNumber(months, 0)));
    var years = Math.floor(totalMonths / 12);
    var remainingMonths = totalMonths % 12;
    var parts = [];
    if (years) {
      parts.push(years + 'y');
    }
    if (remainingMonths) {
      parts.push(remainingMonths + 'm');
    }
    return parts.length ? parts.join(' ') : '0m';
  }

  function splitTermMonths(months) {
    var totalMonths = Math.max(1, Math.round(toNumber(months, 12)));
    if (totalMonths % 12 === 0) {
      return { termValue: String(totalMonths / 12), termUnit: 'years' };
    }
    return { termValue: String(totalMonths), termUnit: 'months' };
  }

  function termToMonths(termValue, termUnit) {
    var value = Math.max(0, Math.round(toNumber(termValue, 0)));
    return termUnit === 'years' ? value * 12 : value;
  }

  function getSearchParam(name) {
    if (!runtimeRoot.location || !runtimeRoot.location.search) {
      return '';
    }
    return new runtimeRoot.URLSearchParams(runtimeRoot.location.search).get(name) || '';
  }

  function buildUrl(page, params) {
    var url = new runtimeRoot.URL(page, runtimeRoot.location && runtimeRoot.location.href ? runtimeRoot.location.href : 'https://example.com/');
    var keys = Object.keys(params || {});
    keys.forEach(function (key) {
      if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
        url.searchParams.set(key, params[key]);
      }
    });
    return url.pathname.replace(/^.*\//, './') + url.search;
  }

  function navigateTo(href) {
    if (!runtimeRoot.location) {
      return;
    }
    runtimeRoot.location.href = href;
  }

  function useFlashMessage(initialMessage) {
    var result = useState(initialMessage || '');
    var message = result[0];
    var setMessage = result[1];

    useEffect(function () {
      if (!message) {
        return undefined;
      }
      var timeout = runtimeRoot.setTimeout(function () {
        setMessage('');
      }, 2800);
      return function () {
        runtimeRoot.clearTimeout(timeout);
      };
    }, [message]);

    return [message, setMessage];
  }

  function getTheme() {
    return Store && typeof Store.getTheme === 'function' ? Store.getTheme() : 'dark';
  }

  function applyTheme(theme) {
    if (!runtimeRoot.document || !runtimeRoot.document.documentElement) {
      return;
    }
    runtimeRoot.document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : 'dark');
    var meta = runtimeRoot.document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', theme === 'light' ? '#f8fafc' : '#0b1020');
    }
  }

  function describeDueDate(dateInput, referenceDateInput) {
    if (!dateInput) {
      return 'No due date';
    }
    var referenceDate = referenceDateInput || todayIso();
    var diff = Calculator.daysBetween(referenceDate, dateInput);
    if (diff === 0) {
      return 'Due today';
    }
    if (diff > 0) {
      if (diff === 1) {
        return 'Due in 1 day';
      }
      return 'Due in ' + diff + ' days';
    }
    if (diff === -1) {
      return '1 day overdue';
    }
    return Math.abs(diff) + ' days overdue';
  }

  function buildCsvContent(rows, columns) {
    var data = Array.isArray(rows) ? rows : [];
    if (!data.length) {
      return '';
    }
    var headers = Array.isArray(columns) && columns.length
      ? columns
      : Object.keys(data[0]).map(function (key) {
          return { key: key, label: key };
        });
    var lines = [];
    lines.push(headers.map(function (column) { return escapeCsvValue(column.label); }).join(','));
    data.forEach(function (row) {
      lines.push(headers.map(function (column) {
        return escapeCsvValue(row[column.key]);
      }).join(','));
    });
    return lines.join('\n');
  }

  function escapeCsvValue(value) {
    var text = value === undefined || value === null ? '' : String(value);
    if (/[",\n]/.test(text)) {
      return '"' + text.replace(/"/g, '""') + '"';
    }
    return text;
  }

  function downloadCsv(filename, rows, columns) {
    if (!runtimeRoot.document || !runtimeRoot.URL || !runtimeRoot.Blob) {
      return false;
    }
    var csv = buildCsvContent(rows, columns);
    var blob = new runtimeRoot.Blob([csv], { type: 'text/csv;charset=utf-8' });
    var objectUrl = runtimeRoot.URL.createObjectURL(blob);
    var anchor = runtimeRoot.document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = filename;
    runtimeRoot.document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    runtimeRoot.URL.revokeObjectURL(objectUrl);
    return true;
  }

  function IconButton(props) {
    return el('a', {
      className: classNames('icon-button', props.className),
      href: props.href || '#',
      'aria-label': props.label || props.children,
      title: props.label || '',
      onClick: props.onClick
    }, props.children || '←');
  }

  function Button(props) {
    var Tag = props.href ? 'a' : 'button';
    var tagProps = {
      className: classNames(
        props.variant === 'ghost' ? 'button button--ghost' : 'button',
        props.small && 'button--small',
        props.block && 'button--block',
        props.className
      ),
      href: props.href,
      type: props.href ? undefined : (props.type || 'button'),
      onClick: props.onClick,
      disabled: props.disabled,
      title: props.title
    };
    return el(Tag, tagProps, props.children);
  }

  function ThemeToggleButton() {
    var state = useState(getTheme());
    var theme = state[0];
    var setTheme = state[1];

    function handleToggle() {
      var nextTheme = theme === 'light' ? 'dark' : 'light';
      setTheme(nextTheme);
      if (Store && typeof Store.setTheme === 'function') {
        Store.setTheme(nextTheme);
      }
      applyTheme(nextTheme);
    }

    return el('button', {
      type: 'button',
      className: 'icon-button',
      title: theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode',
      'aria-label': theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode',
      onClick: handleToggle
    }, theme === 'light' ? '☾' : '☀');
  }

  function BottomNav(props) {
    var currentPage = props.currentPage;
    var items = [
      { key: 'home', label: 'Home', href: './index.html', icon: '⌂' },
      { key: 'loans', label: 'Loans', href: './loans.html', icon: '◎' },
      { key: 'insights', label: 'Insights', href: './insights.html', icon: '◔' },
      { key: 'calculator', label: 'Calc', href: './calculator.html', icon: '◫' },
      { key: 'settings', label: 'Settings', href: './settings.html', icon: '⚙' }
    ];

    return el('nav', { className: 'bottom-nav surface-card', 'aria-label': 'Primary navigation' },
      items.map(function (item) {
        return el('a', {
          key: item.key,
          href: item.href,
          className: classNames('bottom-nav__item', currentPage === item.key && 'bottom-nav__item--active')
        },
          el('span', { className: 'bottom-nav__icon' }, item.icon),
          el('span', { className: 'bottom-nav__label' }, item.label)
        );
      })
    );
  }

  function PageShell(props) {
    return el('div', { className: classNames('page-shell', props.pageClassName) },
      el('header', { className: 'topbar surface-card' },
        el('div', { className: 'topbar__left' },
          props.backHref
            ? el(IconButton, { href: props.backHref, label: 'Go back' }, '←')
            : el('div', { className: 'icon-button icon-button--placeholder', 'aria-hidden': 'true' }, '•'),
          el('div', { className: 'topbar__titles' },
            el('div', { className: 'topbar__eyebrow' }, props.eyebrow || 'EMI Tracker'),
            el('h1', { className: 'page-title', style: props.titleTransitionName ? { viewTransitionName: props.titleTransitionName } : null }, props.title),
            props.subtitle ? el('p', { className: 'page-subtitle' }, props.subtitle) : null
          )
        ),
        el('div', { className: 'topbar__actions' },
          props.actions || null,
          props.currentPage !== 'settings'
            ? el(IconButton, { href: './settings.html', label: 'Open settings' }, '⚙')
            : null,
          el(ThemeToggleButton)
        )
      ),
      props.flashMessage
        ? el('div', { className: 'flash-banner surface-card' }, props.flashMessage)
        : null,
      el('main', { className: 'page-content' }, props.children),
      el(BottomNav, { currentPage: props.currentPage })
    );
  }

  function SectionCard(props) {
    return el('section', {
      className: classNames('section-card surface-card', props.className),
      style: props.style || null
    },
      props.title || props.subtitle || props.action
        ? el('div', { className: 'section-card__header' },
            el('div', null,
              props.title ? el('h2', { className: 'section-card__title' }, props.title) : null,
              props.subtitle ? el('p', { className: 'section-card__subtitle' }, props.subtitle) : null
            ),
            props.action ? el('div', { className: 'section-card__action' }, props.action) : null
          )
        : null,
      props.children
    );
  }

  function StatCard(props) {
    return el('div', { className: classNames('stat-card', props.emphasis && 'stat-card--emphasis') },
      el('span', { className: 'stat-card__label' }, props.label),
      el('strong', { className: 'stat-card__value' }, props.value),
      props.hint ? el('span', { className: 'stat-card__hint' }, props.hint) : null
    );
  }

  function Field(props) {
    var inputId = props.id || props.name;
    var control;
    var commonProps = {
      id: inputId,
      name: props.name,
      className: classNames('field-control', props.error && 'field-control--error'),
      value: props.value,
      onChange: props.onChange,
      placeholder: props.placeholder,
      type: props.type || 'text',
      min: props.min,
      step: props.step,
      inputMode: props.inputMode,
      disabled: props.disabled,
      rows: props.rows,
      max: props.max
    };

    if (props.as === 'textarea') {
      control = el('textarea', commonProps);
    } else if (props.as === 'select') {
      control = el('select', commonProps,
        props.options.map(function (option) {
          return el('option', { key: option.value, value: option.value }, option.label);
        })
      );
    } else {
      control = el('input', commonProps);
    }

    return el('label', {
      className: classNames('field', props.wide && 'field--wide')
    },
      el('span', { className: 'field__label' }, props.label),
      control,
      props.hint ? el('span', { className: 'field__hint' }, props.hint) : null,
      props.error ? el('span', { className: 'field__error' }, props.error) : null
    );
  }

  function ProgressBar(props) {
    var percent = Math.max(0, Math.min(100, toNumber(props.percent, 0)));
    return el('div', { className: 'progress' },
      el('div', {
        className: 'progress__bar',
        style: { width: percent + '%' }
      })
    );
  }

  function BalanceChart(props) {
    var rows = Array.isArray(props.rows) ? props.rows : [];
    var comparisonRows = Array.isArray(props.comparisonRows) ? props.comparisonRows : [];
    var width = 640;
    var height = 240;
    var padding = 18;
    var maxBalance = rows.concat(comparisonRows).reduce(function (highest, row) {
      return Math.max(highest, toNumber(row.openingBalance, 0));
    }, 0) || 1;

    if (!rows.length) {
      return el('div', { className: 'chart-empty' }, 'Add loan inputs to see the chart.');
    }

    function buildPoints(sourceRows) {
      return sourceRows.map(function (row, index) {
        var x = padding + ((width - padding * 2) * index) / Math.max(1, sourceRows.length - 1);
        var y = height - padding - ((height - padding * 2) * toNumber(row.closingBalance, 0)) / maxBalance;
        return [x, y];
      });
    }

    function pointsToString(points) {
      return points.map(function (pair) { return pair[0] + ',' + pair[1]; }).join(' ');
    }

    var points = buildPoints(rows);
    var comparisonPoints = comparisonRows.length ? buildPoints(comparisonRows) : [];
    var pointString = pointsToString(points);
    var comparisonString = pointsToString(comparisonPoints);
    var areaString = ['M ' + padding + ' ' + (height - padding)]
      .concat(points.map(function (pair) { return 'L ' + pair[0] + ' ' + pair[1]; }))
      .concat(['L ' + points[points.length - 1][0] + ' ' + (height - padding), 'Z'])
      .join(' ');

    return el('div', { className: 'chart-wrap' },
      el('svg', {
        className: 'chart',
        viewBox: '0 0 ' + width + ' ' + height,
        role: 'img',
        'aria-label': 'Loan balance reduction chart'
      },
        el('defs', null,
          el('linearGradient', { id: 'balanceGradient', x1: '0', x2: '0', y1: '0', y2: '1' },
            el('stop', { offset: '0%', 'stop-color': 'rgba(124, 58, 237, 0.55)' }),
            el('stop', { offset: '100%', 'stop-color': 'rgba(124, 58, 237, 0.02)' })
          )
        ),
        el('path', {
          d: areaString,
          fill: 'url(#balanceGradient)'
        }),
        comparisonRows.length
          ? el('polyline', {
              points: comparisonString,
              fill: 'none',
              stroke: 'rgba(148, 163, 184, 0.9)',
              'stroke-width': '2.5',
              'stroke-dasharray': '8 6',
              'stroke-linecap': 'round',
              'stroke-linejoin': 'round'
            })
          : null,
        el('polyline', {
          points: pointString,
          fill: 'none',
          stroke: '#9f7aea',
          'stroke-width': '4',
          'stroke-linecap': 'round',
          'stroke-linejoin': 'round'
        }),
        points.length
          ? [
              el('circle', { key: 'start', cx: points[0][0], cy: points[0][1], r: '5', fill: '#f8fafc' }),
              el('circle', { key: 'end', cx: points[points.length - 1][0], cy: points[points.length - 1][1], r: '5', fill: '#f8fafc' })
            ]
          : null
      ),
      el('div', { className: 'chart__labels' },
        el('span', null, formatMonth(rows[0].paymentDate)),
        comparisonRows.length ? el('span', null, 'Baseline vs plan') : null,
        el('span', null, formatMonth(rows[rows.length - 1].paymentDate))
      )
    );
  }

  function EmptyState(props) {
    return el('div', { className: 'empty-state surface-card' },
      el('div', { className: 'empty-state__icon' }, props.icon || '◌'),
      el('h2', { className: 'empty-state__title' }, props.title),
      props.message ? el('p', { className: 'empty-state__message' }, props.message) : null,
      props.actions ? el('div', { className: 'empty-state__actions' }, props.actions) : null
    );
  }

  function LoanCard(props) {
    var loan = props.loan;
    var snapshot = props.snapshot;
    var currency = props.currency;
    return el('a', {
      className: 'loan-card surface-card',
      href: buildUrl('loan.html', { id: loan.id }),
      style: { viewTransitionName: 'loan-card-' + loan.id }
    },
      el('div', { className: 'loan-card__glow' }),
      el('div', { className: 'loan-card__header' },
        el('div', null,
          el('strong', { className: 'loan-card__title' }, loan.name),
          el('span', { className: 'loan-card__meta' }, loan.lender || 'Loan account')
        ),
        el('span', { className: 'pill' }, describeTenure(snapshot.remainingInstallments))
      ),
      el('div', { className: 'loan-card__amount' }, formatMoney(loan.principal, currency)),
      el('div', { className: 'loan-card__amount-label' }, 'Loan amount • ' + describeDueDate(snapshot.nextDueDate, todayIso())),
      el('div', { className: 'loan-card__grid' },
        el(StatCard, {
          label: 'Outstanding',
          value: formatMoney(snapshot.remainingBalance, currency)
        }),
        el(StatCard, {
          label: 'Monthly due',
          value: formatMoney(snapshot.nextDueAmount || snapshot.totalRecurringPayment, currency)
        }),
        el(StatCard, {
          label: 'Payoff',
          value: snapshot.payoffDate ? formatMonth(snapshot.payoffDate) : '—'
        })
      ),
      el('div', { className: 'loan-card__progress' },
        el('div', { className: 'loan-card__progress-head' },
          el('span', null, 'Repaid'),
          el('span', null, formatNumber(snapshot.progressPercent, 0) + '%')
        ),
        el(ProgressBar, { percent: snapshot.progressPercent }),
        el('div', { className: 'chip-row' },
          el('span', { className: 'pill pill--subtle' }, 'Rate ' + formatNumber(snapshot.activeAnnualRate, 2) + '%'),
          el('span', { className: 'pill pill--subtle' }, 'Saved ' + formatMoney(snapshot.interestSaved, currency)),
          snapshot.hasActualTracking ? el('span', { className: 'pill pill--subtle' }, snapshot.actualPaymentCount + ' logged payments') : null
        )
      )
    );
  }

  function QuickActionCard(props) {
    var Tag = props.href ? 'a' : 'button';
    return el(Tag, {
      href: props.href,
      type: props.href ? undefined : 'button',
      onClick: props.onClick,
      className: classNames('quick-action-card surface-card', props.className)
    },
      el('div', { className: 'quick-action-card__icon' }, props.icon || '→'),
      el('div', { className: 'quick-action-card__body' },
        el('strong', { className: 'quick-action-card__title' }, props.title),
        props.description ? el('span', { className: 'quick-action-card__description' }, props.description) : null
      )
    );
  }

  function TabBar(props) {
    return el('div', { className: 'tab-bar', role: 'tablist', 'aria-label': props.label || 'Tabs' },
      props.tabs.map(function (tab) {
        return el('button', {
          key: tab.value,
          type: 'button',
          role: 'tab',
          'aria-selected': props.value === tab.value ? 'true' : 'false',
          className: classNames('tab-bar__button', props.value === tab.value && 'tab-bar__button--active'),
          onClick: function () { props.onChange(tab.value); }
        }, tab.label);
      })
    );
  }

  function CurrencyPicker(props) {
    return el(Field, {
      label: 'Currency',
      name: 'currency',
      as: 'select',
      value: props.value,
      onChange: props.onChange,
      options: (Store ? Store.CURRENCY_OPTIONS : ['INR']).map(function (code) {
        return { value: code, label: code };
      })
    });
  }

  return {
    React: React,
    h: h,
    el: el,
    Fragment: Fragment,
    useEffect: useEffect,
    useMemo: useMemo,
    useState: useState,
    useRef: useRef,
    classNames: classNames,
    toNumber: toNumber,
    todayIso: todayIso,
    formatMoney: formatMoney,
    formatNumber: formatNumber,
    formatDate: formatDate,
    formatMonth: formatMonth,
    describeTenure: describeTenure,
    describeDueDate: describeDueDate,
    splitTermMonths: splitTermMonths,
    termToMonths: termToMonths,
    getSearchParam: getSearchParam,
    buildUrl: buildUrl,
    navigateTo: navigateTo,
    useFlashMessage: useFlashMessage,
    getTheme: getTheme,
    applyTheme: applyTheme,
    buildCsvContent: buildCsvContent,
    downloadCsv: downloadCsv,
    IconButton: IconButton,
    Button: Button,
    ThemeToggleButton: ThemeToggleButton,
    BottomNav: BottomNav,
    PageShell: PageShell,
    SectionCard: SectionCard,
    StatCard: StatCard,
    Field: Field,
    ProgressBar: ProgressBar,
    BalanceChart: BalanceChart,
    EmptyState: EmptyState,
    LoanCard: LoanCard,
    QuickActionCard: QuickActionCard,
    TabBar: TabBar,
    CurrencyPicker: CurrencyPicker
  };
});
