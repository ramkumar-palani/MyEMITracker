(function (root, factory) {
  root.EmiTrackerHomePage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { HomePage: function HomePageFallback() { return null; } };
  }

  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var EmptyState = Common.EmptyState;
  var QuickActionCard = Common.QuickActionCard;
  var formatMoney = Common.formatMoney;
  var formatDate = Common.formatDate;
  var describeDueDate = Common.describeDueDate;

  function buildDueSoon(loans, daysAhead) {
    var today = Calculator.toIsoDate(new Date());
    return loans.map(function (loan) {
      var snapshot = Calculator.buildLoanSnapshot(loan, today);
      var dueDate = snapshot.nextDueDate;
      var diff = dueDate ? Calculator.daysBetween(today, dueDate) : 9999;
      return {
        loan: loan,
        snapshot: snapshot,
        diff: diff
      };
    }).filter(function (item) {
      return item.snapshot.nextDueDate && item.diff >= 0 && item.diff <= daysAhead;
    }).sort(function (left, right) {
      return left.diff - right.diff;
    });
  }

  function HomePage() {
    var loansState = useState(Store.getLoans());
    var loans = loansState[0];
    var setLoans = loansState[1];
    var currency = Store.getCurrency();
    var reminderSettings = Store.getReminderSettings();

    var snapshots = useMemo(function () {
      return loans.map(function (loan) {
        return {
          loan: loan,
          snapshot: Calculator.buildLoanSnapshot(loan, new Date())
        };
      });
    }, [loans]);

    var totals = useMemo(function () {
      return snapshots.reduce(function (accumulator, item) {
        accumulator.outstanding += item.snapshot.remainingBalance;
        accumulator.monthlyDue += item.snapshot.nextDueAmount || item.snapshot.totalRecurringPayment;
        accumulator.interestSaved += item.snapshot.interestSaved;
        return accumulator;
      }, {
        outstanding: 0,
        monthlyDue: 0,
        interestSaved: 0
      });
    }, [snapshots]);

    var dueSoon = useMemo(function () {
      return buildDueSoon(loans, Math.max(3, reminderSettings.reminderDaysBefore));
    }, [loans, reminderSettings.reminderDaysBefore]);

    var strategyPlan = useMemo(function () {
      return Calculator.buildStrategyPlan(loans, {
        strategy: 'highestRate',
        extraBudget: 5000,
        asOfDate: new Date()
      });
    }, [loans]);

    function handleSeedSample() {
      var seeded = Store.seedSampleLoans();
      setLoans(seeded);
    }

    if (!loans.length) {
      return el(PageShell, {
        currentPage: 'home',
        title: 'EMI Tracker',
        subtitle: 'Simple loan overview',
        titleTransitionName: 'app-title',
        actions: el('a', { href: './form.html', className: 'button button--small' }, 'Add loan')
      },
        el(EmptyState, {
          icon: '◎',
          title: 'Start with one loan',
          message: 'Track EMIs, extra payments, reminders, and payoff insights in one app.',
          actions: [
            el(Button, { key: 'sample', variant: 'ghost', onClick: handleSeedSample }, 'Load sample'),
            el(Button, { key: 'create', href: './form.html' }, 'Add loan')
          ]
        }),
        el('div', { className: 'quick-action-grid' },
          el(QuickActionCard, {
            href: './calculator.html',
            icon: '◫',
            title: 'Advanced calculator',
            description: 'Model extra payments, rate changes, and payoff options.'
          }),
          el(QuickActionCard, {
            href: './settings.html',
            icon: '⚙',
            title: 'Settings',
            description: 'Choose currency, theme, exports, and reminders.'
          })
        )
      );
    }

    return el(PageShell, {
      currentPage: 'home',
      title: 'EMI Tracker',
      subtitle: 'Simple loan overview',
      titleTransitionName: 'app-title',
      actions: el('div', { className: 'topbar__action-group' },
        el('a', { href: './form.html', className: 'button button--ghost button--small' }, 'Add loan'),
        el('a', { href: './loans.html', className: 'button button--small' }, 'View loans')
      )
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'Outstanding',
          value: formatMoney(totals.outstanding, currency),
          hint: loans.length + ' active loan' + (loans.length === 1 ? '' : 's')
        }),
        el(StatCard, {
          label: 'Upcoming dues',
          value: formatMoney(totals.monthlyDue, currency),
          hint: 'Across the next bill cycle'
        }),
        el(StatCard, {
          label: 'Interest saved',
          value: formatMoney(totals.interestSaved, currency),
          hint: 'From your current extra-payment plan'
        })
      ),
      strategyPlan.target
        ? el(SectionCard, {
            title: 'Smart focus',
            subtitle: 'A quick recommendation based on your current loans.',
            action: el(Button, { href: Common.buildUrl('loan.html', { id: strategyPlan.target.id }), small: true }, 'Open loan')
          },
            el('div', { className: 'hero-recommendation' },
              el('div', { className: 'hero-recommendation__body' },
                el('strong', { className: 'hero-recommendation__title' }, 'Close ' + strategyPlan.target.name + ' first'),
                el('p', { className: 'muted-copy' }, strategyPlan.reason + '. Adding ' + formatMoney(strategyPlan.extraBudget, currency) + ' monthly could save about ' + formatMoney(strategyPlan.target.projectedInterestReduction, currency) + ' and cut ' + strategyPlan.target.projectedMonthsReduction + ' months.'),
                el('div', { className: 'chip-row' },
                  el('span', { className: 'pill' }, 'Rate ' + strategyPlan.target.activeAnnualRate.toFixed(2) + '%'),
                  el('span', { className: 'pill' }, 'Balance ' + formatMoney(strategyPlan.target.remainingBalance, currency)),
                  el('span', { className: 'pill' }, 'Payoff ' + (strategyPlan.target.payoffDate ? Common.formatMonth(strategyPlan.target.payoffDate) : '—'))
                )
              )
            )
          )
        : null,
      el(SectionCard, {
        title: 'Due soon',
        subtitle: dueSoon.length ? 'Loans that need attention next.' : 'Nothing due in the next few days.',
        action: el(Button, { href: './settings.html', variant: 'ghost', small: true }, 'Manage reminders')
      },
        dueSoon.length
          ? el('div', { className: 'feed-list' },
              dueSoon.slice(0, 3).map(function (item) {
                return el('a', {
                  key: item.loan.id,
                  className: 'feed-item surface-card',
                  href: Common.buildUrl('loan.html', { id: item.loan.id })
                },
                  el('div', null,
                    el('strong', null, item.loan.name),
                    el('p', { className: 'muted-copy' }, item.loan.lender || 'Loan account')
                  ),
                  el('div', { className: 'feed-item__meta' },
                    el('strong', null, formatMoney(item.snapshot.nextDueAmount || item.snapshot.totalRecurringPayment, currency)),
                    el('span', null, describeDueDate(item.snapshot.nextDueDate))
                  )
                );
              })
            )
          : el('p', { className: 'muted-copy' }, 'Your loans have no immediate due date within the reminder window.')
      ),
      el(SectionCard, {
        title: 'Quick actions',
        subtitle: 'Jump into the part of the app you need.'
      },
        el('div', { className: 'quick-action-grid' },
          el(QuickActionCard, {
            href: './loans.html',
            icon: '◎',
            title: 'Open loans',
            description: 'See every loan card, status, and payoff date.'
          }),
          el(QuickActionCard, {
            href: './calculator.html',
            icon: '◫',
            title: 'Advanced calculator',
            description: 'Compare baseline vs extra payments and use the slider.'
          }),
          el(QuickActionCard, {
            href: './insights.html',
            icon: '◔',
            title: 'Insights & strategy',
            description: 'Get a payoff recommendation and ask the smart assistant.'
          }),
          el(QuickActionCard, {
            href: './settings.html',
            icon: '⚙',
            title: 'Settings & export',
            description: 'Switch currency, theme, reminders, and CSV export.'
          })
        )
      )
    );
  }

  return {
    HomePage: HomePage
  };
});
