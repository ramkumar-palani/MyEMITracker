(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.EmiTrackerCalculator = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var MAX_SCHEDULE_MONTHS = 1200;
  var EPSILON = 0.01;
  var objectHasOwn = Object.prototype.hasOwnProperty;

  function clampToNumber(value, fallback) {
    var parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function roundMoney(value) {
    return Math.round((clampToNumber(value, 0) + Number.EPSILON) * 100) / 100;
  }

  function calculateMonthlyRate(annualRate) {
    return Math.max(0, clampToNumber(annualRate, 0)) / 100 / 12;
  }

  function calculateEmiExact(principal, annualRate, tenureMonths) {
    var amount = Math.max(0, clampToNumber(principal, 0));
    var months = Math.max(0, Math.round(clampToNumber(tenureMonths, 0)));
    var monthlyRate = calculateMonthlyRate(annualRate);

    if (!amount || !months) {
      return 0;
    }

    if (!monthlyRate) {
      return amount / months;
    }

    var factor = Math.pow(1 + monthlyRate, months);
    return (amount * monthlyRate * factor) / (factor - 1);
  }

  function calculateEmi(principal, annualRate, tenureMonths) {
    return roundMoney(calculateEmiExact(principal, annualRate, tenureMonths));
  }

  function parseIsoDate(dateInput) {
    if (dateInput instanceof Date) {
      return new Date(Date.UTC(
        dateInput.getUTCFullYear(),
        dateInput.getUTCMonth(),
        dateInput.getUTCDate()
      ));
    }

    if (typeof dateInput !== 'string' || !dateInput) {
      return null;
    }

    var parts = dateInput.split('-').map(Number);
    if (parts.length !== 3 || parts.some(function (part) { return !Number.isFinite(part); })) {
      return null;
    }

    return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  }

  function toIsoDate(dateInput) {
    var date = parseIsoDate(dateInput) || (dateInput instanceof Date ? parseIsoDate(dateInput) : null);
    if (!date || Number.isNaN(date.getTime())) {
      return '';
    }
    return date.toISOString().slice(0, 10);
  }

  function getLastDayOfMonth(year, monthIndex) {
    return new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  }

  function addMonths(dateInput, monthsToAdd) {
    var date = parseIsoDate(dateInput);
    if (!date) {
      return null;
    }

    var year = date.getUTCFullYear();
    var month = date.getUTCMonth() + Math.round(monthsToAdd);
    var day = date.getUTCDate();
    var targetYear = year + Math.floor(month / 12);
    var normalizedMonth = month % 12;

    if (normalizedMonth < 0) {
      normalizedMonth += 12;
      targetYear -= 1;
    }

    var lastDay = getLastDayOfMonth(targetYear, normalizedMonth);
    return new Date(Date.UTC(targetYear, normalizedMonth, Math.min(day, lastDay)));
  }

  function monthKey(dateInput) {
    var date = parseIsoDate(dateInput);
    if (!date) {
      return '';
    }
    return date.toISOString().slice(0, 7);
  }

  function isDateOnOrBefore(left, right) {
    var leftDate = parseIsoDate(left);
    var rightDate = parseIsoDate(right);
    if (!leftDate || !rightDate) {
      return false;
    }
    return leftDate.getTime() <= rightDate.getTime();
  }

  function isDateOnOrAfter(left, right) {
    var leftDate = parseIsoDate(left);
    var rightDate = parseIsoDate(right);
    if (!leftDate || !rightDate) {
      return false;
    }
    return leftDate.getTime() >= rightDate.getTime();
  }

  function daysBetween(startDateInput, endDateInput) {
    var startDate = parseIsoDate(startDateInput);
    var endDate = parseIsoDate(endDateInput);
    if (!startDate || !endDate) {
      return 0;
    }
    var diff = endDate.getTime() - startDate.getTime();
    return Math.round(diff / 86400000);
  }

  function sortByDate(list) {
    return (Array.isArray(list) ? list.slice() : []).sort(function (left, right) {
      return String(left.date || '').localeCompare(String(right.date || ''));
    });
  }

  function sumBy(list, selector) {
    return roundMoney((Array.isArray(list) ? list : []).reduce(function (total, item) {
      return total + selector(item);
    }, 0));
  }

  function normalizeAmountList(list, amountKey, allowZero) {
    return sortByDate(list).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }

      var date = toIsoDate(item.date);
      var amount = clampToNumber(item[amountKey], 0);
      if (!date || amount < 0) {
        return accumulator;
      }
      if (!allowZero && amount <= 0) {
        return accumulator;
      }

      accumulator.push({
        date: date,
        amount: roundMoney(amount)
      });
      return accumulator;
    }, []);
  }

  function normalizeRateChangeList(list) {
    return sortByDate(list).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }

      var date = toIsoDate(item.date);
      var annualRate = clampToNumber(item.annualRate, 0);
      if (!date || annualRate < 0) {
        return accumulator;
      }

      accumulator.push({
        date: date,
        annualRate: annualRate
      });
      return accumulator;
    }, []);
  }

  function normalizeOffsetBalanceChangeList(list) {
    return sortByDate(list).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }

      var date = toIsoDate(item.date);
      var balance = clampToNumber(item.balance, 0);
      if (!date || balance < 0) {
        return accumulator;
      }

      accumulator.push({
        date: date,
        balance: roundMoney(balance)
      });
      return accumulator;
    }, []);
  }

  function normalizePaymentLogList(list) {
    return sortByDate(list).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }

      var date = toIsoDate(item.date);
      var paidOn = toIsoDate(item.paidOn);
      var amount = clampToNumber(item.amount, 0);
      if (!date || amount < 0) {
        return accumulator;
      }

      accumulator.push({
        date: date,
        amount: roundMoney(amount),
        paidOn: paidOn,
        note: item.note ? String(item.note) : ''
      });
      return accumulator;
    }, []);
  }

  function buildMonthAmountMap(list, allowZero) {
    return (Array.isArray(list) ? list : []).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }

      var key = monthKey(item.date);
      var amount = clampToNumber(item.amount, 0);
      if (!key || amount < 0) {
        return accumulator;
      }
      if (!allowZero && amount <= 0) {
        return accumulator;
      }

      if (allowZero) {
        accumulator[key] = roundMoney(amount);
      } else {
        accumulator[key] = roundMoney((accumulator[key] || 0) + amount);
      }
      return accumulator;
    }, {});
  }

  function buildDateValueMap(list, valueKey) {
    return (Array.isArray(list) ? list : []).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }
      accumulator[toIsoDate(item.date)] = item[valueKey];
      return accumulator;
    }, {});
  }

  function buildDateItemMap(list) {
    return (Array.isArray(list) ? list : []).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }
      accumulator[toIsoDate(item.date)] = item;
      return accumulator;
    }, {});
  }

  function buildEffectiveSeriesMap(list, keyName) {
    return sortByDate(list).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }
      var key = monthKey(item.date);
      if (!key) {
        return accumulator;
      }
      accumulator.push({
        month: key,
        value: item[keyName]
      });
      return accumulator;
    }, []);
  }

  function resolveEffectiveValue(series, defaultValue, paymentDate) {
    var month = monthKey(paymentDate);
    var resolved = defaultValue;

    for (var index = 0; index < series.length; index += 1) {
      if (series[index].month <= month) {
        resolved = series[index].value;
      } else {
        break;
      }
    }

    return resolved;
  }

  function normalizeLoan(loanInput) {
    var principal = Math.max(0, roundMoney(clampToNumber(loanInput && loanInput.principal, 0)));
    var annualRate = Math.max(0, clampToNumber(loanInput && loanInput.annualRate, 0));
    var originalTenureMonths = Math.max(1, Math.round(clampToNumber(loanInput && loanInput.originalTenureMonths, 1)));
    var monthlyPayment = Math.max(0, roundMoney(clampToNumber(loanInput && loanInput.monthlyPayment, 0)));
    var monthlyExtraPayment = Math.max(0, roundMoney(clampToNumber(loanInput && loanInput.monthlyExtraPayment, 0)));
    var offsetBalance = Math.max(0, roundMoney(clampToNumber(loanInput && loanInput.offsetBalance, 0)));
    var calculatedEmiExact = calculateEmiExact(principal, annualRate, originalTenureMonths);
    var calculatedEmi = roundMoney(calculatedEmiExact);
    var effectiveMonthlyPayment = monthlyPayment || calculatedEmiExact;
    var startDate = toIsoDate((loanInput && loanInput.startDate) || new Date()) || toIsoDate(new Date());
    var priorityRank = Math.max(0, Math.round(clampToNumber(loanInput && loanInput.priorityRank, 0)));
    var prepaymentMode = loanInput && loanInput.prepaymentMode === 'reduceEmi' ? 'reduceEmi' : 'reduceTenure';

    return {
      id: loanInput && loanInput.id ? String(loanInput.id) : '',
      name: loanInput && loanInput.name ? String(loanInput.name) : 'Loan',
      lender: loanInput && loanInput.lender ? String(loanInput.lender) : '',
      principal: principal,
      annualRate: annualRate,
      originalTenureMonths: originalTenureMonths,
      monthlyPayment: monthlyPayment,
      monthlyExtraPayment: monthlyExtraPayment,
      monthlyExtraOverrides: normalizeAmountList(loanInput && loanInput.monthlyExtraOverrides, 'amount', true),
      extraPayments: normalizeAmountList(loanInput && loanInput.extraPayments, 'amount', false),
      rateChanges: normalizeRateChangeList(loanInput && loanInput.rateChanges),
      offsetBalance: offsetBalance,
      offsetBalanceChanges: normalizeOffsetBalanceChangeList(loanInput && loanInput.offsetBalanceChanges),
      actualPayments: normalizePaymentLogList(loanInput && loanInput.actualPayments),
      effectiveMonthlyPayment: effectiveMonthlyPayment,
      calculatedEmi: calculatedEmi,
      startDate: startDate,
      priorityRank: priorityRank,
      prepaymentMode: prepaymentMode,
      createdAt: loanInput && loanInput.createdAt ? String(loanInput.createdAt) : '',
      updatedAt: loanInput && loanInput.updatedAt ? String(loanInput.updatedAt) : ''
    };
  }

  function createAmortizationSchedule(loanInput) {
    var loan = normalizeLoan(loanInput);
    var balance = loan.principal;
    var extraPaymentMap = buildMonthAmountMap(loan.extraPayments, false);
    var monthlyOverrideMap = buildMonthAmountMap(loan.monthlyExtraOverrides, true);
    var rateSeries = buildEffectiveSeriesMap(loan.rateChanges, 'annualRate');
    var offsetSeries = buildEffectiveSeriesMap(loan.offsetBalanceChanges, 'balance');
    var actualPaymentMap = buildDateItemMap(loan.actualPayments);
    var scheduledPayment = loan.effectiveMonthlyPayment;
    var schedule = [];
    var hasNegativeAmortization = false;
    var minimumScheduledPayment = null;

    if (!loan.principal) {
      return {
        rows: [],
        scheduledPayment: roundMoney(scheduledPayment),
        calculatedEmi: loan.calculatedEmi,
        hasNegativeAmortization: false,
        payoffDate: '',
        totalInterest: 0,
        totalPrincipal: 0,
        totalPayments: 0,
        minimumScheduledPayment: 0,
        finalScheduledPayment: 0
      };
    }

    for (var monthIndex = 0; monthIndex < MAX_SCHEDULE_MONTHS && balance > EPSILON; monthIndex += 1) {
      var paymentDate = addMonths(loan.startDate, monthIndex);
      var dueDate = toIsoDate(paymentDate);
      var currentAnnualRate = resolveEffectiveValue(rateSeries, loan.annualRate, paymentDate);
      var monthlyRate = calculateMonthlyRate(currentAnnualRate);
      var offsetBalance = Math.max(0, roundMoney(resolveEffectiveValue(offsetSeries, loan.offsetBalance, paymentDate)));
      var openingBalanceRaw = balance;
      var interestBaseRaw = Math.max(0, openingBalanceRaw - offsetBalance);
      var accruedInterestRaw = interestBaseRaw * monthlyRate;
      var monthlyKey = monthKey(paymentDate);
      var recurringExtra = objectHasOwn.call(monthlyOverrideMap, monthlyKey)
        ? monthlyOverrideMap[monthlyKey]
        : loan.monthlyExtraPayment;
      var oneTimeExtra = extraPaymentMap[monthlyKey] || 0;
      var requestedExtra = recurringExtra + oneTimeExtra;
      var requestedPayment = scheduledPayment + requestedExtra;
      var maximumPayment = openingBalanceRaw + accruedInterestRaw;
      var plannedTotalPaymentRaw = Math.min(requestedPayment, maximumPayment);
      var actualRecord = actualPaymentMap[dueDate] || null;
      var totalPaymentRaw = actualRecord
        ? Math.min(Math.max(0, clampToNumber(actualRecord.amount, 0)), maximumPayment)
        : plannedTotalPaymentRaw;
      var interestPaidRaw = Math.min(totalPaymentRaw, accruedInterestRaw);
      var principalPaidRaw = Math.max(0, totalPaymentRaw - interestPaidRaw);
      var closingBalanceRaw = Math.max(0, openingBalanceRaw + accruedInterestRaw - totalPaymentRaw);
      var scheduledPaymentAppliedRaw = Math.min(scheduledPayment, totalPaymentRaw);
      var extraPaymentAppliedRaw = Math.max(0, totalPaymentRaw - scheduledPaymentAppliedRaw);
      var plannedScheduledAppliedRaw = Math.min(scheduledPayment, plannedTotalPaymentRaw);
      var plannedExtraAppliedRaw = Math.max(0, plannedTotalPaymentRaw - plannedScheduledAppliedRaw);

      if (closingBalanceRaw > openingBalanceRaw + 1e-9) {
        hasNegativeAmortization = true;
      }

      minimumScheduledPayment = minimumScheduledPayment === null
        ? roundMoney(scheduledPayment)
        : Math.min(minimumScheduledPayment, roundMoney(scheduledPayment));

      schedule.push({
        installmentNumber: monthIndex + 1,
        paymentDate: dueDate,
        openingBalance: roundMoney(openingBalanceRaw),
        annualRate: roundMoney(currentAnnualRate),
        monthlyRate: monthlyRate,
        offsetBalance: offsetBalance,
        interestBase: roundMoney(interestBaseRaw),
        accruedInterest: roundMoney(accruedInterestRaw),
        scheduledPayment: roundMoney(scheduledPaymentAppliedRaw),
        scheduledPaymentTarget: roundMoney(scheduledPayment),
        recurringExtra: roundMoney(recurringExtra),
        oneTimeExtra: roundMoney(oneTimeExtra),
        extraPayment: roundMoney(extraPaymentAppliedRaw),
        plannedExtra: roundMoney(plannedExtraAppliedRaw),
        plannedTotalPayment: roundMoney(plannedTotalPaymentRaw),
        totalPayment: roundMoney(totalPaymentRaw),
        loggedPayment: actualRecord ? roundMoney(actualRecord.amount) : 0,
        isActualPayment: !!actualRecord,
        paymentVariance: actualRecord ? roundMoney(totalPaymentRaw - plannedTotalPaymentRaw) : 0,
        paidOn: actualRecord && actualRecord.paidOn ? actualRecord.paidOn : '',
        note: actualRecord && actualRecord.note ? actualRecord.note : '',
        interestPaid: roundMoney(interestPaidRaw),
        principalPaid: roundMoney(principalPaidRaw),
        closingBalance: roundMoney(closingBalanceRaw),
        prepaymentMode: loan.prepaymentMode
      });

      balance = closingBalanceRaw;

      if (loan.prepaymentMode === 'reduceEmi' && closingBalanceRaw > EPSILON) {
        var remainingMonths = Math.max(0, loan.originalTenureMonths - (monthIndex + 1));
        if (remainingMonths > 0) {
          var nextDate = addMonths(loan.startDate, monthIndex + 1);
          var nextAnnualRate = resolveEffectiveValue(rateSeries, loan.annualRate, nextDate);
          scheduledPayment = calculateEmiExact(closingBalanceRaw, nextAnnualRate, remainingMonths);
        }
      }

      if (closingBalanceRaw <= EPSILON) {
        break;
      }
    }

    return {
      rows: schedule,
      scheduledPayment: roundMoney(loan.effectiveMonthlyPayment),
      calculatedEmi: loan.calculatedEmi,
      hasNegativeAmortization: hasNegativeAmortization,
      payoffDate: schedule.length ? schedule[schedule.length - 1].paymentDate : '',
      totalInterest: sumBy(schedule, function (row) { return row.interestPaid; }),
      totalPrincipal: sumBy(schedule, function (row) { return row.principalPaid; }),
      totalPayments: sumBy(schedule, function (row) { return row.totalPayment; }),
      minimumScheduledPayment: roundMoney(minimumScheduledPayment || loan.effectiveMonthlyPayment),
      finalScheduledPayment: schedule.length ? schedule[schedule.length - 1].scheduledPaymentTarget : roundMoney(loan.effectiveMonthlyPayment)
    };
  }

  function buildLoanSnapshot(loanInput, asOfDateInput) {
    var loan = normalizeLoan(loanInput);
    var asOfDate = toIsoDate(asOfDateInput || new Date()) || toIsoDate(new Date());
    var accelerated = createAmortizationSchedule(loan);
    var baselineLoan = {
      id: loan.id,
      name: loan.name,
      lender: loan.lender,
      principal: loan.principal,
      annualRate: loan.annualRate,
      originalTenureMonths: loan.originalTenureMonths,
      monthlyPayment: loan.monthlyPayment,
      monthlyExtraPayment: 0,
      monthlyExtraOverrides: [],
      extraPayments: [],
      rateChanges: loan.rateChanges,
      offsetBalance: loan.offsetBalance,
      offsetBalanceChanges: loan.offsetBalanceChanges,
      actualPayments: [],
      priorityRank: loan.priorityRank,
      prepaymentMode: loan.prepaymentMode,
      startDate: loan.startDate
    };
    var baseline = createAmortizationSchedule(baselineLoan);

    var dueRows = accelerated.rows.filter(function (row) {
      return isDateOnOrBefore(row.paymentDate, asOfDate);
    });
    var futureRows = accelerated.rows.filter(function (row) {
      return !isDateOnOrBefore(row.paymentDate, asOfDate);
    });
    var actualRows = dueRows.filter(function (row) {
      return row.isActualPayment;
    });
    var useActualTracking = loan.actualPayments.length > 0;
    var paidRows = useActualTracking ? actualRows : dueRows;
    var lastPaidRow = paidRows.length ? paidRows[paidRows.length - 1] : null;
    var currentBalanceRow = useActualTracking
      ? (lastPaidRow || null)
      : (dueRows.length ? dueRows[dueRows.length - 1] : null);
    var principalPaidSoFar = sumBy(paidRows, function (row) { return row.principalPaid; });
    var interestPaidSoFar = sumBy(paidRows, function (row) { return row.interestPaid; });
    var remainingBalance = currentBalanceRow ? currentBalanceRow.closingBalance : loan.principal;
    var remainingTenureMonths = useActualTracking
      ? accelerated.rows.filter(function (row) {
          return !lastPaidRow || !isDateOnOrBefore(row.paymentDate, lastPaidRow.paymentDate);
        }).length
      : futureRows.length;
    var progressPercent = loan.principal ? roundMoney((principalPaidSoFar / loan.principal) * 100) : 0;
    var monthsSaved = Math.max(0, baseline.rows.length - accelerated.rows.length);
    var interestSaved = Math.max(0, roundMoney(baseline.totalInterest - accelerated.totalInterest));
    var oneTimeExtraTotal = sumBy(loan.extraPayments, function (item) { return item.amount; });
    var totalRecurringPayment = roundMoney((loan.prepaymentMode === 'reduceEmi'
      ? accelerated.minimumScheduledPayment
      : loan.effectiveMonthlyPayment) + loan.monthlyExtraPayment);
    var totalProjectedOffset = sumBy(accelerated.rows, function (row) { return row.offsetBalance; });
    var activeRow = accelerated.rows.length
      ? accelerated.rows[Math.min(useActualTracking ? paidRows.length : dueRows.length, accelerated.rows.length - 1)]
      : null;
    var currentInterestCost = activeRow ? roundMoney(activeRow.accruedInterest || activeRow.interestPaid) : 0;
    var nextDueRow = futureRows.length ? futureRows[0] : null;

    return {
      loan: loan,
      asOfDate: asOfDate,
      schedule: accelerated.rows,
      baselineSchedule: baseline.rows,
      paymentsMadeCount: paidRows.length,
      remainingInstallments: remainingTenureMonths,
      principalPaidSoFar: principalPaidSoFar,
      interestPaidSoFar: interestPaidSoFar,
      estimatedPrincipalPaid: sumBy(dueRows, function (row) { return row.principalPaid; }),
      estimatedInterestPaid: sumBy(dueRows, function (row) { return row.interestPaid; }),
      remainingBalance: roundMoney(Math.max(0, remainingBalance)),
      progressPercent: Math.min(100, Math.max(0, progressPercent)),
      payoffDate: accelerated.payoffDate,
      projectedTotalInterest: accelerated.totalInterest,
      projectedTotalPrincipal: accelerated.totalPrincipal,
      projectedTotalPayments: accelerated.totalPayments,
      totalRecurringPayment: totalRecurringPayment,
      recurringExtraPayment: loan.monthlyExtraPayment,
      oneTimeExtraTotal: oneTimeExtraTotal,
      monthsSaved: monthsSaved,
      interestSaved: interestSaved,
      calculatedEmi: loan.calculatedEmi,
      scheduledPayment: accelerated.scheduledPayment,
      minimumScheduledPayment: accelerated.minimumScheduledPayment,
      finalScheduledPayment: accelerated.finalScheduledPayment,
      hasNegativeAmortization: accelerated.hasNegativeAmortization,
      isPaidOff: roundMoney(remainingBalance) <= EPSILON,
      nextDueDate: nextDueRow ? nextDueRow.paymentDate : '',
      nextDueAmount: nextDueRow ? nextDueRow.plannedTotalPayment : 0,
      baselineInterest: baseline.totalInterest,
      baselinePayoffDate: baseline.payoffDate,
      baselineMonths: baseline.rows.length,
      projectedOffsetTotal: totalProjectedOffset,
      activeAnnualRate: activeRow ? activeRow.annualRate : loan.annualRate,
      actualPaymentCount: actualRows.length,
      actualAmountPaidSoFar: sumBy(actualRows, function (row) { return row.totalPayment; }),
      unloggedDueCount: useActualTracking ? dueRows.filter(function (row) { return !row.isActualPayment; }).length : 0,
      hasActualTracking: useActualTracking,
      currentMonthlyInterestCost: currentInterestCost
    };
  }

  function buildStrategyPlan(loansInput, options) {
    var settings = options || {};
    var asOfDate = toIsoDate(settings.asOfDate || new Date()) || toIsoDate(new Date());
    var strategy = settings.strategy || 'highestRate';
    var extraBudget = Math.max(0, roundMoney(clampToNumber(settings.extraBudget, 0)));

    var activeLoans = (Array.isArray(loansInput) ? loansInput : []).map(function (loan) {
      var snapshot = buildLoanSnapshot(loan, asOfDate);
      var trialLoan = normalizeLoan(loan);
      trialLoan.monthlyExtraPayment = roundMoney(trialLoan.monthlyExtraPayment + extraBudget);
      var extraScenario = extraBudget > 0 ? buildLoanSnapshot(trialLoan, asOfDate) : snapshot;
      return {
        loan: normalizeLoan(loan),
        snapshot: snapshot,
        projectedInterestReduction: Math.max(0, roundMoney(snapshot.projectedTotalInterest - extraScenario.projectedTotalInterest)),
        projectedMonthsReduction: Math.max(0, snapshot.schedule.length - extraScenario.schedule.length),
        monthlyInterestCost: snapshot.currentMonthlyInterestCost,
        priorityRank: normalizeLoan(loan).priorityRank || 0
      };
    }).filter(function (item) {
      return !item.snapshot.isPaidOff;
    });

    function compare(left, right) {
      if (strategy === 'smallestBalance') {
        if (left.snapshot.remainingBalance !== right.snapshot.remainingBalance) {
          return left.snapshot.remainingBalance - right.snapshot.remainingBalance;
        }
      } else if (strategy === 'highestInterestCost') {
        if (left.monthlyInterestCost !== right.monthlyInterestCost) {
          return right.monthlyInterestCost - left.monthlyInterestCost;
        }
      } else if (strategy === 'customPriority') {
        var leftPriority = left.priorityRank || Number.MAX_SAFE_INTEGER;
        var rightPriority = right.priorityRank || Number.MAX_SAFE_INTEGER;
        if (leftPriority !== rightPriority) {
          return leftPriority - rightPriority;
        }
      } else {
        if (left.snapshot.activeAnnualRate !== right.snapshot.activeAnnualRate) {
          return right.snapshot.activeAnnualRate - left.snapshot.activeAnnualRate;
        }
      }

      if (right.projectedInterestReduction !== left.projectedInterestReduction) {
        return right.projectedInterestReduction - left.projectedInterestReduction;
      }
      return left.snapshot.remainingBalance - right.snapshot.remainingBalance;
    }

    var ordered = activeLoans.sort(compare);
    var target = ordered.length ? ordered[0] : null;
    var reasonMap = {
      highestRate: 'Highest active interest rate',
      smallestBalance: 'Smallest remaining balance',
      highestInterestCost: 'Highest monthly interest cost',
      customPriority: 'Your custom priority order'
    };

    return {
      strategy: strategy,
      extraBudget: extraBudget,
      asOfDate: asOfDate,
      reason: reasonMap[strategy] || reasonMap.highestRate,
      target: target ? {
        id: target.loan.id,
        name: target.loan.name,
        lender: target.loan.lender,
        remainingBalance: target.snapshot.remainingBalance,
        activeAnnualRate: target.snapshot.activeAnnualRate,
        currentMonthlyInterestCost: target.monthlyInterestCost,
        projectedInterestReduction: target.projectedInterestReduction,
        projectedMonthsReduction: target.projectedMonthsReduction,
        payoffDate: target.snapshot.payoffDate
      } : null,
      order: ordered.map(function (item, index) {
        return {
          rank: index + 1,
          id: item.loan.id,
          name: item.loan.name,
          lender: item.loan.lender,
          remainingBalance: item.snapshot.remainingBalance,
          activeAnnualRate: item.snapshot.activeAnnualRate,
          payoffDate: item.snapshot.payoffDate,
          currentMonthlyInterestCost: item.monthlyInterestCost,
          projectedInterestReduction: item.projectedInterestReduction,
          projectedMonthsReduction: item.projectedMonthsReduction,
          priorityRank: item.priorityRank || 0
        };
      })
    };
  }

  function findRequiredMonthlyPayment(loanInput, targetMonths) {
    var loan = normalizeLoan(loanInput);
    var months = Math.max(1, Math.round(clampToNumber(targetMonths, loan.originalTenureMonths)));
    var baseLow = Math.max(loan.effectiveMonthlyPayment, loan.principal / months);
    var high = Math.max(baseLow * 3, loan.principal + loan.principal * calculateMonthlyRate(loan.annualRate));
    var low = Math.max(0, baseLow);
    var upper = high;

    for (var index = 0; index < 40; index += 1) {
      var mid = (low + upper) / 2;
      var trial = createAmortizationSchedule({
        principal: loan.principal,
        annualRate: loan.annualRate,
        originalTenureMonths: Math.max(months, loan.originalTenureMonths),
        startDate: loan.startDate,
        monthlyPayment: mid,
        monthlyExtraPayment: loan.monthlyExtraPayment,
        monthlyExtraOverrides: loan.monthlyExtraOverrides,
        extraPayments: loan.extraPayments,
        rateChanges: loan.rateChanges,
        offsetBalance: loan.offsetBalance,
        offsetBalanceChanges: loan.offsetBalanceChanges,
        prepaymentMode: 'reduceTenure'
      });
      if (trial.rows.length > months) {
        low = mid;
      } else {
        upper = mid;
      }
    }

    return roundMoney(upper);
  }

  function calculateTenureMonths(principal, annualRate, monthlyPayment) {
    var payment = Math.max(0, clampToNumber(monthlyPayment, 0));
    if (!payment) {
      return 0;
    }
    var trial = createAmortizationSchedule({
      principal: principal,
      annualRate: annualRate,
      originalTenureMonths: MAX_SCHEDULE_MONTHS,
      monthlyPayment: payment,
      monthlyExtraPayment: 0,
      startDate: toIsoDate(new Date()),
      prepaymentMode: 'reduceTenure'
    });
    return trial.rows.length;
  }

  return {
    MAX_SCHEDULE_MONTHS: MAX_SCHEDULE_MONTHS,
    EPSILON: EPSILON,
    roundMoney: roundMoney,
    clampToNumber: clampToNumber,
    calculateMonthlyRate: calculateMonthlyRate,
    calculateEmiExact: calculateEmiExact,
    calculateEmi: calculateEmi,
    parseIsoDate: parseIsoDate,
    toIsoDate: toIsoDate,
    addMonths: addMonths,
    monthKey: monthKey,
    daysBetween: daysBetween,
    isDateOnOrBefore: isDateOnOrBefore,
    isDateOnOrAfter: isDateOnOrAfter,
    sortByDate: sortByDate,
    createAmortizationSchedule: createAmortizationSchedule,
    buildLoanSnapshot: buildLoanSnapshot,
    buildStrategyPlan: buildStrategyPlan,
    findRequiredMonthlyPayment: findRequiredMonthlyPayment,
    calculateTenureMonths: calculateTenureMonths,
    normalizeLoan: normalizeLoan,
    sumBy: sumBy,
    normalizePaymentLogList: normalizePaymentLogList,
    buildDateValueMap: buildDateValueMap
  };
});
