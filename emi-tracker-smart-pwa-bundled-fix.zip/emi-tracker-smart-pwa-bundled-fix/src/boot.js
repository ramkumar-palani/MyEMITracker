(function (root) {
  'use strict';

  var mountNode = root.document && root.document.getElementById('app');

  function renderFallback(message) {
    if (!mountNode) {
      return;
    }
    mountNode.innerHTML = '<div class="fallback-box"><h1>EMI Tracker</h1><p>' + message + '</p></div>';
  }

  if (!mountNode) {
    return;
  }

  if (!root.React || !root.ReactDOM || !root.EmiTrackerCommon) {
    renderFallback('The app dependencies could not be loaded. Open the app once online, then reinstall if needed.');
    return;
  }

  var page = root.document.body.getAttribute('data-page');
  var registry = {
    home: root.EmiTrackerHomePage && root.EmiTrackerHomePage.HomePage,
    loans: root.EmiTrackerLoansPage && root.EmiTrackerLoansPage.LoansPage,
    insights: root.EmiTrackerInsightsPage && root.EmiTrackerInsightsPage.InsightsPage,
    settings: root.EmiTrackerSettingsPage && root.EmiTrackerSettingsPage.SettingsPage,
    form: root.EmiTrackerFormPage && root.EmiTrackerFormPage.FormPage,
    loan: root.EmiTrackerLoanPage && root.EmiTrackerLoanPage.LoanPage,
    calculator: root.EmiTrackerCalculatorPage && root.EmiTrackerCalculatorPage.CalculatorPage
  };
  var Component = registry[page];

  if (!Component) {
    renderFallback('This page is not available.');
    return;
  }

  try {
    var appRoot;
    if (typeof root.ReactDOM.createRoot === 'function') {
      appRoot = root.ReactDOM.createRoot(mountNode);
      appRoot.render(root.React.createElement(Component));
    } else if (typeof root.ReactDOM.render === 'function') {
      root.ReactDOM.render(root.React.createElement(Component), mountNode);
    } else {
      renderFallback('ReactDOM could not mount the app.');
    }
  } catch (error) {
    renderFallback('The app failed to start. Refresh once, and if needed clear the site cache before reinstalling.');
    if (root.console && typeof root.console.error === 'function') {
      root.console.error(error);
    }
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
