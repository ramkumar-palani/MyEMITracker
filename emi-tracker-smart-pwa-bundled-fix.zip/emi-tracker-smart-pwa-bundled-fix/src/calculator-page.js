(function (root, factory) {
  root.EmiTrackerCalculatorPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { CalculatorPage: function CalculatorPageFallback() { return null; } };
  }

  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var Field = Common.Field;
  var BalanceChart = Common.BalanceChart;
  var TabBar = Common.TabBar;
  var EmptyState = Common.EmptyState;
  var formatMoney = Common.formatMoney;
  var formatMonth = Common.formatMonth;
  var getSearchParam = Common.getSearchParam;
  var splitTermMonths = Common.splitTermMonths;
  var termToMonths = Common.termToMonths;
  var todayIso = Common.todayIso;
  var toNumber = Common.toNumber;

  function sanitizeAmountRows(list, keepZero) {
    return (Array.isArray(list) ? list : []).map(function (row) {
      return {
        date: row && row.date ? String(row.date) : '',
        amount: row && row.amount !== undefined ? String(row.amount) : ''
      };
    }).filter(function (row) {
      if (!row.date && !row.amount) {
        return false;
      }
      if (!keepZero && row.amount !== '' && toNumber(row.amount, 0) <= 0 && !row.date) {
        return false;
      }
      return true;
    });
  }

  function sanitizeRateRows(list) {
    return (Array.isArray(list) ? list : []).map(function (row) {
      return {
        date: row && row.date ? String(row.date) : '',
        annualRate: row && row.annualRate !== undefined ? String(row.annualRate) : ''
      };
    }).filter(function (row) {
      return row.date || row.annualRate;
    });
  }

  function sanitizeOffsetRows(list) {
    return (Array.isArray(list) ? list : []).map(function (row) {
      return {
        date: row && row.date ? String(row.date) : '',
        balance: row && row.balance !== undefined ? String(row.balance) : ''
      };
    }).filter(function (row) {
      return row.date || row.balance;
    });
  }

  function buildInitialState(existingLoan) {
    var term = splitTermMonths(existingLoan ? existingLoan.originalTenureMonths : 240);
    return {
      name: existingLoan ? existingLoan.name : '',
      lender: existingLoan ? existingLoan.lender : '',
      principal: existingLoan ? String(existingLoan.principal) : '',
      annualRate: existingLoan ? String(existingLoan.annualRate) : '',
      termValue: term.termValue,
      termUnit: term.termUnit,
      startDate: existingLoan ? existingLoan.startDate : todayIso(),
      monthlyPayment: existingLoan && existingLoan.monthlyPayment ? String(existingLoan.monthlyPayment) : '',
      monthlyExtraPayment: existingLoan && existingLoan.monthlyExtraPayment ? String(existingLoan.monthlyExtraPayment) : '0',
      monthlyExtraOverrides: sanitizeAmountRows(existingLoan ? existingLoan.monthlyExtraOverrides : [], true),
      extraPayments: sanitizeAmountRows(existingLoan ? existingLoan.extraPayments : [], false),
      rateChanges: sanitizeRateRows(existingLoan ? existingLoan.rateChanges : []),
      offsetBalance: existingLoan && existingLoan.offsetBalance ? String(existingLoan.offsetBalance) : '',
      offsetBalanceChanges: sanitizeOffsetRows(existingLoan ? existingLoan.offsetBalanceChanges : []),
      prepaymentMode: existingLoan && existingLoan.prepaymentMode ? existingLoan.prepaymentMode : 'reduceTenure',
      existingLoanId: existingLoan ? existingLoan.id : ''
    };
  }

  function getMonthlyOverrideMap(state) {
    return sanitizeAmountRows(state.monthlyExtraOverrides, true).reduce(function (accumulator, row) {
      if (row.date) {
        accumulator[row.date] = row.amount;
      }
      return accumulator;
    }, {});
  }

  function upsertMonthlyOverride(list, date, rawAmount, defaultAmount) {
    var amount = rawAmount === '' ? '' : String(rawAmount);
    var normalizedAmount = amount === '' ? null : Calculator.roundMoney(Math.max(0, toNumber(amount, 0)));
    var defaultValue = Calculator.roundMoney(Math.max(0, toNumber(defaultAmount, 0)));
    var next = sanitizeAmountRows(list, true).filter(function (row) {
      return row.date !== date;
    });
    if (normalizedAmount !== null && Math.abs(normalizedAmount - defaultValue) > 0.004) {
      next.push({ date: date, amount: String(normalizedAmount) });
    }
    return next.sort(function (left, right) {
      return left.date.localeCompare(right.date);
    });
  }

  function buildLoanFromState(state, existingLoan) {
    return Object.assign({}, existingLoan || {}, {
      id: existingLoan && existingLoan.id ? existingLoan.id : (state.existingLoanId || ''),
      name: String(state.name || '').trim() || (existingLoan && existingLoan.name) || 'Loan',
      lender: String(state.lender || '').trim(),
      principal: Calculator.roundMoney(Math.max(0, toNumber(state.principal, 0))),
      annualRate: Math.max(0, toNumber(state.annualRate, 0)),
      originalTenureMonths: Math.max(1, termToMonths(state.termValue, state.termUnit)),
      startDate: state.startDate,
      monthlyPayment: Calculator.roundMoney(Math.max(0, toNumber(state.monthlyPayment, 0))),
      monthlyExtraPayment: Calculator.roundMoney(Math.max(0, toNumber(state.monthlyExtraPayment, 0))),
      monthlyExtraOverrides: sanitizeAmountRows(state.monthlyExtraOverrides, true)
        .map(function (row) {
          return {
            date: row.date,
            amount: Calculator.roundMoney(Math.max(0, toNumber(row.amount, 0)))
          };
        })
        .filter(function (row) { return row.date; }),
      extraPayments: sanitizeAmountRows(state.extraPayments, false)
        .map(function (row) {
          return {
            date: row.date,
            amount: Calculator.roundMoney(Math.max(0, toNumber(row.amount, 0)))
          };
        })
        .filter(function (row) { return row.date && row.amount > 0; }),
      rateChanges: sanitizeRateRows(state.rateChanges)
        .map(function (row) {
          return {
            date: row.date,
            annualRate: Math.max(0, toNumber(row.annualRate, 0))
          };
        })
        .filter(function (row) { return row.date; }),
      offsetBalance: Calculator.roundMoney(Math.max(0, toNumber(state.offsetBalance, 0))),
      offsetBalanceChanges: sanitizeOffsetRows(state.offsetBalanceChanges)
        .map(function (row) {
          return {
            date: row.date,
            balance: Calculator.roundMoney(Math.max(0, toNumber(row.balance, 0)))
          };
        })
        .filter(function (row) { return row.date; }),
      prepaymentMode: state.prepaymentMode === 'reduceEmi' ? 'reduceEmi' : 'reduceTenure'
    });
  }

  function validateScenario(state) {
    var errors = {};
    var principal = toNumber(state.principal, 0);
    var annualRate = toNumber(state.annualRate, 0);
    var offsetBalance = Math.max(0, toNumber(state.offsetBalance, 0));
    var termMonths = termToMonths(state.termValue, state.termUnit);
    var monthlyPayment = Math.max(0, toNumber(state.monthlyPayment, 0));
    var monthlyExtra = Math.max(0, toNumber(state.monthlyExtraPayment, 0));
    var payment = (monthlyPayment > 0 ? monthlyPayment : Calculator.calculateEmi(principal, annualRate, termMonths)) + monthlyExtra;
    var firstMonthInterest = Math.max(0, principal - offsetBalance) * Calculator.calculateMonthlyRate(annualRate);

    if (principal <= 0) {
      errors.principal = 'Loan amount must be greater than zero.';
    }
    if (annualRate < 0) {
      errors.annualRate = 'Interest rate cannot be negative.';
    }
    if (termMonths <= 0) {
      errors.termValue = 'Loan term must be at least 1 month.';
    }
    if (!state.startDate) {
      errors.startDate = 'Start date is required.';
    }
    if (monthlyPayment < 0) {
      errors.monthlyPayment = 'Monthly payment cannot be negative.';
    }
    if (monthlyExtra < 0) {
      errors.monthlyExtraPayment = 'Extra payment cannot be negative.';
    }
    if (offsetBalance < 0) {
      errors.offsetBalance = 'Offset balance cannot be negative.';
    }
    if (principal > 0 && payment <= firstMonthInterest) {
      errors.monthlyPayment = 'Payment is too low to reduce the balance.';
    }

    sanitizeAmountRows(state.extraPayments, false).forEach(function (row, index) {
      var amount = toNumber(row.amount, 0);
      if (row.date && amount <= 0) {
        errors['extraPayments.' + index] = 'Extra payment must be greater than zero.';
      }
      if (!row.date && amount > 0) {
        errors['extraPayments.' + index] = 'Choose a month for this extra payment.';
      }
    });

    sanitizeRateRows(state.rateChanges).forEach(function (row, index) {
      if (!row.date) {
        errors['rateChanges.' + index] = 'Choose when the rate changes.';
      }
      if (row.annualRate === '' || toNumber(row.annualRate, -1) < 0) {
        errors['rateChanges.' + index] = 'Enter a valid interest rate change.';
      }
    });

    sanitizeOffsetRows(state.offsetBalanceChanges).forEach(function (row, index) {
      if (!row.date) {
        errors['offsetBalanceChanges.' + index] = 'Choose when the offset balance changes.';
      }
      if (row.balance === '' || toNumber(row.balance, -1) < 0) {
        errors['offsetBalanceChanges.' + index] = 'Enter a valid offset balance.';
      }
    });

    return errors;
  }

  function validateSave(state) {
    var errors = validateScenario(state);
    if (!String(state.name || '').trim()) {
      errors.name = 'Loan name is required to save this scenario.';
    }
    return errors;
  }

  function GenericListEditor(props) {
    var rows = props.rows;

    function updateRow(index, key, value) {
      var next = rows.slice();
      next[index] = Object.assign({}, next[index], {
        [key]: value
      });
      props.onChange(next);
    }

    function addRow() {
      props.onChange(rows.concat([props.createRow()]));
    }

    function removeRow(index) {
      props.onChange(rows.filter(function (_, rowIndex) {
        return rowIndex !== index;
      }));
    }

    return el('div', { className: 'list-editor' },
      rows.length
        ? rows.map(function (row, index) {
            return el('div', { key: props.idPrefix + '-' + index, className: 'list-editor__row list-editor__row--compact' },
              props.fields.map(function (field) {
                return el('label', { key: field.key, className: 'list-editor__cell' },
                  el('span', { className: 'list-editor__label' }, field.label),
                  el('input', {
                    className: 'field-control',
                    type: field.type,
                    min: field.min,
                    step: field.step,
                    inputMode: field.inputMode,
                    placeholder: field.placeholder,
                    value: row[field.key],
                    onChange: function (event) { updateRow(index, field.key, event.target.value); }
                  }),
                  props.errors && props.errors[props.errorPrefix + '.' + index]
                    ? el('span', { className: 'field__error' }, props.errors[props.errorPrefix + '.' + index])
                    : null
                );
              }),
              el('button', {
                className: 'button button--ghost button--small',
                type: 'button',
                onClick: function () { removeRow(index); }
              }, 'Remove')
            );
          })
        : el('p', { className: 'muted-copy' }, props.emptyText),
      el(Button, { variant: 'ghost', small: true, onClick: addRow }, props.addLabel)
    );
  }

  function ReportScheduleCard(props) {
    return el('div', { className: 'schedule-card' },
      el('div', { className: 'schedule-card__head' },
        el('strong', null, formatMonth(props.row.paymentDate)),
        el('span', { className: 'pill pill--subtle' }, formatMoney(props.row.totalPayment, props.currency))
      ),
      el('div', { className: 'schedule-card__grid' },
        el(StatCard, { label: 'Principal', value: formatMoney(props.row.principalPaid, props.currency) }),
        el(StatCard, { label: 'Interest', value: formatMoney(props.row.interestPaid, props.currency) }),
        el(StatCard, { label: 'Extra', value: formatMoney(props.row.extraPayment, props.currency) }),
        el(StatCard, { label: 'Balance', value: formatMoney(props.row.closingBalance, props.currency) })
      )
    );
  }

  function GoalHelperCard(props) {
    return el('div', { className: 'goal-helper surface-card' },
      el('div', { className: 'goal-helper__body' },
        el('strong', { className: 'goal-helper__title' }, props.title),
        el('p', { className: 'muted-copy' }, props.message)
      )
    );
  }

  function CalculatorPage() {
    var loanId = getSearchParam('loanId');
    var existingLoan = loanId ? Store.getLoanById(loanId) : null;
    var tabState = useState('input');
    var activeTab = tabState[0];
    var setActiveTab = tabState[1];
    var formState = useState(buildInitialState(existingLoan));
    var form = formState[0];
    var setForm = formState[1];
    var showAllPlannerState = useState(false);
    var showAllPlanner = showAllPlannerState[0];
    var setShowAllPlanner = showAllPlannerState[1];
    var saveMessageState = Common.useFlashMessage('');
    var saveMessage = saveMessageState[0];
    var setSaveMessage = saveMessageState[1];
    var goalModeState = useState('targetTenure');
    var goalMode = goalModeState[0];
    var setGoalMode = goalModeState[1];
    var goalValueState = useState('36');
    var goalValue = goalValueState[0];
    var setGoalValue = goalValueState[1];
    var currency = Store.getCurrency();

    if (loanId && !existingLoan) {
      return el(PageShell, {
        currentPage: 'calculator',
        title: 'Loan not found',
        subtitle: 'The selected loan is unavailable.',
        backHref: './loans.html'
      },
        el(EmptyState, {
          icon: '◌',
          title: 'Missing loan',
          message: 'Open another loan or start a new scenario.',
          actions: [
            el(Button, { key: 'home', href: './loans.html' }, 'Back to loans'),
            el(Button, { key: 'new', variant: 'ghost', href: './calculator.html' }, 'New calculator')
          ]
        })
      );
    }

    var scenarioErrors = useMemo(function () {
      return validateScenario(form);
    }, [form]);

    var previewLoan = useMemo(function () {
      return buildLoanFromState(form, existingLoan || {});
    }, [form, existingLoan]);

    var previewSnapshot = useMemo(function () {
      return Calculator.buildLoanSnapshot(previewLoan, Calculator.addMonths(previewLoan.startDate, -1) || previewLoan.startDate);
    }, [previewLoan]);

    var plannerRowsAll = previewSnapshot.schedule;
    var plannerOverrideMap = getMonthlyOverrideMap(form);
    var plannerRows = showAllPlanner ? plannerRowsAll : plannerRowsAll.slice(0, 12);
    var sliderMax = Math.max(10000, Math.ceil(toNumber(form.principal, 0) / 20 / 1000) * 1000 || 10000);

    var goalMessage = useMemo(function () {
      if (Object.keys(scenarioErrors).length) {
        return { title: 'Complete the core inputs', message: 'Enter a valid loan amount, rate, and term to unlock the goal helper.' };
      }
      if (goalMode === 'targetTenure') {
        var months = Math.max(1, Math.round(toNumber(goalValue, 0)));
        var requiredPayment = Calculator.findRequiredMonthlyPayment(previewLoan, months);
        return {
          title: 'Target tenure mode',
          message: 'To close this loan in about ' + Common.describeTenure(months) + ', target roughly ' + formatMoney(requiredPayment + previewLoan.monthlyExtraPayment, currency) + ' per month in total payments.'
        };
      }
      var paymentAmount = Math.max(0, toNumber(goalValue, 0));
      var estimatedMonths = Calculator.calculateTenureMonths(previewLoan.principal, previewLoan.annualRate, paymentAmount);
      return {
        title: 'Target EMI mode',
        message: paymentAmount > 0
          ? 'Paying about ' + formatMoney(paymentAmount, currency) + ' per month would finish the loan in roughly ' + Common.describeTenure(estimatedMonths) + '.'
          : 'Enter a payment amount to estimate the tenure.'
      };
    }, [goalMode, goalValue, previewLoan, scenarioErrors, currency]);

    function updateField(name, value) {
      setForm(function (current) {
        return Object.assign({}, current, {
          [name]: value
        });
      });
    }

    function updateArrayField(name, rows) {
      setForm(function (current) {
        return Object.assign({}, current, {
          [name]: rows
        });
      });
    }

    function handlePlannerValueChange(date, value) {
      setForm(function (current) {
        return Object.assign({}, current, {
          monthlyExtraOverrides: upsertMonthlyOverride(current.monthlyExtraOverrides, date, value, current.monthlyExtraPayment)
        });
      });
    }

    function handleSaveScenario() {
      var saveErrors = validateSave(form);
      if (Object.keys(saveErrors).length) {
        setActiveTab('save');
        setSaveMessage('Complete the required save fields first.');
        return;
      }

      var saved = Store.upsertLoan(buildLoanFromState(form, existingLoan));
      Common.navigateTo(Common.buildUrl('loan.html', { id: saved.id }));
    }

    var tabs = [
      { value: 'input', label: 'Input' },
      { value: 'report', label: 'Report' },
      { value: 'graph', label: 'Graph' },
      { value: 'save', label: 'Save' }
    ];

    return el(PageShell, {
      currentPage: 'calculator',
      title: 'Advanced EMI',
      subtitle: existingLoan ? 'Loaded from ' + existingLoan.name : 'Calculator with strategy and goal helpers.',
      backHref: existingLoan ? Common.buildUrl('loan.html', { id: existingLoan.id }) : './loans.html',
      flashMessage: saveMessage,
      actions: existingLoan
        ? el('a', { href: Common.buildUrl('loan.html', { id: existingLoan.id }), className: 'button button--ghost button--small' }, 'Open loan')
        : null
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'EMI',
          value: formatMoney(previewSnapshot.calculatedEmi, currency),
          hint: form.monthlyPayment ? 'Custom payment set' : 'Auto-calculated'
        }),
        el(StatCard, {
          label: 'Projected payoff',
          value: previewSnapshot.payoffDate ? formatMonth(previewSnapshot.payoffDate) : '—',
          hint: Common.describeTenure(previewSnapshot.schedule.length)
        }),
        el(StatCard, {
          label: 'Projected interest',
          value: formatMoney(previewSnapshot.projectedTotalInterest, currency),
          hint: previewLoan.prepaymentMode === 'reduceEmi'
            ? 'Minimum EMI can fall to ' + formatMoney(previewSnapshot.minimumScheduledPayment, currency)
            : previewSnapshot.monthsSaved + ' months saved vs baseline'
        })
      ),
      el(SectionCard, {
        title: 'Calculator',
        subtitle: 'Input, report, graph, and save.',
        action: el(TabBar, {
          label: 'Calculator tabs',
          tabs: tabs,
          value: activeTab,
          onChange: setActiveTab
        })
      },
        activeTab === 'input'
          ? el('div', { className: 'stack-gap' },
              el('div', { className: 'form-grid' },
                el(Field, {
                  label: 'Loan amount',
                  name: 'principal',
                  type: 'number',
                  min: '0',
                  step: '0.01',
                  inputMode: 'decimal',
                  value: form.principal,
                  onChange: function (event) { updateField('principal', event.target.value); },
                  error: scenarioErrors.principal,
                  placeholder: '0'
                }),
                el(Field, {
                  label: 'Annual interest rate (%)',
                  name: 'annualRate',
                  type: 'number',
                  min: '0',
                  step: '0.01',
                  inputMode: 'decimal',
                  value: form.annualRate,
                  onChange: function (event) { updateField('annualRate', event.target.value); },
                  error: scenarioErrors.annualRate,
                  placeholder: '0'
                }),
                el(Field, {
                  label: 'Loan term',
                  name: 'termValue',
                  type: 'number',
                  min: '1',
                  step: '1',
                  inputMode: 'numeric',
                  value: form.termValue,
                  onChange: function (event) { updateField('termValue', event.target.value); },
                  error: scenarioErrors.termValue,
                  placeholder: '20'
                }),
                el(Field, {
                  label: 'Unit',
                  name: 'termUnit',
                  as: 'select',
                  value: form.termUnit,
                  onChange: function (event) { updateField('termUnit', event.target.value); },
                  options: [
                    { value: 'years', label: 'Years' },
                    { value: 'months', label: 'Months' }
                  ]
                }),
                el(Field, {
                  label: 'Loan start date',
                  name: 'startDate',
                  type: 'date',
                  value: form.startDate,
                  onChange: function (event) { updateField('startDate', event.target.value); },
                  error: scenarioErrors.startDate
                }),
                el(Field, {
                  label: 'Monthly payment (optional)',
                  name: 'monthlyPayment',
                  type: 'number',
                  min: '0',
                  step: '0.01',
                  inputMode: 'decimal',
                  value: form.monthlyPayment,
                  onChange: function (event) { updateField('monthlyPayment', event.target.value); },
                  error: scenarioErrors.monthlyPayment,
                  hint: 'Leave blank to use the calculated EMI.'
                }),
                el(Field, {
                  label: 'Prepayment outcome',
                  name: 'prepaymentMode',
                  as: 'select',
                  value: form.prepaymentMode,
                  onChange: function (event) { updateField('prepaymentMode', event.target.value); },
                  options: [
                    { value: 'reduceTenure', label: 'Reduce tenure' },
                    { value: 'reduceEmi', label: 'Reduce EMI' }
                  ]
                }),
                el(Field, {
                  label: 'Interest saver / offset balance',
                  name: 'offsetBalance',
                  type: 'number',
                  min: '0',
                  step: '0.01',
                  inputMode: 'decimal',
                  value: form.offsetBalance,
                  onChange: function (event) { updateField('offsetBalance', event.target.value); },
                  error: scenarioErrors.offsetBalance,
                  hint: 'Reduces the balance used for interest calculations.'
                })
              ),
              el(SectionCard, {
                title: 'Monthly extra slider',
                subtitle: 'Adjust extra EMI quickly and see the impact instantly.'
              },
                el('div', { className: 'stack-gap' },
                  el('label', { className: 'field' },
                    el('span', { className: 'field__label' }, 'Default monthly extra'),
                    el('input', {
                      className: 'range-control',
                      type: 'range',
                      min: '0',
                      max: String(sliderMax),
                      step: '100',
                      value: String(Math.max(0, toNumber(form.monthlyExtraPayment, 0))),
                      onChange: function (event) { updateField('monthlyExtraPayment', event.target.value); }
                    }),
                    el('span', { className: 'field__hint' }, 'Slider range 0 to ' + formatMoney(sliderMax, currency))
                  ),
                  el(Field, {
                    label: 'Default monthly extra',
                    name: 'monthlyExtraPayment',
                    type: 'number',
                    min: '0',
                    step: '0.01',
                    inputMode: 'decimal',
                    value: form.monthlyExtraPayment,
                    onChange: function (event) { updateField('monthlyExtraPayment', event.target.value); },
                    error: scenarioErrors.monthlyExtraPayment,
                    hint: 'You can override each month below.'
                  })
                )
              ),
              el(SectionCard, {
                title: 'EMI vs tenure helper',
                subtitle: 'Switch between a target close date and a target monthly payment.'
              },
                el('div', { className: 'form-grid' },
                  el(Field, {
                    label: 'Helper mode',
                    name: 'goalMode',
                    as: 'select',
                    value: goalMode,
                    onChange: function (event) { setGoalMode(event.target.value); },
                    options: [
                      { value: 'targetTenure', label: 'Target tenure → required payment' },
                      { value: 'targetPayment', label: 'Target payment → estimated tenure' }
                    ]
                  }),
                  goalMode === 'targetTenure'
                    ? el(Field, {
                        label: 'Target months',
                        name: 'goalValue',
                        type: 'number',
                        min: '1',
                        step: '1',
                        inputMode: 'numeric',
                        value: goalValue,
                        onChange: function (event) { setGoalValue(event.target.value); }
                      })
                    : el(Field, {
                        label: 'Target monthly payment',
                        name: 'goalValue',
                        type: 'number',
                        min: '0',
                        step: '0.01',
                        inputMode: 'decimal',
                        value: goalValue,
                        onChange: function (event) { setGoalValue(event.target.value); }
                      })
                ),
                el(GoalHelperCard, goalMessage)
              ),
              el(SectionCard, {
                title: 'Monthly extra planner',
                subtitle: 'Set the extra amount for specific months.',
                action: plannerRowsAll.length > 12
                  ? el(Button, {
                      variant: 'ghost',
                      small: true,
                      onClick: function () { setShowAllPlanner(!showAllPlanner); }
                    }, showAllPlanner ? 'Show less' : 'Show all')
                  : null
              },
                plannerRows.length
                  ? el('div', { className: 'planner-list' },
                      plannerRows.map(function (row) {
                        var displayValue = Object.prototype.hasOwnProperty.call(plannerOverrideMap, row.paymentDate)
                          ? plannerOverrideMap[row.paymentDate]
                          : (form.monthlyExtraPayment || '0');
                        return el('div', { key: row.paymentDate, className: 'planner-row' },
                          el('div', { className: 'planner-row__meta' },
                            el('strong', null, formatMonth(row.paymentDate)),
                            el('span', null, 'Projected balance ' + formatMoney(row.closingBalance, currency))
                          ),
                          el('label', { className: 'planner-row__input' },
                            el('span', null, 'Monthly extra'),
                            el('input', {
                              className: 'field-control',
                              type: 'number',
                              min: '0',
                              step: '0.01',
                              inputMode: 'decimal',
                              value: displayValue,
                              onChange: function (event) {
                                handlePlannerValueChange(row.paymentDate, event.target.value);
                              }
                            })
                          )
                        );
                      })
                    )
                  : el('p', { className: 'muted-copy' }, 'Enter enough inputs to generate a schedule.')
              ),
              el(SectionCard, {
                title: 'Extra repayments',
                subtitle: 'Optional lump-sum prepayments.'
              },
                el(GenericListEditor, {
                  rows: form.extraPayments,
                  onChange: function (rows) { updateArrayField('extraPayments', rows); },
                  idPrefix: 'extra-payments',
                  errorPrefix: 'extraPayments',
                  errors: scenarioErrors,
                  addLabel: 'Add extra repayment',
                  emptyText: 'No one-time extra repayments added.',
                  createRow: function () { return { date: '', amount: '' }; },
                  fields: [
                    { key: 'date', label: 'Month', type: 'date' },
                    { key: 'amount', label: 'Amount', type: 'number', min: '0', step: '0.01', inputMode: 'decimal', placeholder: '0' }
                  ]
                })
              ),
              el(SectionCard, {
                title: 'Interest rate changes',
                subtitle: 'Simulate floating-rate changes.'
              },
                el(GenericListEditor, {
                  rows: form.rateChanges,
                  onChange: function (rows) { updateArrayField('rateChanges', rows); },
                  idPrefix: 'rate-changes',
                  errorPrefix: 'rateChanges',
                  errors: scenarioErrors,
                  addLabel: 'Add rate change',
                  emptyText: 'No rate changes added.',
                  createRow: function () { return { date: '', annualRate: '' }; },
                  fields: [
                    { key: 'date', label: 'Month', type: 'date' },
                    { key: 'annualRate', label: 'Rate (%)', type: 'number', min: '0', step: '0.01', inputMode: 'decimal', placeholder: '0' }
                  ]
                })
              ),
              el(SectionCard, {
                title: 'Offset balance changes',
                subtitle: 'Change the interest saver balance over time.'
              },
                el(GenericListEditor, {
                  rows: form.offsetBalanceChanges,
                  onChange: function (rows) { updateArrayField('offsetBalanceChanges', rows); },
                  idPrefix: 'offset-balance-changes',
                  errorPrefix: 'offsetBalanceChanges',
                  errors: scenarioErrors,
                  addLabel: 'Add offset balance change',
                  emptyText: 'No offset balance changes added.',
                  createRow: function () { return { date: '', balance: '' }; },
                  fields: [
                    { key: 'date', label: 'Month', type: 'date' },
                    { key: 'balance', label: 'Balance', type: 'number', min: '0', step: '0.01', inputMode: 'decimal', placeholder: '0' }
                  ]
                })
              )
            )
          : null,
        activeTab === 'report'
          ? Object.keys(scenarioErrors).length
            ? el(EmptyState, {
                icon: '!',
                title: 'Complete the input first',
                message: 'Fix the highlighted calculator inputs to generate a reliable report.',
                actions: el(Button, { onClick: function () { setActiveTab('input'); } }, 'Go to input')
              })
            : el('div', { className: 'stack-gap' },
                el('div', { className: 'summary-grid' },
                  el(StatCard, { label: 'Loan amount', value: formatMoney(previewLoan.principal, currency) }),
                  el(StatCard, { label: 'EMI', value: formatMoney(previewSnapshot.scheduledPayment, currency) }),
                  el(StatCard, { label: 'Total interest', value: formatMoney(previewSnapshot.projectedTotalInterest, currency) }),
                  el(StatCard, { label: 'Total payments', value: formatMoney(previewSnapshot.projectedTotalPayments, currency) }),
                  el(StatCard, { label: 'Interest saved', value: formatMoney(previewSnapshot.interestSaved, currency) }),
                  el(StatCard, { label: 'Tenure saved', value: previewSnapshot.monthsSaved + ' months' })
                ),
                previewSnapshot.hasNegativeAmortization
                  ? el('div', { className: 'warning-banner surface-card' }, 'This scenario leads to negative amortization. Increase the payment or extra amount.')
                  : null,
                el(GoalHelperCard, goalMessage),
                el('div', { className: 'schedule-list' },
                  previewSnapshot.schedule.slice(0, 8).map(function (row) {
                    return el(ReportScheduleCard, {
                      key: row.paymentDate,
                      row: row,
                      currency: currency
                    });
                  })
                )
              )
          : null,
        activeTab === 'graph'
          ? Object.keys(scenarioErrors).length
            ? el(EmptyState, {
                icon: '↗',
                title: 'Add valid inputs first',
                message: 'A graph appears when the schedule can be calculated.',
                actions: el(Button, { onClick: function () { setActiveTab('input'); } }, 'Go to input')
              })
            : el('div', { className: 'stack-gap' },
                el(BalanceChart, { rows: previewSnapshot.schedule, comparisonRows: previewSnapshot.baselineSchedule }),
                el('div', { className: 'summary-grid' },
                  el(StatCard, { label: 'Start balance', value: formatMoney(previewLoan.principal, currency) }),
                  el(StatCard, { label: 'Baseline payoff', value: previewSnapshot.baselinePayoffDate ? formatMonth(previewSnapshot.baselinePayoffDate) : '—' }),
                  el(StatCard, { label: 'Plan payoff', value: previewSnapshot.payoffDate ? formatMonth(previewSnapshot.payoffDate) : '—' }),
                  el(StatCard, { label: 'One-time extras', value: formatMoney(previewSnapshot.oneTimeExtraTotal, currency) })
                )
              )
          : null,
        activeTab === 'save'
          ? el('div', { className: 'stack-gap' },
              el('div', { className: 'form-grid' },
                el(Field, {
                  label: 'Loan name',
                  name: 'name',
                  value: form.name,
                  onChange: function (event) { updateField('name', event.target.value); },
                  error: validateSave(form).name,
                  placeholder: 'Home Loan'
                }),
                el(Field, {
                  label: 'Lender',
                  name: 'lender',
                  value: form.lender,
                  onChange: function (event) { updateField('lender', event.target.value); },
                  placeholder: 'Bank or lender'
                })
              ),
              el('div', { className: 'summary-grid' },
                el(StatCard, { label: 'Loan amount', value: formatMoney(previewLoan.principal, currency) }),
                el(StatCard, { label: 'EMI', value: formatMoney(previewSnapshot.scheduledPayment, currency) }),
                el(StatCard, { label: 'Payoff', value: previewSnapshot.payoffDate ? formatMonth(previewSnapshot.payoffDate) : '—' }),
                el(StatCard, { label: 'Interest', value: formatMoney(previewSnapshot.projectedTotalInterest, currency) })
              ),
              el('div', { className: 'form-actions' },
                el(Button, { variant: 'ghost', onClick: function () { setActiveTab('input'); } }, 'Back to input'),
                el(Button, { onClick: handleSaveScenario }, existingLoan ? 'Update loan' : 'Save as loan')
              )
            )
          : null
      )
    );
  }

  return {
    CalculatorPage: CalculatorPage
  };
});
