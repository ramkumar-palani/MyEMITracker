(function (root, factory) {
  root.EmiTrackerFormPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { FormPage: function FormPageFallback() { return null; } };
  }

  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var Field = Common.Field;
  var formatMoney = Common.formatMoney;
  var getSearchParam = Common.getSearchParam;
  var splitTermMonths = Common.splitTermMonths;
  var termToMonths = Common.termToMonths;
  var todayIso = Common.todayIso;
  var toNumber = Common.toNumber;

  function sanitizeExtraRows(rows) {
    return (Array.isArray(rows) ? rows : []).map(function (row) {
      return {
        date: row && row.date ? String(row.date) : '',
        amount: row && row.amount !== undefined ? String(row.amount) : ''
      };
    });
  }

  function buildInitialState(existingLoan) {
    var baseTerm = splitTermMonths(existingLoan ? existingLoan.originalTenureMonths : 240);
    return {
      name: existingLoan ? existingLoan.name : '',
      lender: existingLoan ? existingLoan.lender : '',
      principal: existingLoan ? String(existingLoan.principal) : '',
      annualRate: existingLoan ? String(existingLoan.annualRate) : '',
      termValue: baseTerm.termValue,
      termUnit: baseTerm.termUnit,
      startDate: existingLoan ? existingLoan.startDate : todayIso(),
      monthlyPayment: existingLoan && existingLoan.monthlyPayment ? String(existingLoan.monthlyPayment) : '',
      monthlyExtraPayment: existingLoan && existingLoan.monthlyExtraPayment ? String(existingLoan.monthlyExtraPayment) : '',
      priorityRank: existingLoan && existingLoan.priorityRank ? String(existingLoan.priorityRank) : '',
      prepaymentMode: existingLoan && existingLoan.prepaymentMode ? existingLoan.prepaymentMode : 'reduceTenure',
      extraPayments: sanitizeExtraRows(existingLoan ? existingLoan.extraPayments : [])
    };
  }

  function buildLoanFromState(state, existingLoan) {
    var termMonths = termToMonths(state.termValue, state.termUnit);
    return Object.assign({}, existingLoan || {}, {
      id: existingLoan && existingLoan.id ? existingLoan.id : '',
      name: String(state.name || '').trim(),
      lender: String(state.lender || '').trim(),
      principal: Calculator.roundMoney(Math.max(0, toNumber(state.principal, 0))),
      annualRate: Math.max(0, toNumber(state.annualRate, 0)),
      originalTenureMonths: Math.max(1, termMonths),
      startDate: state.startDate,
      monthlyPayment: Calculator.roundMoney(Math.max(0, toNumber(state.monthlyPayment, 0))),
      monthlyExtraPayment: Calculator.roundMoney(Math.max(0, toNumber(state.monthlyExtraPayment, 0))),
      priorityRank: Math.max(0, Math.round(toNumber(state.priorityRank, 0))),
      prepaymentMode: state.prepaymentMode === 'reduceEmi' ? 'reduceEmi' : 'reduceTenure',
      extraPayments: sanitizeExtraRows(state.extraPayments)
        .map(function (row) {
          return {
            date: row.date,
            amount: Calculator.roundMoney(Math.max(0, toNumber(row.amount, 0)))
          };
        })
        .filter(function (row) {
          return row.date && row.amount > 0;
        })
        .sort(function (left, right) {
          return left.date.localeCompare(right.date);
        })
    });
  }

  function validate(state) {
    var errors = {};
    var principal = toNumber(state.principal, 0);
    var annualRate = toNumber(state.annualRate, 0);
    var termMonths = termToMonths(state.termValue, state.termUnit);
    var monthlyPayment = Math.max(0, toNumber(state.monthlyPayment, 0));
    var monthlyExtraPayment = Math.max(0, toNumber(state.monthlyExtraPayment, 0));
    var effectivePayment = (monthlyPayment > 0 ? monthlyPayment : Calculator.calculateEmi(principal, annualRate, termMonths)) + monthlyExtraPayment;
    var firstMonthInterest = principal * Calculator.calculateMonthlyRate(annualRate);

    if (!String(state.name || '').trim()) {
      errors.name = 'Loan name is required.';
    }
    if (principal <= 0) {
      errors.principal = 'Loan amount must be greater than zero.';
    }
    if (annualRate < 0) {
      errors.annualRate = 'Interest rate cannot be negative.';
    }
    if (termMonths <= 0) {
      errors.termValue = 'Loan term must be at least 1 month.';
    }
    if (!state.startDate) {
      errors.startDate = 'Start date is required.';
    }
    if (monthlyPayment < 0) {
      errors.monthlyPayment = 'Monthly payment cannot be negative.';
    }
    if (monthlyExtraPayment < 0) {
      errors.monthlyExtraPayment = 'Extra payment cannot be negative.';
    }
    if (principal > 0 && effectivePayment <= firstMonthInterest) {
      errors.monthlyPayment = 'Payment is too low to reduce the balance.';
    }
    if (toNumber(state.priorityRank, 0) < 0) {
      errors.priorityRank = 'Priority rank cannot be negative.';
    }

    sanitizeExtraRows(state.extraPayments).forEach(function (row, index) {
      var amount = toNumber(row.amount, 0);
      if (row.date && amount <= 0) {
        errors['extraPayments.' + index] = 'Extra payment must be greater than zero.';
      }
      if (!row.date && amount > 0) {
        errors['extraPayments.' + index] = 'Choose a month for each one-time extra payment.';
      }
    });

    return errors;
  }

  function ExtraPaymentEditor(props) {
    var rows = props.rows;
    var errors = props.errors || {};

    function updateRow(index, key, value) {
      var next = rows.slice();
      next[index] = Object.assign({}, next[index], {
        [key]: value
      });
      props.onChange(next);
    }

    function removeRow(index) {
      props.onChange(rows.filter(function (_, rowIndex) {
        return rowIndex !== index;
      }));
    }

    function addRow() {
      props.onChange(rows.concat([{ date: '', amount: '' }]));
    }

    return el('div', { className: 'list-editor' },
      rows.length
        ? rows.map(function (row, index) {
            return el('div', { key: 'extra-' + index, className: 'list-editor__row' },
              el('label', { className: 'list-editor__cell' },
                el('span', { className: 'list-editor__label' }, 'Month'),
                el('input', {
                  className: 'field-control',
                  type: 'date',
                  value: row.date,
                  onChange: function (event) { updateRow(index, 'date', event.target.value); }
                }),
                errors['extraPayments.' + index] ? el('span', { className: 'field__error' }, errors['extraPayments.' + index]) : null
              ),
              el('label', { className: 'list-editor__cell' },
                el('span', { className: 'list-editor__label' }, 'Amount'),
                el('input', {
                  className: 'field-control',
                  type: 'number',
                  min: '0',
                  step: '0.01',
                  inputMode: 'decimal',
                  value: row.amount,
                  placeholder: 'Amount',
                  onChange: function (event) { updateRow(index, 'amount', event.target.value); }
                })
              ),
              el('button', {
                className: 'button button--ghost button--small',
                type: 'button',
                onClick: function () { removeRow(index); }
              }, 'Remove')
            );
          })
        : el('p', { className: 'muted-copy' }, 'No one-time extra payments added.'),
      el(Button, { variant: 'ghost', small: true, onClick: addRow }, 'Add one-time extra payment')
    );
  }

  function FormPage() {
    var loanId = getSearchParam('id');
    var existingLoan = loanId ? Store.getLoanById(loanId) : null;
    var formState = useState(buildInitialState(existingLoan));
    var form = formState[0];
    var setForm = formState[1];
    var errorsState = useState({});
    var errors = errorsState[0];
    var setErrors = errorsState[1];

    var previewLoan = useMemo(function () {
      return buildLoanFromState(form, existingLoan || {});
    }, [form, existingLoan]);

    var previewSnapshot = useMemo(function () {
      return Calculator.buildLoanSnapshot(previewLoan, Calculator.addMonths(previewLoan.startDate, -1) || previewLoan.startDate);
    }, [previewLoan]);

    function updateField(name, value) {
      setForm(function (current) {
        return Object.assign({}, current, {
          [name]: value
        });
      });
    }

    function handleSubmit(event) {
      event.preventDefault();
      var nextErrors = validate(form);
      setErrors(nextErrors);
      if (Object.keys(nextErrors).length) {
        return;
      }

      var saved = Store.upsertLoan(buildLoanFromState(form, existingLoan));
      Common.navigateTo(Common.buildUrl('loan.html', { id: saved.id }));
    }

    if (loanId && !existingLoan) {
      return el(PageShell, {
        currentPage: 'loans',
        title: 'Loan not found',
        subtitle: 'This loan may have been deleted.',
        backHref: './loans.html'
      },
        el(SectionCard, { title: 'Missing loan' },
          el('p', { className: 'muted-copy' }, 'Go back to loans and open a valid item.'),
          el(Button, { href: './loans.html' }, 'Back to loans')
        )
      );
    }

    return el(PageShell, {
      currentPage: 'loans',
      title: existingLoan ? 'Edit loan' : 'Add loan',
      subtitle: existingLoan ? 'Update basics, strategy, and priority.' : 'Create a new loan.',
      backHref: existingLoan ? Common.buildUrl('loan.html', { id: existingLoan.id }) : './loans.html',
      actions: el('a', { href: './calculator.html', className: 'button button--ghost button--small' }, 'Open calculator')
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'EMI',
          value: formatMoney(previewSnapshot.calculatedEmi, Store.getCurrency()),
          hint: form.monthlyPayment ? 'Custom monthly payment enabled' : 'Auto-calculated'
        }),
        el(StatCard, {
          label: 'Projected payoff',
          value: previewSnapshot.payoffDate ? Common.formatMonth(previewSnapshot.payoffDate) : '—',
          hint: Common.describeTenure(previewSnapshot.schedule.length)
        }),
        el(StatCard, {
          label: 'Projected interest',
          value: formatMoney(previewSnapshot.projectedTotalInterest, Store.getCurrency()),
          hint: previewLoan.prepaymentMode === 'reduceEmi' ? 'EMI recast mode' : 'Tenure reduction mode'
        })
      ),
      el(SectionCard, {
        title: 'Loan details',
        subtitle: 'Set the main EMI inputs here. Use Advanced for deeper scenarios.'
      },
        el('form', { className: 'form-stack', onSubmit: handleSubmit },
          el('div', { className: 'form-grid' },
            el(Field, {
              label: 'Loan name',
              name: 'name',
              value: form.name,
              onChange: function (event) { updateField('name', event.target.value); },
              error: errors.name,
              placeholder: 'Home Loan'
            }),
            el(Field, {
              label: 'Lender',
              name: 'lender',
              value: form.lender,
              onChange: function (event) { updateField('lender', event.target.value); },
              placeholder: 'Bank or lender'
            }),
            el(Field, {
              label: 'Loan amount',
              name: 'principal',
              type: 'number',
              min: '0',
              step: '0.01',
              inputMode: 'decimal',
              value: form.principal,
              onChange: function (event) { updateField('principal', event.target.value); },
              error: errors.principal,
              placeholder: '0'
            }),
            el(Field, {
              label: 'Annual interest rate (%)',
              name: 'annualRate',
              type: 'number',
              min: '0',
              step: '0.01',
              inputMode: 'decimal',
              value: form.annualRate,
              onChange: function (event) { updateField('annualRate', event.target.value); },
              error: errors.annualRate,
              placeholder: '0'
            }),
            el(Field, {
              label: 'Loan term',
              name: 'termValue',
              type: 'number',
              min: '1',
              step: '1',
              inputMode: 'numeric',
              value: form.termValue,
              onChange: function (event) { updateField('termValue', event.target.value); },
              error: errors.termValue,
              placeholder: '20'
            }),
            el(Field, {
              label: 'Unit',
              name: 'termUnit',
              as: 'select',
              value: form.termUnit,
              onChange: function (event) { updateField('termUnit', event.target.value); },
              options: [
                { value: 'years', label: 'Years' },
                { value: 'months', label: 'Months' }
              ]
            }),
            el(Field, {
              label: 'Start date',
              name: 'startDate',
              type: 'date',
              value: form.startDate,
              onChange: function (event) { updateField('startDate', event.target.value); },
              error: errors.startDate
            }),
            el(Field, {
              label: 'Monthly payment (optional)',
              name: 'monthlyPayment',
              type: 'number',
              min: '0',
              step: '0.01',
              inputMode: 'decimal',
              value: form.monthlyPayment,
              onChange: function (event) { updateField('monthlyPayment', event.target.value); },
              error: errors.monthlyPayment,
              hint: 'Leave blank to use the calculated EMI.'
            }),
            el(Field, {
              label: 'Default monthly extra',
              name: 'monthlyExtraPayment',
              type: 'number',
              min: '0',
              step: '0.01',
              inputMode: 'decimal',
              value: form.monthlyExtraPayment,
              onChange: function (event) { updateField('monthlyExtraPayment', event.target.value); },
              error: errors.monthlyExtraPayment,
              hint: 'You can fine-tune each month later.'
            }),
            el(Field, {
              label: 'Priority rank',
              name: 'priorityRank',
              type: 'number',
              min: '0',
              step: '1',
              inputMode: 'numeric',
              value: form.priorityRank,
              onChange: function (event) { updateField('priorityRank', event.target.value); },
              error: errors.priorityRank,
              hint: 'Used when the strategy engine is set to Custom priority.'
            }),
            el(Field, {
              label: 'Prepayment outcome',
              name: 'prepaymentMode',
              as: 'select',
              value: form.prepaymentMode,
              onChange: function (event) { updateField('prepaymentMode', event.target.value); },
              options: [
                { value: 'reduceTenure', label: 'Reduce tenure' },
                { value: 'reduceEmi', label: 'Reduce EMI' }
              ]
            })
          ),
          el('div', { className: 'stack-gap' },
            el('div', { className: 'stack-gap__head' },
              el('h3', { className: 'stack-gap__title' }, 'One-time extra payments'),
              el('p', { className: 'muted-copy' }, 'Optional lump-sum prepayments.')
            ),
            el(ExtraPaymentEditor, {
              rows: form.extraPayments,
              errors: errors,
              onChange: function (rows) { updateField('extraPayments', rows); }
            })
          ),
          el('div', { className: 'form-actions' },
            el(Button, { href: existingLoan ? Common.buildUrl('loan.html', { id: existingLoan.id }) : './loans.html', variant: 'ghost' }, 'Cancel'),
            el(Button, { type: 'submit' }, existingLoan ? 'Save changes' : 'Create loan')
          )
        )
      )
    );
  }

  return {
    FormPage: FormPage
  };
});
