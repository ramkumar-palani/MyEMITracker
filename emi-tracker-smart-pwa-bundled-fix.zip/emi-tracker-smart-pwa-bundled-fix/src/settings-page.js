(function (root, factory) {
  root.EmiTrackerSettingsPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { SettingsPage: function SettingsPageFallback() { return null; } };
  }

  var runtimeRoot = typeof globalThis !== 'undefined' ? globalThis : {};
  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var Field = Common.Field;
  var CurrencyPicker = Common.CurrencyPicker;
  var formatMoney = Common.formatMoney;
  var describeDueDate = Common.describeDueDate;

  function buildDueSoon(loans, daysAhead) {
    var today = Calculator.toIsoDate(new Date());
    return loans.map(function (loan) {
      var snapshot = Calculator.buildLoanSnapshot(loan, today);
      var dueDate = snapshot.nextDueDate;
      var diff = dueDate ? Calculator.daysBetween(today, dueDate) : 9999;
      return {
        loan: loan,
        snapshot: snapshot,
        diff: diff
      };
    }).filter(function (item) {
      return item.snapshot.nextDueDate && item.diff >= 0 && item.diff <= daysAhead;
    }).sort(function (left, right) {
      return left.diff - right.diff;
    });
  }

  function flattenPaymentLog(loans) {
    return loans.reduce(function (rows, loan) {
      return rows.concat((loan.actualPayments || []).map(function (item) {
        return {
          loan: loan.name,
          dueDate: item.date,
          amount: item.amount,
          paidOn: item.paidOn,
          note: item.note
        };
      }));
    }, []);
  }

  function SettingsPage() {
    var settingsState = useState(Store.getSettings());
    var settings = settingsState[0];
    var setSettings = settingsState[1];
    var loansState = useState(Store.getLoans());
    var loans = loansState[0];
    var setLoans = loansState[1];
    var flashState = Common.useFlashMessage('');
    var flashMessage = flashState[0];
    var setFlashMessage = flashState[1];
    var permissionState = useState(runtimeRoot.Notification ? runtimeRoot.Notification.permission : 'unsupported');
    var permission = permissionState[0];
    var setPermission = permissionState[1];

    var dueSoon = useMemo(function () {
      return buildDueSoon(loans, settings.reminderDaysBefore);
    }, [loans, settings.reminderDaysBefore]);

    function updateSettings(partial) {
      var next = Store.setSettings(Object.assign({}, settings, partial));
      setSettings(next);
      if (partial.theme) {
        Common.applyTheme(next.theme);
      }
    }

    function handleNotificationPermission() {
      if (runtimeRoot.EmiTrackerPWA && typeof runtimeRoot.EmiTrackerPWA.requestNotificationPermission === 'function') {
        runtimeRoot.EmiTrackerPWA.requestNotificationPermission().then(function (nextPermission) {
          setPermission(nextPermission || (runtimeRoot.Notification ? runtimeRoot.Notification.permission : 'unsupported'));
          setFlashMessage(nextPermission === 'granted' ? 'Browser notifications enabled.' : 'Notification permission not granted.');
        });
        return;
      }
      if (runtimeRoot.Notification && typeof runtimeRoot.Notification.requestPermission === 'function') {
        runtimeRoot.Notification.requestPermission().then(function (nextPermission) {
          setPermission(nextPermission);
          setFlashMessage(nextPermission === 'granted' ? 'Browser notifications enabled.' : 'Notification permission not granted.');
        });
      }
    }

    function handleTestNotification() {
      if (runtimeRoot.EmiTrackerPWA && typeof runtimeRoot.EmiTrackerPWA.triggerTestNotification === 'function') {
        runtimeRoot.EmiTrackerPWA.triggerTestNotification();
        setFlashMessage('Test reminder sent.');
      }
    }

    function handleExportLoansCsv() {
      Common.downloadCsv('emi-loans.csv', loans.map(function (loan) {
        var snapshot = Calculator.buildLoanSnapshot(loan, new Date());
        return {
          loanName: loan.name,
          lender: loan.lender,
          loanAmount: loan.principal,
          remainingBalance: snapshot.remainingBalance,
          monthlyDue: snapshot.nextDueAmount || snapshot.totalRecurringPayment,
          payoffDate: snapshot.payoffDate,
          interestSaved: snapshot.interestSaved,
          theme: settings.theme,
          currency: settings.currency
        };
      }), [
        { key: 'loanName', label: 'Loan name' },
        { key: 'lender', label: 'Lender' },
        { key: 'loanAmount', label: 'Loan amount' },
        { key: 'remainingBalance', label: 'Remaining balance' },
        { key: 'monthlyDue', label: 'Monthly due' },
        { key: 'payoffDate', label: 'Payoff date' },
        { key: 'interestSaved', label: 'Interest saved' },
        { key: 'currency', label: 'Currency' },
        { key: 'theme', label: 'Theme' }
      ]);
      setFlashMessage('Loans CSV exported.');
    }

    function handleExportPaymentsCsv() {
      Common.downloadCsv('emi-payment-history.csv', flattenPaymentLog(loans), [
        { key: 'loan', label: 'Loan' },
        { key: 'dueDate', label: 'Due date' },
        { key: 'amount', label: 'Amount' },
        { key: 'paidOn', label: 'Paid on' },
        { key: 'note', label: 'Note' }
      ]);
      setFlashMessage('Payment history CSV exported.');
    }

    function handleSeedSample() {
      setLoans(Store.seedSampleLoans());
      setFlashMessage('Sample loans loaded.');
    }

    return el(PageShell, {
      currentPage: 'settings',
      title: 'Settings',
      subtitle: 'Theme, currency, reminders, and export',
      flashMessage: flashMessage
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'Currency',
          value: settings.currency,
          hint: 'Used across all pages'
        }),
        el(StatCard, {
          label: 'Theme',
          value: settings.theme === 'light' ? 'Light' : 'Dark',
          hint: 'Applies instantly'
        }),
        el(StatCard, {
          label: 'Reminder window',
          value: settings.reminderDaysBefore + ' days',
          hint: settings.remindersEnabled ? 'Reminders enabled' : 'Reminders disabled'
        })
      ),
      el(SectionCard, {
        title: 'Appearance',
        subtitle: 'Switch the app look and feel.'
      },
        el('div', { className: 'form-grid' },
          el(CurrencyPicker, {
            value: settings.currency,
            onChange: function (event) { updateSettings({ currency: event.target.value }); }
          }),
          el(Field, {
            label: 'Theme',
            name: 'theme',
            as: 'select',
            value: settings.theme,
            onChange: function (event) { updateSettings({ theme: event.target.value }); },
            options: Store.THEME_OPTIONS.map(function (theme) {
              return { value: theme, label: theme === 'light' ? 'Light' : 'Dark' };
            })
          })
        )
      ),
      el(SectionCard, {
        title: 'Payment reminders',
        subtitle: 'Browser reminders work best when the app is opened regularly and notification permission is granted.'
      },
        el('div', { className: 'form-grid' },
          el(Field, {
            label: 'Reminders',
            name: 'remindersEnabled',
            as: 'select',
            value: settings.remindersEnabled ? 'on' : 'off',
            onChange: function (event) { updateSettings({ remindersEnabled: event.target.value === 'on' }); },
            options: [
              { value: 'on', label: 'On' },
              { value: 'off', label: 'Off' }
            ]
          }),
          el(Field, {
            label: 'Notify this many days before due date',
            name: 'reminderDaysBefore',
            type: 'number',
            min: '1',
            max: '14',
            step: '1',
            inputMode: 'numeric',
            value: String(settings.reminderDaysBefore),
            onChange: function (event) { updateSettings({ reminderDaysBefore: event.target.value }); }
          })
        ),
        el('div', { className: 'topbar__action-group' },
          el(Button, { variant: 'ghost', onClick: handleNotificationPermission }, permission === 'granted' ? 'Notifications ready' : 'Enable notifications'),
          el(Button, { onClick: handleTestNotification, disabled: permission !== 'granted' }, 'Send test reminder')
        ),
        dueSoon.length
          ? el('div', { className: 'feed-list' },
              dueSoon.map(function (item) {
                return el('div', { key: item.loan.id, className: 'feed-item surface-card' },
                  el('div', null,
                    el('strong', null, item.loan.name),
                    el('p', { className: 'muted-copy' }, describeDueDate(item.snapshot.nextDueDate))
                  ),
                  el('div', { className: 'feed-item__meta' },
                    el('strong', null, formatMoney(item.snapshot.nextDueAmount || item.snapshot.totalRecurringPayment, settings.currency)),
                    el('span', null, item.snapshot.nextDueDate)
                  )
                );
              })
            )
          : el('p', { className: 'muted-copy' }, 'No loan is due within the current reminder window.')
      ),
      el(SectionCard, {
        title: 'Export & sample data',
        subtitle: 'Download your data or load the example setup.'
      },
        el('div', { className: 'quick-action-grid' },
          el('button', { type: 'button', className: 'quick-action-card surface-card', onClick: handleExportLoansCsv },
            el('div', { className: 'quick-action-card__icon' }, '⇩'),
            el('div', { className: 'quick-action-card__body' },
              el('strong', { className: 'quick-action-card__title' }, 'Export loans CSV'),
              el('span', { className: 'quick-action-card__description' }, 'Summary of all saved loans and payoff details.')
            )
          ),
          el('button', { type: 'button', className: 'quick-action-card surface-card', onClick: handleExportPaymentsCsv },
            el('div', { className: 'quick-action-card__icon' }, '⤓'),
            el('div', { className: 'quick-action-card__body' },
              el('strong', { className: 'quick-action-card__title' }, 'Export payment history'),
              el('span', { className: 'quick-action-card__description' }, 'CSV of logged real-world payments.')
            )
          ),
          el('button', { type: 'button', className: 'quick-action-card surface-card', onClick: handleSeedSample },
            el('div', { className: 'quick-action-card__icon' }, '✦'),
            el('div', { className: 'quick-action-card__body' },
              el('strong', { className: 'quick-action-card__title' }, 'Load sample data'),
              el('span', { className: 'quick-action-card__description' }, 'Explore insights, tracking, and reminders with example loans.')
            )
          )
        )
      )
    );
  }

  return {
    SettingsPage: SettingsPage
  };
});
