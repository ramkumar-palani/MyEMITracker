(function (root, factory) {
  root.EmiTrackerLoanPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { LoanPage: function LoanPageFallback() { return null; } };
  }

  var runtimeRoot = typeof globalThis !== 'undefined' ? globalThis : {};
  var el = Common.el;
  var useEffect = React.useEffect;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var BalanceChart = Common.BalanceChart;
  var EmptyState = Common.EmptyState;
  var ProgressBar = Common.ProgressBar;
  var formatMoney = Common.formatMoney;
  var formatMonth = Common.formatMonth;
  var formatDate = Common.formatDate;
  var getSearchParam = Common.getSearchParam;
  var describeTenure = Common.describeTenure;
  var toNumber = Common.toNumber;

  function buildOverrideMap(overrides) {
    return (Array.isArray(overrides) ? overrides : []).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }
      accumulator[item.date] = item.amount;
      return accumulator;
    }, {});
  }

  function getMonthlyExtraValue(loan, date) {
    var map = buildOverrideMap(loan.monthlyExtraOverrides);
    return Object.prototype.hasOwnProperty.call(map, date) ? map[date] : loan.monthlyExtraPayment;
  }

  function updateOverrideList(currentList, date, amount, defaultAmount) {
    var normalizedAmount = Calculator.roundMoney(Math.max(0, toNumber(amount, 0)));
    var next = (Array.isArray(currentList) ? currentList : []).filter(function (item) {
      return item.date !== date;
    });
    if (Math.abs(normalizedAmount - defaultAmount) > 0.004) {
      next.push({ date: date, amount: normalizedAmount });
    }
    return next.sort(function (left, right) {
      return left.date.localeCompare(right.date);
    });
  }

  function buildActualPaymentMap(list) {
    return (Array.isArray(list) ? list : []).reduce(function (accumulator, item) {
      if (!item || !item.date) {
        return accumulator;
      }
      accumulator[item.date] = {
        amount: item.amount,
        paidOn: item.paidOn || '',
        note: item.note || ''
      };
      return accumulator;
    }, {});
  }

  function buildPaymentDrafts(loan, schedule) {
    var paymentMap = buildActualPaymentMap(loan.actualPayments);
    return (Array.isArray(schedule) ? schedule : []).reduce(function (accumulator, row) {
      var saved = paymentMap[row.paymentDate] || null;
      accumulator[row.paymentDate] = {
        amount: saved ? String(saved.amount) : '',
        paidOn: saved ? saved.paidOn : '',
        note: saved ? saved.note : ''
      };
      return accumulator;
    }, {});
  }

  function normalizePaymentDrafts(schedule, drafts) {
    return (Array.isArray(schedule) ? schedule : []).reduce(function (accumulator, row) {
      var draft = drafts[row.paymentDate] || {};
      var amountValue = draft.amount === '' || draft.amount === undefined ? '' : String(draft.amount);
      var hasAnyValue = amountValue !== '' || !!draft.paidOn || !!draft.note;
      if (!hasAnyValue) {
        return accumulator;
      }
      accumulator.push({
        date: row.paymentDate,
        amount: Calculator.roundMoney(Math.max(0, toNumber(amountValue, 0))),
        paidOn: draft.paidOn || '',
        note: draft.note ? String(draft.note) : ''
      });
      return accumulator;
    }, []).sort(function (left, right) {
      return left.date.localeCompare(right.date);
    });
  }

  function buildLoanInsights(loan, snapshot, currency) {
    var insights = [];
    insights.push('This plan saves about ' + formatMoney(snapshot.interestSaved, currency) + ' and trims ' + snapshot.monthsSaved + ' months compared with no extra payments.');
    if (loan.prepaymentMode === 'reduceEmi') {
      insights.push('Prepayments are set to reduce EMI. The scheduled payment could recast down to around ' + formatMoney(snapshot.minimumScheduledPayment, currency) + '.');
    } else {
      insights.push('Prepayments are set to reduce tenure. Your payoff is projected for ' + (snapshot.payoffDate ? formatMonth(snapshot.payoffDate) : '—') + '.');
    }
    if (snapshot.hasActualTracking && snapshot.unloggedDueCount > 0) {
      insights.push('You have ' + snapshot.unloggedDueCount + ' due month' + (snapshot.unloggedDueCount === 1 ? '' : 's') + ' without a logged real payment yet.');
    }
    if (snapshot.activeAnnualRate >= 12) {
      insights.push('This loan has a relatively high current rate at ' + snapshot.activeAnnualRate.toFixed(2) + '%, so extra payments matter more here.');
    }
    return insights.slice(0, 4);
  }

  function PlannerRow(props) {
    return el('div', { className: 'planner-row' },
      el('div', { className: 'planner-row__meta' },
        el('strong', null, formatMonth(props.row.paymentDate)),
        el('span', null, 'Due ' + formatDate(props.row.paymentDate))
      ),
      el('div', { className: 'planner-row__detail' },
        el('span', null, 'Base EMI ' + formatMoney(props.row.scheduledPaymentTarget || props.snapshot.scheduledPayment, props.currency)),
        el('span', null, 'Balance ' + formatMoney(props.row.closingBalance, props.currency))
      ),
      el('label', { className: 'planner-row__input' },
        el('span', null, 'Monthly extra'),
        el('input', {
          className: 'field-control',
          type: 'number',
          min: '0',
          step: '0.01',
          inputMode: 'decimal',
          value: props.value,
          onChange: function (event) { props.onChange(event.target.value); }
        })
      )
    );
  }

  function PaymentTrackerRow(props) {
    var draft = props.draft;
    return el('div', { className: 'planner-row payment-row' },
      el('div', { className: 'planner-row__meta' },
        el('strong', null, formatMonth(props.row.paymentDate)),
        el('span', null, props.row.isActualPayment ? 'Logged payment' : 'Planned payment')
      ),
      el('div', { className: 'planner-row__detail' },
        el('span', null, 'Planned ' + formatMoney(props.row.plannedTotalPayment, props.currency)),
        el('span', null, props.row.isActualPayment ? 'Actual ' + formatMoney(props.row.totalPayment, props.currency) : 'Balance ' + formatMoney(props.row.closingBalance, props.currency))
      ),
      el('div', { className: 'payment-row__grid' },
        el('label', { className: 'planner-row__input' },
          el('span', null, 'Amount paid'),
          el('input', {
            className: 'field-control',
            type: 'number',
            min: '0',
            step: '0.01',
            inputMode: 'decimal',
            value: draft.amount,
            onChange: function (event) { props.onChange('amount', event.target.value); }
          })
        ),
        el('label', { className: 'planner-row__input' },
          el('span', null, 'Paid on'),
          el('input', {
            className: 'field-control',
            type: 'date',
            value: draft.paidOn,
            onChange: function (event) { props.onChange('paidOn', event.target.value); }
          })
        ),
        el('label', { className: 'planner-row__input field--wide' },
          el('span', null, 'Note'),
          el('input', {
            className: 'field-control',
            value: draft.note,
            placeholder: 'Optional note',
            onChange: function (event) { props.onChange('note', event.target.value); }
          })
        )
      ),
      el('div', { className: 'topbar__action-group payment-row__actions' },
        el(Button, { variant: 'ghost', small: true, onClick: props.onFillPlanned }, 'Use planned amount'),
        props.row.isActualPayment ? el('span', { className: 'pill pill--subtle' }, 'Variance ' + formatMoney(props.row.paymentVariance, props.currency)) : null
      )
    );
  }

  function ScheduleCard(props) {
    return el('div', { className: 'schedule-card' },
      el('div', { className: 'schedule-card__head' },
        el('strong', null, formatMonth(props.row.paymentDate)),
        el('div', { className: 'chip-row' },
          el('span', { className: 'pill pill--subtle' }, 'Rate ' + props.row.annualRate.toFixed(2) + '%'),
          props.row.isActualPayment ? el('span', { className: 'pill' }, 'Actual logged') : el('span', { className: 'pill pill--subtle' }, 'Planned')
        )
      ),
      el('div', { className: 'schedule-card__grid' },
        el(StatCard, { label: 'Payment', value: formatMoney(props.row.totalPayment, props.currency) }),
        el(StatCard, { label: 'Principal', value: formatMoney(props.row.principalPaid, props.currency) }),
        el(StatCard, { label: 'Interest', value: formatMoney(props.row.interestPaid, props.currency) }),
        el(StatCard, { label: 'Balance', value: formatMoney(props.row.closingBalance, props.currency) })
      )
    );
  }

  function LoanPage() {
    var loanId = getSearchParam('id');
    var initialLoan = loanId ? Store.getLoanById(loanId) : null;
    var loanState = useState(initialLoan);
    var loan = loanState[0];
    var setLoan = loanState[1];
    var showAllPlannerState = useState(false);
    var showAllPlanner = showAllPlannerState[0];
    var setShowAllPlanner = showAllPlannerState[1];
    var showAllScheduleState = useState(false);
    var showAllSchedule = showAllScheduleState[0];
    var setShowAllSchedule = showAllScheduleState[1];
    var showAllPaymentsState = useState(false);
    var showAllPayments = showAllPaymentsState[0];
    var setShowAllPayments = showAllPaymentsState[1];
    var flashState = Common.useFlashMessage('');
    var flashMessage = flashState[0];
    var setFlashMessage = flashState[1];
    var currency = Store.getCurrency();

    useEffect(function () {
      if (!loanId) {
        return undefined;
      }
      function refreshLoan() {
        setLoan(Store.getLoanById(loanId));
      }
      runtimeRoot.addEventListener('focus', refreshLoan);
      return function () {
        runtimeRoot.removeEventListener('focus', refreshLoan);
      };
    }, [loanId]);

    var snapshot = useMemo(function () {
      return loan ? Calculator.buildLoanSnapshot(loan, new Date()) : null;
    }, [loan]);

    var insights = useMemo(function () {
      return loan && snapshot ? buildLoanInsights(loan, snapshot, currency) : [];
    }, [loan, snapshot, currency]);

    var plannerRowsAll = useMemo(function () {
      if (!snapshot) {
        return [];
      }
      var today = Calculator.toIsoDate(new Date());
      return snapshot.schedule.filter(function (row) {
        return Calculator.isDateOnOrAfter(row.paymentDate, today);
      });
    }, [snapshot]);

    var paymentRowsAll = useMemo(function () {
      if (!snapshot) {
        return [];
      }
      var today = Calculator.toIsoDate(new Date());
      var firstFutureIndex = snapshot.schedule.findIndex(function (row) {
        return !Calculator.isDateOnOrBefore(row.paymentDate, today);
      });
      var pivot = firstFutureIndex >= 0 ? firstFutureIndex : snapshot.schedule.length;
      var start = Math.max(0, pivot - 3);
      var end = Math.min(snapshot.schedule.length, pivot + 9);
      return snapshot.schedule.slice(start, end);
    }, [snapshot]);

    var plannerValuesState = useState({});
    var plannerValues = plannerValuesState[0];
    var setPlannerValues = plannerValuesState[1];
    var paymentDraftsState = useState({});
    var paymentDrafts = paymentDraftsState[0];
    var setPaymentDrafts = paymentDraftsState[1];

    useEffect(function () {
      if (!loan || !snapshot) {
        return;
      }
      var nextValues = {};
      plannerRowsAll.forEach(function (row) {
        nextValues[row.paymentDate] = String(getMonthlyExtraValue(loan, row.paymentDate));
      });
      setPlannerValues(nextValues);
      setPaymentDrafts(buildPaymentDrafts(loan, snapshot.schedule));
    }, [loanId, loan && loan.updatedAt, snapshot && snapshot.schedule.length, plannerRowsAll.length]);

    if (!loanId || !loan || !snapshot) {
      return el(PageShell, {
        currentPage: 'loans',
        title: 'Loan not found',
        subtitle: 'This loan may have been removed.',
        backHref: './loans.html'
      },
        el(EmptyState, {
          icon: '◌',
          title: 'Loan not found',
          message: 'Return to loans and select another loan.',
          actions: el(Button, { href: './loans.html' }, 'Back to loans')
        })
      );
    }

    function handlePlannerValueChange(date, value) {
      setPlannerValues(function (current) {
        return Object.assign({}, current, {
          [date]: value
        });
      });
    }

    function handleSavePlanner() {
      var plannerDateMap = plannerRowsAll.reduce(function (accumulator, row) {
        accumulator[row.paymentDate] = true;
        return accumulator;
      }, {});
      var preservedOverrides = (loan.monthlyExtraOverrides || []).filter(function (item) {
        return item && item.date && !plannerDateMap[item.date];
      });
      var nextOverrides = plannerRowsAll.reduce(function (accumulator, row) {
        return updateOverrideList(accumulator, row.paymentDate, plannerValues[row.paymentDate], loan.monthlyExtraPayment);
      }, preservedOverrides);
      var saved = Store.upsertLoan(Object.assign({}, loan, {
        monthlyExtraOverrides: nextOverrides
      }));
      setLoan(saved);
      setFlashMessage('Monthly extra plan updated.');
    }

    function updatePaymentDraft(date, key, value) {
      setPaymentDrafts(function (current) {
        return Object.assign({}, current, {
          [date]: Object.assign({}, current[date] || { amount: '', paidOn: '', note: '' }, {
            [key]: value
          })
        });
      });
    }

    function fillPlannedPayment(row) {
      var today = Calculator.toIsoDate(new Date());
      setPaymentDrafts(function (current) {
        return Object.assign({}, current, {
          [row.paymentDate]: {
            amount: String(row.plannedTotalPayment),
            paidOn: today,
            note: (current[row.paymentDate] && current[row.paymentDate].note) || 'Marked as paid'
          }
        });
      });
    }

    function handleSavePayments() {
      var nextActualPayments = normalizePaymentDrafts(snapshot.schedule, paymentDrafts);
      var saved = Store.upsertLoan(Object.assign({}, loan, {
        actualPayments: nextActualPayments
      }));
      setLoan(saved);
      setFlashMessage('Payment tracker updated.');
    }

    function handleDeleteLoan() {
      var confirmed = runtimeRoot.confirm('Delete this loan? This will remove the saved data from this device.');
      if (!confirmed) {
        return;
      }
      Store.deleteLoan(loan.id);
      Common.navigateTo('./loans.html');
    }

    function handleExportSchedule() {
      Common.downloadCsv((loan.name || 'loan').replace(/\s+/g, '-').toLowerCase() + '-schedule.csv', snapshot.schedule.map(function (row) {
        return {
          dueDate: row.paymentDate,
          openingBalance: row.openingBalance,
          plannedPayment: row.plannedTotalPayment,
          actualPayment: row.totalPayment,
          principalPaid: row.principalPaid,
          interestPaid: row.interestPaid,
          closingBalance: row.closingBalance,
          annualRate: row.annualRate,
          note: row.note,
          paidOn: row.paidOn
        };
      }), [
        { key: 'dueDate', label: 'Due date' },
        { key: 'openingBalance', label: 'Opening balance' },
        { key: 'plannedPayment', label: 'Planned payment' },
        { key: 'actualPayment', label: 'Actual payment' },
        { key: 'principalPaid', label: 'Principal paid' },
        { key: 'interestPaid', label: 'Interest paid' },
        { key: 'closingBalance', label: 'Closing balance' },
        { key: 'annualRate', label: 'Annual rate' },
        { key: 'paidOn', label: 'Paid on' },
        { key: 'note', label: 'Note' }
      ]);
      setFlashMessage('Schedule CSV exported.');
    }

    var plannerRows = showAllPlanner ? plannerRowsAll : plannerRowsAll.slice(0, 12);
    var scheduleRows = showAllSchedule ? snapshot.schedule : snapshot.schedule.slice(0, 12);
    var paymentRows = showAllPayments ? snapshot.schedule : paymentRowsAll;

    return el(PageShell, {
      currentPage: 'loans',
      title: loan.name,
      subtitle: loan.lender || 'Loan details',
      backHref: './loans.html',
      flashMessage: flashMessage,
      actions: el('div', { className: 'topbar__action-group' },
        el('a', { href: Common.buildUrl('form.html', { id: loan.id }), className: 'button button--ghost button--small' }, 'Edit'),
        el('a', { href: Common.buildUrl('calculator.html', { loanId: loan.id }), className: 'button button--ghost button--small' }, 'Advanced'),
        el('button', { type: 'button', className: 'button button--small', onClick: handleExportSchedule }, 'Export CSV')
      )
    },
      el(SectionCard, {
        className: 'loan-hero-card',
        style: { viewTransitionName: 'loan-card-' + loan.id },
        title: 'Loan summary',
        subtitle: 'Principal, interest, tracking, and remaining tenure.',
        action: el('button', {
          type: 'button',
          className: 'button button--ghost button--small',
          onClick: handleDeleteLoan
        }, 'Delete')
      },
        el('section', { className: 'summary-grid' },
          el(StatCard, {
            label: 'Loan amount',
            value: formatMoney(loan.principal, currency),
            hint: 'Original principal'
          }),
          el(StatCard, {
            label: 'Remaining balance',
            value: formatMoney(snapshot.remainingBalance, currency),
            hint: snapshot.nextDueDate ? 'Next due ' + formatDate(snapshot.nextDueDate) : 'Closed'
          }),
          el(StatCard, {
            label: 'Principal paid',
            value: formatMoney(snapshot.principalPaidSoFar, currency),
            hint: formatMoney(snapshot.interestPaidSoFar, currency) + ' interest paid'
          }),
          el(StatCard, {
            label: 'Remaining tenure',
            value: describeTenure(snapshot.remainingInstallments),
            hint: snapshot.payoffDate ? 'Payoff ' + formatMonth(snapshot.payoffDate) : '—'
          })
        ),
        el('div', { className: 'loan-progress-card' },
          el('div', { className: 'loan-progress-card__head' },
            el('strong', null, 'Repaid ' + snapshot.progressPercent.toFixed(0) + '%'),
            el('span', null, loan.prepaymentMode === 'reduceEmi' ? 'Reduce EMI mode' : 'Reduce tenure mode')
          ),
          el(ProgressBar, { percent: snapshot.progressPercent }),
          el('div', { className: 'chip-row' },
            el('span', { className: 'pill' }, 'EMI ' + formatMoney(snapshot.scheduledPayment, currency)),
            el('span', { className: 'pill' }, 'Interest saved ' + formatMoney(snapshot.interestSaved, currency)),
            el('span', { className: 'pill' }, snapshot.monthsSaved + ' months saved'),
            loan.offsetBalance > 0 ? el('span', { className: 'pill' }, 'Offset ' + formatMoney(loan.offsetBalance, currency)) : null,
            snapshot.hasActualTracking ? el('span', { className: 'pill' }, snapshot.actualPaymentCount + ' payments logged') : null
          )
        )
      ),
      el(SectionCard, {
        title: 'Smart insights',
        subtitle: 'Short observations about this loan.'
      },
        el('div', { className: 'insight-list' },
          insights.map(function (insight, index) {
            return el('div', { key: 'loan-insight-' + index, className: 'insight-item surface-card' },
              el('span', { className: 'insight-item__dot' }, '•'),
              el('p', { className: 'insight-item__text' }, insight)
            );
          })
        )
      ),
      el(SectionCard, {
        title: 'Balance chart',
        subtitle: 'Current plan compared with the no-extra baseline.'
      },
        el(BalanceChart, { rows: snapshot.schedule, comparisonRows: snapshot.baselineSchedule })
      ),
      el(SectionCard, {
        title: 'Payment tracker',
        subtitle: 'Log actual amounts, compare real vs planned, and keep history accurate.',
        action: el('div', { className: 'section-card__action-row' },
          snapshot.schedule.length > paymentRowsAll.length
            ? el(Button, {
                variant: 'ghost',
                small: true,
                onClick: function () { setShowAllPayments(!showAllPayments); }
              }, showAllPayments ? 'Show less' : 'Show all')
            : null,
          el(Button, { small: true, onClick: handleSavePayments }, 'Save payments')
        )
      },
        paymentRows.length
          ? el('div', { className: 'planner-list' },
              paymentRows.map(function (row) {
                var draft = paymentDrafts[row.paymentDate] || { amount: '', paidOn: '', note: '' };
                return el(PaymentTrackerRow, {
                  key: 'payment-' + row.paymentDate,
                  row: row,
                  draft: draft,
                  currency: currency,
                  onFillPlanned: function () { fillPlannedPayment(row); },
                  onChange: function (key, value) { updatePaymentDraft(row.paymentDate, key, value); }
                });
              })
            )
          : el('p', { className: 'muted-copy' }, 'No payment rows available yet.')
      ),
      el(SectionCard, {
        title: 'Monthly extra planner',
        subtitle: 'Adjust the recurring extra amount for each upcoming month.',
        action: el('div', { className: 'section-card__action-row' },
          plannerRowsAll.length > 12
            ? el(Button, {
                variant: 'ghost',
                small: true,
                onClick: function () { setShowAllPlanner(!showAllPlanner); }
              }, showAllPlanner ? 'Show less' : 'Show all')
            : null,
          el(Button, { small: true, onClick: handleSavePlanner }, 'Save planner')
        )
      },
        plannerRows.length
          ? el('div', { className: 'planner-list' },
              plannerRows.map(function (row) {
                return el(PlannerRow, {
                  key: row.paymentDate,
                  row: row,
                  snapshot: snapshot,
                  currency: currency,
                  value: plannerValues[row.paymentDate] || '0',
                  onChange: function (value) {
                    handlePlannerValueChange(row.paymentDate, value);
                  }
                });
              })
            )
          : el('p', { className: 'muted-copy' }, 'This loan is already paid off.')
      ),
      el(SectionCard, {
        title: 'Amortization schedule',
        subtitle: 'Principal, interest, and balance for each installment.',
        action: snapshot.schedule.length > 12
          ? el(Button, {
              variant: 'ghost',
              small: true,
              onClick: function () { setShowAllSchedule(!showAllSchedule); }
            }, showAllSchedule ? 'Show less' : 'Show all')
          : null
      },
        el('div', { className: 'schedule-list' },
          scheduleRows.map(function (row) {
            return el(ScheduleCard, {
              key: row.paymentDate,
              row: row,
              currency: currency
            });
          })
        )
      )
    );
  }

  return {
    LoanPage: LoanPage
  };
});
