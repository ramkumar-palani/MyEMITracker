(function (root) {
  'use strict';

  var deferredPrompt = null;
  var banner = null;
  var RUNTIME_CACHE = 'emi-tracker-runtime-v3';
  var REMINDER_STATE_KEY = 'emi-tracker-modern-pwa.reminder-state.v1';
  var WARM_URLS = [
    './index.html',
    './loans.html',
    './insights.html',
    './settings.html',
    './form.html',
    './loan.html',
    './calculator.html',
    './vendor/react-lite.js',
    './vendor/react-dom-lite.js'
  ];

  function ensureBanner() {
    if (!root.document || banner) {
      return banner;
    }
    banner = root.document.createElement('div');
    banner.className = 'install-banner surface-card';
    banner.innerHTML = '' +
      '<div class="install-banner__text">Install EMI Tracker for faster access and reminders.</div>' +
      '<div class="install-banner__actions">' +
      '  <button class="button button--ghost button--small" type="button" data-action="dismiss">Later</button>' +
      '  <button class="button button--small" type="button" data-action="install">Install</button>' +
      '</div>';

    banner.querySelector('[data-action="dismiss"]').addEventListener('click', function () {
      banner.remove();
    });
    banner.querySelector('[data-action="install"]').addEventListener('click', function () {
      if (!deferredPrompt) {
        banner.remove();
        return;
      }
      deferredPrompt.prompt();
      deferredPrompt.userChoice.finally(function () {
        deferredPrompt = null;
        banner.remove();
      });
    });
    root.document.body.appendChild(banner);
    return banner;
  }

  function warmRuntimeCache() {
    if (!('caches' in root) || !('fetch' in root)) {
      return Promise.resolve();
    }

    return root.caches.open(RUNTIME_CACHE).then(function (cache) {
      return Promise.all(WARM_URLS.map(function (url) {
        return cache.match(url).then(function (match) {
          if (match) {
            return null;
          }
          var request = new Request(url, {
            mode: 'same-origin',
            cache: 'no-store'
          });
          return root.fetch(request).then(function (response) {
            if (!response) {
              return null;
            }
            return cache.put(url, response.clone()).catch(function () {
              return null;
            });
          }).catch(function () {
            return null;
          });
        });
      }));
    }).catch(function () {
      return null;
    });
  }

  function requestNotificationPermission() {
    if (!root.Notification || typeof root.Notification.requestPermission !== 'function') {
      return Promise.resolve('unsupported');
    }
    return root.Notification.requestPermission();
  }

  function showNotification(title, options) {
    if (!root.Notification || root.Notification.permission !== 'granted') {
      return Promise.resolve(false);
    }
    if (root.navigator && root.navigator.serviceWorker && root.navigator.serviceWorker.ready) {
      return root.navigator.serviceWorker.ready.then(function (registration) {
        if (registration && typeof registration.showNotification === 'function') {
          return registration.showNotification(title, options || {});
        }
        return new root.Notification(title, options || {});
      }).catch(function () {
        return new root.Notification(title, options || {});
      });
    }
    return Promise.resolve(new root.Notification(title, options || {}));
  }

  function readReminderState() {
    try {
      var raw = root.localStorage && root.localStorage.getItem(REMINDER_STATE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (error) {
      return {};
    }
  }

  function writeReminderState(state) {
    try {
      if (root.localStorage) {
        root.localStorage.setItem(REMINDER_STATE_KEY, JSON.stringify(state));
      }
    } catch (error) {
      // Ignore storage failures.
    }
  }

  function getDueSoonLoans() {
    if (!root.EmiTrackerStore || !root.EmiTrackerCalculator) {
      return [];
    }
    var settings = root.EmiTrackerStore.getSettings();
    var today = root.EmiTrackerCalculator.toIsoDate(new Date());
    return root.EmiTrackerStore.getLoans().map(function (loan) {
      var snapshot = root.EmiTrackerCalculator.buildLoanSnapshot(loan, today);
      var diff = snapshot.nextDueDate ? root.EmiTrackerCalculator.daysBetween(today, snapshot.nextDueDate) : 9999;
      return {
        loan: loan,
        snapshot: snapshot,
        diff: diff
      };
    }).filter(function (item) {
      return settings.remindersEnabled && item.snapshot.nextDueDate && item.diff >= 0 && item.diff <= settings.reminderDaysBefore;
    }).sort(function (left, right) {
      return left.diff - right.diff;
    });
  }

  function sendDueNotifications() {
    if (!root.Notification || root.Notification.permission !== 'granted' || !root.EmiTrackerStore) {
      return Promise.resolve(false);
    }
    var settings = root.EmiTrackerStore.getSettings();
    if (!settings.remindersEnabled) {
      return Promise.resolve(false);
    }

    var dueSoon = getDueSoonLoans();
    if (!dueSoon.length) {
      return Promise.resolve(false);
    }

    var today = root.EmiTrackerCalculator.toIsoDate(new Date());
    var digest = dueSoon.map(function (item) {
      return item.loan.id + ':' + item.snapshot.nextDueDate;
    }).join('|');
    var state = readReminderState();
    if (state.lastDate === today && state.digest === digest) {
      return Promise.resolve(false);
    }

    var title = dueSoon.length === 1 ? 'EMI reminder' : dueSoon.length + ' EMI reminders';
    var body = dueSoon.length === 1
      ? dueSoon[0].loan.name + ' is due on ' + dueSoon[0].snapshot.nextDueDate + '.'
      : dueSoon[0].loan.name + ' and ' + (dueSoon.length - 1) + ' more loans are due soon.';

    writeReminderState({
      lastDate: today,
      digest: digest
    });

    return showNotification(title, {
      body: body,
      icon: './assets/icons/icon-192.png',
      badge: './assets/icons/icon-192.png'
    });
  }

  function triggerTestNotification() {
    return showNotification('EMI Tracker test reminder', {
      body: 'Browser reminders are active for this device.',
      icon: './assets/icons/icon-192.png',
      badge: './assets/icons/icon-192.png'
    });
  }

  root.EmiTrackerPWA = {
    requestNotificationPermission: requestNotificationPermission,
    sendDueNotifications: sendDueNotifications,
    triggerTestNotification: triggerTestNotification,
    warmRuntimeCache: warmRuntimeCache
  };

  root.addEventListener('beforeinstallprompt', function (event) {
    event.preventDefault();
    deferredPrompt = event;
    ensureBanner();
  });

  root.addEventListener('appinstalled', function () {
    deferredPrompt = null;
    if (banner) {
      banner.remove();
    }
  });

  root.addEventListener('load', function () {
    if ('serviceWorker' in root.navigator) {
      root.navigator.serviceWorker.register('./service-worker.js').then(function () {
        return root.navigator.serviceWorker.ready;
      }).then(function () {
        return warmRuntimeCache();
      }).then(function () {
        return sendDueNotifications();
      }).catch(function () {
        // Keep the app usable even if service worker registration fails.
      });
    }
  });

  root.addEventListener('visibilitychange', function () {
    if (root.document && root.document.visibilityState === 'visible') {
      sendDueNotifications();
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : this);
