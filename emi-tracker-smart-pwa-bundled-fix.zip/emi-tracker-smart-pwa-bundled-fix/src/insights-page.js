(function (root, factory) {
  root.EmiTrackerInsightsPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { InsightsPage: function InsightsPageFallback() { return null; } };
  }

  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var Field = Common.Field;
  var EmptyState = Common.EmptyState;
  var formatMoney = Common.formatMoney;
  var formatMonth = Common.formatMonth;
  var describeTenure = Common.describeTenure;
  var toNumber = Common.toNumber;

  function matchLoanByName(loans, query) {
    var text = String(query || '').toLowerCase();
    var best = null;
    loans.forEach(function (loan) {
      var name = String(loan.name || '').toLowerCase();
      if (name && text.indexOf(name) >= 0) {
        best = loan;
      }
    });
    return best;
  }

  function buildSmartInsights(loans, currency, strategyPlan) {
    var snapshots = loans.map(function (loan) {
      return {
        loan: loan,
        snapshot: Calculator.buildLoanSnapshot(loan, new Date())
      };
    });
    var highestRate = snapshots.slice().sort(function (left, right) {
      return right.snapshot.activeAnnualRate - left.snapshot.activeAnnualRate;
    })[0];
    var biggestInterest = snapshots.slice().sort(function (left, right) {
      return right.snapshot.projectedTotalInterest - left.snapshot.projectedTotalInterest;
    })[0];
    var topSavings = snapshots.slice().sort(function (left, right) {
      return right.snapshot.interestSaved - left.snapshot.interestSaved;
    })[0];
    var overdue = snapshots.filter(function (item) {
      return item.snapshot.nextDueDate && Calculator.daysBetween(Calculator.toIsoDate(new Date()), item.snapshot.nextDueDate) < 0;
    })[0];
    var insights = [];

    if (strategyPlan && strategyPlan.target) {
      insights.push('Focus extra cash on ' + strategyPlan.target.name + '. That matches your current ' + strategyPlan.reason.toLowerCase() + ' strategy.');
    }
    if (highestRate) {
      insights.push(highestRate.loan.name + ' has the highest active rate at ' + highestRate.snapshot.activeAnnualRate.toFixed(2) + '%.');
    }
    if (biggestInterest) {
      insights.push(biggestInterest.loan.name + ' will cost the most interest overall: ' + formatMoney(biggestInterest.snapshot.projectedTotalInterest, currency) + '.');
    }
    if (topSavings && topSavings.snapshot.interestSaved > 0) {
      insights.push(topSavings.loan.name + ' already saves you ' + formatMoney(topSavings.snapshot.interestSaved, currency) + ' in projected interest.');
    }
    if (overdue) {
      insights.push(overdue.loan.name + ' is overdue. Logging the actual payment will keep tracking accurate.');
    }
    return insights.slice(0, 4);
  }

  function answerAssistantQuery(query, loans, currency, strategyPlan) {
    var text = String(query || '').trim();
    if (!text) {
      return 'Ask a question like “Which loan should I close first?” or “What if I pay 10000 extra?”';
    }

    var lower = text.toLowerCase();
    var amountMatch = lower.match(/(\d[\d,\.]*)/);
    var parsedAmount = amountMatch ? toNumber(amountMatch[1].replace(/,/g, ''), 0) : 0;
    var namedLoan = matchLoanByName(loans, lower);

    if (lower.indexOf('which') >= 0 && lower.indexOf('loan') >= 0 && lower.indexOf('first') >= 0) {
      if (!strategyPlan.target) {
        return 'All your loans are already closed.';
      }
      return strategyPlan.target.name + ' should be first right now because it matches your ' + strategyPlan.reason.toLowerCase() + ' rule.';
    }

    if ((lower.indexOf('extra') >= 0 || lower.indexOf('more') >= 0) && parsedAmount > 0) {
      var plan = Calculator.buildStrategyPlan(loans, {
        strategy: strategyPlan.strategy,
        extraBudget: parsedAmount,
        asOfDate: new Date()
      });
      if (!plan.target) {
        return 'I could not find an active loan to allocate that extra amount to.';
      }
      return 'Put ' + formatMoney(parsedAmount, currency) + ' extra toward ' + plan.target.name + '. It could reduce interest by about ' + formatMoney(plan.target.projectedInterestReduction, currency) + ' and shorten the payoff by ' + plan.target.projectedMonthsReduction + ' months.';
    }

    if (lower.indexOf('save interest') >= 0) {
      if (!strategyPlan.target) {
        return 'You have no active loans to optimize.';
      }
      return 'The quickest interest win is to target ' + strategyPlan.target.name + ' first, then roll its payment into the next loan in the strategy list.';
    }

    if (namedLoan && (lower.indexOf('close') >= 0 || lower.indexOf('finish') >= 0)) {
      var targetYears = 0;
      var yearMatch = lower.match(/(\d+)\s*year/);
      var monthMatch = lower.match(/(\d+)\s*month/);
      if (yearMatch) {
        targetYears = Number(yearMatch[1]) * 12;
      } else if (monthMatch) {
        targetYears = Number(monthMatch[1]);
      }
      if (targetYears > 0) {
        var required = Calculator.findRequiredMonthlyPayment(namedLoan, targetYears);
        return 'To close ' + namedLoan.name + ' in about ' + describeTenure(targetYears) + ', aim for roughly ' + formatMoney(required + namedLoan.monthlyExtraPayment, currency) + ' per month in total payments.';
      }
    }

    return 'Try asking about payoff order, extra payments, or a target close date for one of your loans.';
  }

  function StrategyRow(props) {
    return el('div', { className: 'strategy-row' },
      el('div', { className: 'strategy-row__head' },
        el('strong', null, '#' + props.item.rank + ' ' + props.item.name),
        el('span', { className: 'pill pill--subtle' }, props.item.payoffDate ? formatMonth(props.item.payoffDate) : 'Open')
      ),
      el('div', { className: 'strategy-row__grid' },
        el(StatCard, { label: 'Balance', value: formatMoney(props.item.remainingBalance, props.currency) }),
        el(StatCard, { label: 'Rate', value: props.item.activeAnnualRate.toFixed(2) + '%' }),
        el(StatCard, { label: 'Monthly interest', value: formatMoney(props.item.currentMonthlyInterestCost, props.currency) }),
        el(StatCard, { label: 'Extra impact', value: props.item.projectedMonthsReduction + ' mo / ' + formatMoney(props.item.projectedInterestReduction, props.currency) })
      )
    );
  }

  function InsightsPage() {
    var loans = Store.getLoans();
    var currency = Store.getCurrency();
    var strategyState = useState('highestRate');
    var strategy = strategyState[0];
    var setStrategy = strategyState[1];
    var extraState = useState('5000');
    var extraBudget = extraState[0];
    var setExtraBudget = extraState[1];
    var queryState = useState('');
    var assistantQuery = queryState[0];
    var setAssistantQuery = queryState[1];
    var answerState = useState('');
    var assistantAnswer = answerState[0];
    var setAssistantAnswer = answerState[1];

    var snapshots = useMemo(function () {
      return loans.map(function (loan) {
        return Calculator.buildLoanSnapshot(loan, new Date());
      });
    }, [loans]);

    var totals = useMemo(function () {
      return snapshots.reduce(function (accumulator, snapshot) {
        accumulator.projectedInterest += snapshot.projectedTotalInterest;
        accumulator.interestSaved += snapshot.interestSaved;
        accumulator.loggedPayments += snapshot.actualPaymentCount;
        return accumulator;
      }, {
        projectedInterest: 0,
        interestSaved: 0,
        loggedPayments: 0
      });
    }, [snapshots]);

    var strategyPlan = useMemo(function () {
      return Calculator.buildStrategyPlan(loans, {
        strategy: strategy,
        extraBudget: toNumber(extraBudget, 0),
        asOfDate: new Date()
      });
    }, [loans, strategy, extraBudget]);

    var smartInsights = useMemo(function () {
      return buildSmartInsights(loans, currency, strategyPlan);
    }, [loans, currency, strategyPlan]);

    function handleAsk(queryText) {
      setAssistantAnswer(answerAssistantQuery(queryText, loans, currency, strategyPlan));
    }

    if (!loans.length) {
      return el(PageShell, {
        currentPage: 'insights',
        title: 'Insights',
        subtitle: 'Strategy and smart suggestions',
        actions: el('a', { href: './form.html', className: 'button button--small' }, 'Add loan')
      },
        el(EmptyState, {
          icon: '◔',
          title: 'Add loans to unlock insights',
          message: 'Once your loans are saved, the app will show payoff strategy, smart suggestions, and what-if guidance.',
          actions: el(Button, { href: './form.html' }, 'Add loan')
        })
      );
    }

    return el(PageShell, {
      currentPage: 'insights',
      title: 'Insights',
      subtitle: 'Strategy and smart suggestions'
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'Projected interest',
          value: formatMoney(totals.projectedInterest, currency),
          hint: 'Across all active loans'
        }),
        el(StatCard, {
          label: 'Interest saved',
          value: formatMoney(totals.interestSaved, currency),
          hint: 'From your current plan'
        }),
        el(StatCard, {
          label: 'Logged payments',
          value: String(totals.loggedPayments),
          hint: 'Actual payment history entries'
        })
      ),
      el(SectionCard, {
        title: 'Which loan should I close first?',
        subtitle: 'Choose a strategy and test an extra monthly budget.'
      },
        el('div', { className: 'form-grid' },
          el(Field, {
            label: 'Strategy',
            name: 'strategy',
            as: 'select',
            value: strategy,
            onChange: function (event) { setStrategy(event.target.value); },
            options: [
              { value: 'highestRate', label: 'Highest rate first' },
              { value: 'smallestBalance', label: 'Smallest balance first' },
              { value: 'highestInterestCost', label: 'Highest monthly interest cost' },
              { value: 'customPriority', label: 'Custom priority rank' }
            ]
          }),
          el(Field, {
            label: 'Extra monthly budget',
            name: 'extraBudget',
            type: 'number',
            min: '0',
            step: '100',
            inputMode: 'decimal',
            value: extraBudget,
            onChange: function (event) { setExtraBudget(event.target.value); },
            hint: 'Try a small monthly amount to see the payoff impact.'
          })
        ),
        strategyPlan.target
          ? el('div', { className: 'hero-recommendation' },
              el('div', { className: 'hero-recommendation__body' },
                el('strong', { className: 'hero-recommendation__title' }, strategyPlan.target.name + ' is your first target'),
                el('p', { className: 'muted-copy' }, strategyPlan.reason + '. With ' + formatMoney(strategyPlan.extraBudget, currency) + ' extra per month, this loan could save about ' + formatMoney(strategyPlan.target.projectedInterestReduction, currency) + ' and close about ' + strategyPlan.target.projectedMonthsReduction + ' months earlier.'),
                el('div', { className: 'chip-row' },
                  el('span', { className: 'pill' }, 'Balance ' + formatMoney(strategyPlan.target.remainingBalance, currency)),
                  el('span', { className: 'pill' }, 'Rate ' + strategyPlan.target.activeAnnualRate.toFixed(2) + '%'),
                  el('span', { className: 'pill' }, 'Monthly interest ' + formatMoney(strategyPlan.target.currentMonthlyInterestCost, currency))
                )
              )
            )
          : null,
        el('div', { className: 'stack-gap' },
          strategyPlan.order.map(function (item) {
            return el(StrategyRow, {
              key: item.id,
              item: item,
              currency: currency
            });
          })
        )
      ),
      el(SectionCard, {
        title: 'Smart insights',
        subtitle: 'Short observations about your current setup.'
      },
        el('div', { className: 'insight-list' },
          smartInsights.map(function (insight, index) {
            return el('div', { key: 'insight-' + index, className: 'insight-item surface-card' },
              el('span', { className: 'insight-item__dot' }, '•'),
              el('p', { className: 'insight-item__text' }, insight)
            );
          })
        )
      ),
      el(SectionCard, {
        title: 'Ask the smart assistant',
        subtitle: 'Rule-based answers for payoff planning and what-if questions.'
      },
        el('div', { className: 'stack-gap' },
          el('div', { className: 'form-grid' },
            el(Field, {
              label: 'Question',
              name: 'assistantQuery',
              value: assistantQuery,
              onChange: function (event) { setAssistantQuery(event.target.value); },
              wide: true,
              placeholder: 'What if I pay 10000 extra?'
            })
          ),
          el('div', { className: 'topbar__action-group' },
            el(Button, { onClick: function () { handleAsk(assistantQuery); } }, 'Ask'),
            el(Button, { variant: 'ghost', onClick: function () { setAssistantQuery('Which loan should I close first?'); handleAsk('Which loan should I close first?'); } }, 'Best loan first'),
            el(Button, { variant: 'ghost', onClick: function () { setAssistantQuery('What if I pay 10000 extra?'); handleAsk('What if I pay 10000 extra?'); } }, 'What-if extra'),
            el(Button, { variant: 'ghost', onClick: function () { if (strategyPlan.target) { var prompt = 'How can I close ' + strategyPlan.target.name + ' in 3 years?'; setAssistantQuery(prompt); handleAsk(prompt); } } }, 'Close in 3 years')
          ),
          assistantAnswer
            ? el('div', { className: 'assistant-answer surface-card' },
                el('strong', null, 'Answer'),
                el('p', { className: 'muted-copy' }, assistantAnswer)
              )
            : el('p', { className: 'muted-copy' }, 'Try a question about payoff order, extra payments, or a target close date.')
        )
      )
    );
  }

  return {
    InsightsPage: InsightsPage
  };
});
