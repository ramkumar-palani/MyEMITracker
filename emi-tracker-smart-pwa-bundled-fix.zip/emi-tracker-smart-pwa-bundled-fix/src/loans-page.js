(function (root, factory) {
  root.EmiTrackerLoansPage = factory(root.React, root.EmiTrackerCommon, root.EmiTrackerCalculator, root.EmiTrackerStore);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (React, Common, Calculator, Store) {
  'use strict';

  if (!React || !Common || !Calculator || !Store) {
    return { LoansPage: function LoansPageFallback() { return null; } };
  }

  var el = Common.el;
  var useMemo = React.useMemo;
  var useState = React.useState;
  var PageShell = Common.PageShell;
  var SectionCard = Common.SectionCard;
  var StatCard = Common.StatCard;
  var Button = Common.Button;
  var Field = Common.Field;
  var LoanCard = Common.LoanCard;
  var EmptyState = Common.EmptyState;
  var formatMoney = Common.formatMoney;

  function buildSummaryRows(items, currency) {
    return items.map(function (item) {
      return {
        name: item.loan.name,
        lender: item.loan.lender,
        loanAmount: item.loan.principal,
        outstanding: item.snapshot.remainingBalance,
        monthlyDue: item.snapshot.nextDueAmount || item.snapshot.totalRecurringPayment,
        payoffDate: item.snapshot.payoffDate,
        interestSaved: item.snapshot.interestSaved,
        strategyPriority: item.loan.priorityRank || ''
      };
    });
  }

  function LoansPage() {
    var loansState = useState(Store.getLoans());
    var loans = loansState[0];
    var setLoans = loansState[1];
    var sortState = useState('nextDue');
    var sortKey = sortState[0];
    var setSortKey = sortState[1];
    var currency = Store.getCurrency();

    var items = useMemo(function () {
      return loans.map(function (loan) {
        return {
          loan: loan,
          snapshot: Calculator.buildLoanSnapshot(loan, new Date())
        };
      });
    }, [loans]);

    var sortedItems = useMemo(function () {
      var next = items.slice();
      next.sort(function (left, right) {
        if (sortKey === 'balance') {
          return right.snapshot.remainingBalance - left.snapshot.remainingBalance;
        }
        if (sortKey === 'rate') {
          return right.snapshot.activeAnnualRate - left.snapshot.activeAnnualRate;
        }
        if (sortKey === 'payoff') {
          return String(left.snapshot.payoffDate || '').localeCompare(String(right.snapshot.payoffDate || ''));
        }
        return String(left.snapshot.nextDueDate || '').localeCompare(String(right.snapshot.nextDueDate || ''));
      });
      return next;
    }, [items, sortKey]);

    var totals = useMemo(function () {
      return sortedItems.reduce(function (accumulator, item) {
        accumulator.outstanding += item.snapshot.remainingBalance;
        accumulator.saved += item.snapshot.interestSaved;
        return accumulator;
      }, {
        outstanding: 0,
        saved: 0
      });
    }, [sortedItems]);

    function handleSeedSample() {
      setLoans(Store.seedSampleLoans());
    }

    function handleExportCsv() {
      Common.downloadCsv('emi-loans-summary.csv', buildSummaryRows(sortedItems, currency), [
        { key: 'name', label: 'Loan name' },
        { key: 'lender', label: 'Lender' },
        { key: 'loanAmount', label: 'Loan amount' },
        { key: 'outstanding', label: 'Outstanding balance' },
        { key: 'monthlyDue', label: 'Monthly due' },
        { key: 'payoffDate', label: 'Payoff date' },
        { key: 'interestSaved', label: 'Interest saved' },
        { key: 'strategyPriority', label: 'Priority rank' }
      ]);
    }

    if (!loans.length) {
      return el(PageShell, {
        currentPage: 'loans',
        title: 'Loans',
        subtitle: 'All saved loans',
        backHref: './index.html',
        actions: el('a', { href: './form.html', className: 'button button--small' }, 'Add loan')
      },
        el(EmptyState, {
          icon: '◎',
          title: 'No loans yet',
          message: 'Add your first loan or load the sample data.',
          actions: [
            el(Button, { key: 'sample', variant: 'ghost', onClick: handleSeedSample }, 'Load sample'),
            el(Button, { key: 'create', href: './form.html' }, 'Add loan')
          ]
        })
      );
    }

    return el(PageShell, {
      currentPage: 'loans',
      title: 'Loans',
      subtitle: 'All saved loans',
      actions: el('div', { className: 'topbar__action-group' },
        el('a', { href: './form.html', className: 'button button--ghost button--small' }, 'Add loan'),
        el('button', { type: 'button', className: 'button button--small', onClick: handleExportCsv }, 'Export CSV')
      )
    },
      el('section', { className: 'summary-grid' },
        el(StatCard, {
          label: 'Saved loans',
          value: String(loans.length),
          hint: 'Across all lenders'
        }),
        el(StatCard, {
          label: 'Outstanding',
          value: formatMoney(totals.outstanding, currency),
          hint: 'Current remaining balance'
        }),
        el(StatCard, {
          label: 'Interest saved',
          value: formatMoney(totals.saved, currency),
          hint: 'With your current plan'
        })
      ),
      el(SectionCard, {
        title: 'Loan cards',
        subtitle: 'Modern card view with progress, next due, and payoff date.',
        action: el(Field, {
          label: 'Sort by',
          name: 'sortKey',
          as: 'select',
          value: sortKey,
          onChange: function (event) { setSortKey(event.target.value); },
          options: [
            { value: 'nextDue', label: 'Next due date' },
            { value: 'balance', label: 'Outstanding balance' },
            { value: 'rate', label: 'Active interest rate' },
            { value: 'payoff', label: 'Payoff date' }
          ]
        })
      },
        el('div', { className: 'loan-grid' },
          sortedItems.map(function (item) {
            return el(LoanCard, {
              key: item.loan.id,
              loan: item.loan,
              snapshot: item.snapshot,
              currency: currency
            });
          })
        )
      )
    );
  }

  return {
    LoansPage: LoansPage
  };
});
